package com.myfamily.launcher;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** آخر قراءة طقس + توقعات حتى 3 أيام (كل يوم: الصبيحة/الظهيرة/الليل مع الرياح) من WeatherAPI forecast.json، محفوظة كـ JSON في الكاش. */
final class WeatherData {
    /** ساعات الفترات: الصبيحة 09:00، الظهيرة 14:00، الليل 21:00. */
    static final int[] PERIOD_HOURS = {9, 14, 21};

    /** فترة من اليوم من التوقعات الساعية. */
    static final class Period {
        final double tempC, tempF, windKph;
        final int code;
        final boolean isDay;
        Period(double tempC, double tempF, double windKph, int code, boolean isDay) {
            this.tempC = tempC; this.tempF = tempF; this.windKph = windKph; this.code = code; this.isDay = isDay;
        }
        String temp(boolean f) { return fmt(f ? tempF : tempC); }
        int iconRes() { return WeatherData.iconFor(code, isDay); }
        int tint() { return WeatherIcons.tint(code, isDay); }
    }

    /** يوم واحد من التوقعات. date بصيغة yyyy-MM-dd. periods بطول 3 (قد تحوي null). */
    static final class Day {
        final String date;
        final double maxC, maxF, minC, minF, windKph;
        final int code;
        final Period[] periods;
        Day(String date, double maxC, double maxF, double minC, double minF, int code, double windKph, Period[] periods) {
            this.date = date == null ? "" : date;
            this.maxC = maxC; this.maxF = maxF; this.minC = minC; this.minF = minF; this.code = code; this.windKph = windKph;
            this.periods = periods == null ? new Period[3] : periods;
        }
    }

    final double tempC, tempF, feelC, feelF, windKph;
    final int humidity, code;
    final boolean isDay;
    final String text, place, q, lang;
    final long fetchedAt;
    final List<Day> days;

    WeatherData(double tempC, double tempF, double feelC, double feelF, double windKph, int humidity,
                int code, boolean isDay, String text, String place, String q, String lang, long fetchedAt, List<Day> days) {
        this.tempC = tempC; this.tempF = tempF; this.feelC = feelC; this.feelF = feelF; this.windKph = windKph;
        this.humidity = humidity; this.code = code; this.isDay = isDay;
        this.text = text == null ? "" : text; this.place = place == null ? "" : place;
        this.q = q == null ? "" : q; this.lang = lang == null ? "" : lang; this.fetchedAt = fetchedAt;
        this.days = days == null ? new ArrayList<Day>() : days;
    }

    /** يحلّل ردّ forecast.json. التوقعات اختيارية: غيابها لا يُفشل القراءة الحالية. */
    static WeatherData fromApi(String json, String q, String lang) throws Exception {
        JSONObject root = new JSONObject(json);
        JSONObject cur = root.getJSONObject("current");
        JSONObject cond = cur.getJSONObject("condition");
        JSONObject loc = root.optJSONObject("location");
        List<Day> days = new ArrayList<>();
        JSONObject fc = root.optJSONObject("forecast");
        JSONArray arr = fc == null ? null : fc.optJSONArray("forecastday");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                JSONObject d = o == null ? null : o.optJSONObject("day");
                if (d == null) continue;
                JSONObject dc = d.optJSONObject("condition");
                Period[] per = new Period[3];
                JSONArray hrs = o.optJSONArray("hour");
                if (hrs != null) for (int k = 0; k < hrs.length(); k++) {
                    JSONObject h = hrs.optJSONObject(k);
                    if (h == null) continue;
                    String t = h.optString("time", "");               // "2026-11-22 09:00"
                    int sp = t.indexOf(' '), hour = -1;
                    if (sp > 0 && t.length() >= sp + 3) { try { hour = Integer.parseInt(t.substring(sp + 1, sp + 3)); } catch (Exception ignored) { } }
                    for (int n = 0; n < 3; n++) if (hour == PERIOD_HOURS[n]) {
                        JSONObject hc = h.optJSONObject("condition");
                        per[n] = new Period(h.optDouble("temp_c", 0), h.optDouble("temp_f", 0), h.optDouble("wind_kph", 0),
                                hc == null ? 1000 : hc.optInt("code", 1000), h.optInt("is_day", 1) == 1);
                    }
                }
                days.add(new Day(o.optString("date", ""), d.optDouble("maxtemp_c", 0), d.optDouble("maxtemp_f", 0),
                        d.optDouble("mintemp_c", 0), d.optDouble("mintemp_f", 0), dc == null ? 1000 : dc.optInt("code", 1000),
                        d.optDouble("maxwind_kph", 0), per));
            }
        }
        return new WeatherData(cur.getDouble("temp_c"), cur.getDouble("temp_f"),
                cur.optDouble("feelslike_c", cur.getDouble("temp_c")), cur.optDouble("feelslike_f", cur.getDouble("temp_f")),
                cur.optDouble("wind_kph", 0), cur.optInt("humidity", 0), cond.optInt("code", 1000),
                cur.optInt("is_day", 1) == 1, cond.optString("text", ""), loc == null ? "" : loc.optString("name", ""),
                q, lang, System.currentTimeMillis(), days);
    }


    // ===================== Open-Meteo (مجاني بلا مفتاح) =====================
    private static double c2f(double c) { return c * 9.0 / 5.0 + 32.0; }

    /** رموز WMO ← رموز WeatherAPI التي تفهمها WeatherIcons. */
    static int fromWmo(int w) {
        switch (w) {
            case 0: case 1: return 1000;
            case 2: return 1003;
            case 3: return 1009;
            case 45: case 48: return 1135;
            case 51: return 1150;
            case 53: case 55: return 1153;
            case 56: case 57: return 1168;
            case 61: return 1183;
            case 63: return 1189;
            case 65: return 1195;
            case 66: case 67: return 1198;
            case 71: return 1210;
            case 73: return 1216;
            case 75: return 1222;
            case 77: return 1237;
            case 80: return 1240;
            case 81: return 1243;
            case 82: return 1246;
            case 85: return 1255;
            case 86: return 1258;
            case 95: case 96: case 99: return 1276;
            default: return 1009;
        }
    }

    private static String describe(Context c, int w) {
        Context lc = LocaleHelper.wrap(c);
        int id;
        if (w <= 1) id = R.string.wx_clear;
        else if (w == 2) id = R.string.wx_partly;
        else if (w == 3) id = R.string.wx_cloudy;
        else if (w == 45 || w == 48) id = R.string.wx_fog;
        else if (w == 56 || w == 57 || w == 66 || w == 67) id = R.string.wx_freezing;
        else if (w >= 51 && w <= 55) id = R.string.wx_drizzle;
        else if (w >= 61 && w <= 65) id = R.string.wx_rain;
        else if ((w >= 71 && w <= 77) || w == 85 || w == 86) id = R.string.wx_snow;
        else if (w >= 80 && w <= 82) id = R.string.wx_showers;
        else if (w >= 95) id = R.string.wx_thunder;
        else id = R.string.wx_cloudy;
        return lc.getString(id);
    }

    /** يحلّل ردّ api.open-meteo.com/v1/forecast (current + hourly + daily) إلى نفس بنية WeatherAPI. */
    static WeatherData fromOpenMeteo(Context ctx, String json, String q, String lang, String place) throws Exception {
        JSONObject root = new JSONObject(json);
        JSONObject cur = root.getJSONObject("current");
        double tc = cur.getDouble("temperature_2m");
        double fc = cur.optDouble("apparent_temperature", tc);
        int w = cur.optInt("weather_code", 3);
        boolean day = cur.optInt("is_day", 1) == 1;
        List<Day> days = new ArrayList<>();
        JSONObject dl = root.optJSONObject("daily"), hr = root.optJSONObject("hourly");
        JSONArray dt = dl == null ? null : dl.optJSONArray("time");
        if (dt != null) {
            JSONArray dcode = dl.optJSONArray("weather_code"), dmx = dl.optJSONArray("temperature_2m_max"),
                    dmn = dl.optJSONArray("temperature_2m_min"), dwd = dl.optJSONArray("wind_speed_10m_max");
            JSONArray ht = hr == null ? null : hr.optJSONArray("time"), htm = hr == null ? null : hr.optJSONArray("temperature_2m"),
                    hc = hr == null ? null : hr.optJSONArray("weather_code"), hw = hr == null ? null : hr.optJSONArray("wind_speed_10m"),
                    hd = hr == null ? null : hr.optJSONArray("is_day");
            for (int i = 0; i < dt.length(); i++) {
                String date = dt.optString(i, "");
                Period[] per = new Period[3];
                if (ht != null && htm != null && hc != null) for (int k = 0; k < ht.length(); k++) {
                    String t = ht.optString(k, "");                       // "2026-11-25T09:00"
                    if (t.length() < 13 || !t.startsWith(date)) continue;
                    int hour; try { hour = Integer.parseInt(t.substring(11, 13)); } catch (Exception e) { continue; }
                    for (int n = 0; n < 3; n++) if (hour == PERIOD_HOURS[n]) {
                        double tp = htm.optDouble(k, 0);
                        per[n] = new Period(tp, c2f(tp), hw == null ? 0 : hw.optDouble(k, 0), fromWmo(hc.optInt(k, 3)), hd == null || hd.optInt(k, 1) == 1);
                    }
                }
                double mx = dmx == null ? 0 : dmx.optDouble(i, 0), mn = dmn == null ? 0 : dmn.optDouble(i, 0);
                days.add(new Day(date, mx, c2f(mx), mn, c2f(mn), fromWmo(dcode == null ? 3 : dcode.optInt(i, 3)),
                        dwd == null ? 0 : dwd.optDouble(i, 0), per));
            }
        }
        return new WeatherData(tc, c2f(tc), fc, c2f(fc), cur.optDouble("wind_speed_10m", 0), cur.optInt("relative_humidity_2m", 0),
                fromWmo(w), day, describe(ctx, w), place, q, lang, System.currentTimeMillis(), days);
    }

    String toJson() {
        try {
            JSONArray a = new JSONArray();
            for (Day d : days) {
                JSONArray pa = new JSONArray();
                for (int i = 0; i < 3; i++) {
                    Period p = d.periods[i];
                    if (p != null) pa.put(new JSONObject().put("i", i).put("tc", p.tempC).put("tf", p.tempF)
                            .put("w", p.windKph).put("c", p.code).put("d", p.isDay));
                }
                a.put(new JSONObject().put("d", d.date).put("xc", d.maxC).put("xf", d.maxF).put("nc", d.minC).put("nf", d.minF)
                        .put("c", d.code).put("w", d.windKph).put("p", pa));
            }
            return new JSONObject().put("tc", tempC).put("tf", tempF).put("fc", feelC).put("ff", feelF).put("w", windKph)
                    .put("h", humidity).put("c", code).put("d", isDay).put("t", text).put("p", place)
                    .put("q", q).put("l", lang).put("at", fetchedAt).put("days", a).toString();
        } catch (Exception e) { return ""; }
    }

    static WeatherData fromJson(String s) {
        try {
            JSONObject o = new JSONObject(s);
            List<Day> days = new ArrayList<>();
            JSONArray a = o.optJSONArray("days");               // كاش قديم بلا توقعات/فترات يبقى صالحاً
            if (a != null) for (int i = 0; i < a.length(); i++) {
                JSONObject d = a.getJSONObject(i);
                Period[] per = new Period[3];
                JSONArray pa = d.optJSONArray("p");
                if (pa != null) for (int k = 0; k < pa.length(); k++) {
                    JSONObject p = pa.getJSONObject(k);
                    int n = p.getInt("i");
                    if (n >= 0 && n < 3) per[n] = new Period(p.getDouble("tc"), p.getDouble("tf"), p.optDouble("w", 0), p.getInt("c"), p.getBoolean("d"));
                }
                days.add(new Day(d.optString("d"), d.getDouble("xc"), d.getDouble("xf"), d.getDouble("nc"), d.getDouble("nf"),
                        d.getInt("c"), d.optDouble("w", 0), per));
            }
            return new WeatherData(o.getDouble("tc"), o.getDouble("tf"), o.getDouble("fc"), o.getDouble("ff"), o.getDouble("w"),
                    o.getInt("h"), o.getInt("c"), o.getBoolean("d"), o.optString("t"), o.optString("p"),
                    o.optString("q"), o.optString("l"), o.getLong("at"), days);
        } catch (Exception e) { return null; }
    }

    private static String fmt(double v) { return String.format(Locale.US, "%d°", Math.round(v)); }

    String temp(boolean fahrenheit) { return String.format(Locale.US, "%d°%s", Math.round(fahrenheit ? tempF : tempC), fahrenheit ? "F" : "C"); }
    String feels(boolean fahrenheit) { return String.format(Locale.US, "%d°%s", Math.round(fahrenheit ? feelF : feelC), fahrenheit ? "F" : "C"); }

    int iconRes() { return iconFor(code, isDay); }
    int tint() { return WeatherIcons.tint(code, isDay); }

    /** أيقونة خطية بيضاء (الشارة والبطاقة وخلايا التوقعات). */
    static int iconFor(int code, boolean isDay) { return WeatherIcons.small(code, isDay); }
}
