package com.myfamily.launcher;

import android.app.Activity;
import android.app.Dialog;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

import java.io.*;
import java.net.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int LIVE = 0xFF5EE29A, TEXT = Color.WHITE, DIM = 0xCCFFFFFF, ACCENT = 0xFF6FD8FF, PANEL = 0xCC0B1626;

    static class App { String pkg, label; Drawable icon; boolean banner; }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private List<App> apps = new ArrayList<>();
    private LinearLayout dock;
    private TextView greeting, date, hijriDate, prayerName, prayerSub, prayerCity;
    private TextClock clock;
    private FrameLayout rootFrame;
    private Dialog prayerPanel;
    private LinearLayout matchCard;
    private MatchesPanel matchesPanel;
    private LinearLayout dockWrap;
    private TextView selTitle;
    private FocusGlass focusGlass;                 // الإطار الزجاجي العائم
    private static final float FOCUS_SCALE = 1.10f;  // تكبير البطاقة المحددة (≈1.12 في الفيديو)
    private int rowGx = 6, rowGy = 14;               // هوامش البطاقات (dp): أفقي / عمودي
    private View scrimView;
    private FrameLayout.LayoutParams matchLp;
    private FrameLayout bgHolder;
    private LinearLayout topPills, datesBox;
    private View clockRow, prayerCard, wifiPill, searchPill, settingsPill, radioPill, weatherPill;
    private View radioIcon;   // أيقونة الراديو: تُستبدل بالموجة أثناء التشغيل (بلا تغيير عرض الزر)
    private LinearLayout.LayoutParams wxLp; private ImageView weatherIcon; private TextView weatherTemp; private WeatherPanel weatherPanel;
    private RadioPanel radioPanel;
    private WaveformView radioWave;     // مؤشر صغير في بطاقة الراديو، يظهر فقط أثناء التشغيل الفعلي
    private TextView wifiText;
    private TextView speedView;
    private long spRx, spTx, spAt;
    /** سرعة الشبكة الحالية كل ثانية: ↓ أخضر (تنزيل) و↑ أحمر (رفع)، بلا خلفية، ظلّ خفيف فقط. */
    private final Runnable speedTick = new Runnable() {
        @Override public void run() {
            if (speedView != null && speedView.getVisibility() == View.VISIBLE) {
                long rx = android.net.TrafficStats.getTotalRxBytes(), tx = android.net.TrafficStats.getTotalTxBytes();
                long now = android.os.SystemClock.elapsedRealtime();
                if (rx != android.net.TrafficStats.UNSUPPORTED && tx != android.net.TrafficStats.UNSUPPORTED) {
                    if (spAt != 0 && now > spAt) {
                        double sec = (now - spAt) / 1000.0;
                        showSpeed(Math.max(0, (rx - spRx) / sec), Math.max(0, (tx - spTx) / sec));
                    }
                    spRx = rx; spTx = tx; spAt = now;
                } else speedView.setVisibility(View.GONE);      // الجهاز لا يدعم العدّاد
            } else spAt = 0;
            handler.postDelayed(this, 1000);
        }
    };

    private static String fmtSpeed(double bps) {
        double kb = bps / 1024.0;
        return kb < 1000 ? String.format(Locale.US, "%d KB/s", Math.round(kb)) : String.format(Locale.US, "%.1f MB/s", kb / 1024.0);
    }

    private void showSpeed(double down, double up) {
        android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder();
        int a = sb.length(); sb.append("\u2193");
        sb.setSpan(new android.text.style.ForegroundColorSpan(0xFF3DDC84), a, sb.length(), 0);
        sb.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), a, sb.length(), 0);
        sb.append(' ').append(fmtSpeed(down)).append("   ");
        int b = sb.length(); sb.append("\u2191");
        sb.setSpan(new android.text.style.ForegroundColorSpan(0xFFFF5252), b, sb.length(), 0);
        sb.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), b, sb.length(), 0);
        sb.append(' ').append(fmtSpeed(up));
        speedView.setText(sb);
    }
    private final Background backdrop = new Background();

    // ---------- الراديو ----------
    private final RadioPlayer.Listener radioListener = (state, station, err) -> { refreshRadioPill(); idleReset(); };

    // فتح «شاشة الاستماع» تلقائيًا بعد خمول أثناء تشغيل الراديو (الإعداد amb_auto بالدقائق، 0 = أبدًا)
    private final Runnable idleRun = () -> {
        if (prefs != null && prefs.getInt("amb_auto", 0) > 0 && RadioPlayer.get(this).isPlaying() && !isFinishing())
            startActivity(new Intent(this, AmbientActivity.class));
    };
    private void idleReset() {
        handler.removeCallbacks(idleRun);
        int min = prefs == null ? 0 : prefs.getInt("amb_auto", 0);
        if (min > 0 && RadioPlayer.get(this).isPlaying()) handler.postDelayed(idleRun, min * 60_000L);
    }
    @Override public void onUserInteraction() { super.onUserInteraction(); idleReset(); }

    // ---------- الطقس (WeatherAPI) ----------
    /** إذن الموقع يُطلب في askLocation() (FINE + COARSE). موقع الجهاز يغذّي الطقس فقط، وعند الرفض يعمل الـ fallback. */
    private void refreshDeviceLocation() {
        DeviceLocation.refresh(this, () -> WeatherRepository.refresh(this, false, this::updateWeatherPill));
    }

    /** كل 10 دقائق أثناء ظهور الشاشة؛ WeatherRepository نفسه يقرر هل يجلب (كل 30 دقيقة كحد أدنى) وكل الشبكة بخيط خلفي. */
    private final Runnable weatherTick = new Runnable() {
        @Override public void run() {
            WeatherRepository.refresh(MainActivity.this, false, MainActivity.this::updateWeatherPill);
            updateWeatherPill();
            handler.postDelayed(this, 10 * 60_000L);
        }
    };

    /** سطر الطقس تحت الساعة: "الدرجة" (+ " · سبب الخطأ" إن فشل آخر جلب)، أو "-- · الخطأ" إن لا كاش؛ مخفي إن لا مفتاح/لا بيانات/لا خطأ. */
    private void updateWeatherPill() {
        if (weatherPill == null) return;
        boolean show = Background.flag(this, WeatherRepository.P_SHOW) && WeatherRepository.enabled(this);
        WeatherData d = show ? WeatherRepository.cached(this) : null;
        int err = show ? WeatherRepository.errorText(this) : 0;
        boolean vis = show && clockRow != null && clockRow.getVisibility() == View.VISIBLE && (d != null || err != 0);
        if (vis) {
            String e = err != 0 ? " · " + getString(err) : "";
            if (d != null) {
                weatherIcon.setImageResource(d.iconRes());
                weatherIcon.setColorFilter(d.tint());
                weatherTemp.setText(d.temp(prefs.getBoolean(WeatherRepository.P_FAHRENHEIT, false)) + e);
                weatherPill.setContentDescription(d.text);
            } else {
                weatherIcon.setImageResource(R.drawable.ic_w_cloud);
                weatherIcon.setColorFilter(0xFFB8C7D9);
                weatherTemp.setText("--" + e);
            }
        }
        weatherPill.setVisibility(vis ? View.VISIBLE : View.GONE);
    }

    /** المؤشر الصغير يتحرك ويظهر فقط عندما يكون البث في حالة تشغيل فعلي. */
    private void refreshRadioPill() {
        if (radioWave == null) return;
        boolean playing = RadioPlayer.get(this).isPlaying();
        radioWave.setPlaying(playing);
        radioWave.setVisibility(playing ? View.VISIBLE : View.GONE);
        if (radioIcon != null) radioIcon.setVisibility(playing ? View.GONE : View.VISIBLE);
    }

    // ---------- lifecycle ----------
    @Override protected void attachBaseContext(Context base) { super.attachBaseContext(LocaleHelper.wrap(base)); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        CleanStart.run(this);
        prefs = getSharedPreferences("launcher", MODE_PRIVATE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        try {
            PrayerTimes.LAT = Double.parseDouble(prefs.getString("lat", "33.80"));
            PrayerTimes.LNG = Double.parseDouble(prefs.getString("lng", "2.88"));
            PrayerTimes.TZ = TimeZone.getTimeZone(prefs.getString("tz", "Africa/Algiers"));
            PrayerTimes.METHOD = prefs.getInt("method", 19);
            PrayerTimes.loadAdjust(prefs);
        } catch (Exception ignored) { }
        setContentView(buildUi());
        // اسم الواي فاي يحتاج إذن الموقع (قيد من أندرويد). يُطلب مرة واحدة فقط.
        askLocation();
    }

    private static boolean askedThisRun = false;
    private void askLocation() {
        if (Build.VERSION.SDK_INT < 23 || askedThisRun) return;
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) return;
        askedThisRun = true;
        try { requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 77); } catch (Exception ignored) { }
    }

    private boolean ssidOk = false;
    private boolean hasLocPerm() { return Build.VERSION.SDK_INT < 23 || checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED; }
    private void onWifiClick() {
        if (!hasLocPerm() && prefs.getInt("loc_denied", 0) < 2) { askedThisRun = false; askLocation(); return; }
        if (hasLocPerm() && !ssidOk && Build.VERSION.SDK_INT >= 28) {
            try {
                android.location.LocationManager lm = (android.location.LocationManager) getSystemService(LOCATION_SERVICE);
                if (lm != null && !lm.isLocationEnabled()) {
                    Toast.makeText(this, R.string.wifi_hint_location, Toast.LENGTH_LONG).show();
                    open(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); return;
                }
            } catch (Exception ignored) { }
        }
        open(new Intent(Settings.ACTION_WIFI_SETTINGS));
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (res.length == 0 || res[0] != PackageManager.PERMISSION_GRANTED) prefs.edit().putInt("loc_denied", prefs.getInt("loc_denied", 0) + 1).apply();
        refreshDeviceLocation();
        refreshHeader();
    }

    @Override protected void onResume() {
        super.onResume();
        loadApps();
        backdrop.apply(this, bgHolder);
        applyVisibility();
        refreshDock();
        tick.run();
        RadioPlayer.get(this).addListener(radioListener);
        refreshRadioPill();
        spAt = 0; handler.removeCallbacks(speedTick); handler.post(speedTick);
        idleReset();
        handler.removeCallbacks(weatherTick); handler.post(weatherTick);
        refreshDeviceLocation();
        Adhan.schedule(this);
        askLocation();
        String dlg = getIntent().getStringExtra("dlg");
        if (dlg != null) { getIntent().removeExtra("dlg"); if (dlg.equals("method")) showMethodDialog(); else if (dlg.equals("about")) showAbout(); else if (dlg.equals("greet")) showGreetings(); else showCityDialog(); }
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); }

    @Override protected void onPause() {
        super.onPause(); handler.removeCallbacks(speedTick); handler.removeCallbacks(tick); backdrop.stop(); bgHolder.removeAllViews(); hidePrayerPanel(); matchesPanel.hide();
        RadioPlayer.get(this).removeListener(radioListener);
        handler.removeCallbacks(weatherTick); handler.removeCallbacks(idleRun);
        if (radioPanel != null) radioPanel.dismiss();
        if (weatherPanel != null) weatherPanel.dismiss();
    }

    @Override protected void onDestroy() {
        // إيقاف وتحرير الصوت عند إغلاق الشاشة نهائياً (لا عند تدوير/تغيير اللغة)
        if (radioPanel != null) radioPanel.dismiss();
        if (weatherPanel != null) weatherPanel.dismiss();
        if (!isChangingConfigurations()) RadioPlayer.get(this).release();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (dockExpanded) setDockExpanded(false);
        else if (matchesPanel.isShowing()) { matchesPanel.hide(); matchCard.requestFocus(); }
        else if (prayerPanel != null) hidePrayerPanel(); /* الرئيسية: لا شيء */
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            refreshHeader(); refreshMatchCard();
            Football.refresh(MainActivity.this, false, MainActivity.this::refreshMatchCard);
            handler.postDelayed(this, 20000);
        }
    };

    // ---------- UI ----------
    private View buildUi() {
        FrameLayout root = new FrameLayout(this);
        rootFrame = root;
        matchesPanel = new MatchesPanel(this, root);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF0A1424, 0xFF14405A}));

        bgHolder = new FrameLayout(this);
        root.addView(bgHolder, new FrameLayout.LayoutParams(-1, -1));

        // تعتيم خفيف أعلى الشاشة لتحسين قراءة النص
        View scrim = new View(this); scrimView = scrim;
        scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x66000000, 0x00000000}));
        root.addView(scrim, new FrameLayout.LayoutParams(-1, dp(260)));

        // أعلى اليسار: التحية + الساعة + التاريخ + بطاقة الصلاة
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        greeting = text(14, DIM); greeting.setLetterSpacing(0.25f);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm"); clock.setFormat12Hour("hh:mm");
        clock.setTypeface(Fonts.outfit(this)); clock.setTextSize(58); clock.setTextColor(TEXT); clock.setShadowLayer(8, 0, 2, 0x88000000);
        clock.setSingleLine(true); clock.setMaxLines(1); clock.setIncludeFontPadding(false);
        // العرض الأدنى يُحسب من أعرض رقم في الخط (انظر fitClockWidth) فلا يتحرك التاريخ عند تغيّر الأرقام ولا يُقص أكبر وقت مثل 22:22
        clock.setPadding(0, 0, 0, 0);
        clock.setTextDirection(View.TEXT_DIRECTION_LTR);
        clock.setTextLocale(Locale.getDefault());
        row.addView(clock);
        View divider = new View(this); divider.setBackgroundColor(0x66FFFFFF);
        LinearLayout.LayoutParams dvl = new LinearLayout.LayoutParams(dp(1), dp(48)); dvl.setMarginStart(dp(4));
        row.addView(divider, dvl);
        LinearLayout dates = new LinearLayout(this);
        dates.setOrientation(LinearLayout.VERTICAL);
        dates.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        dates.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        dates.setPadding(dp(6), 0, 0, 0);
        datesBox = dates;
        date = text(15, DIM);
        date.setMaxLines(2);
        date.setTextDirection(View.TEXT_DIRECTION_LTR);
        date.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        date.setLetterSpacing(0.06f);
        hijriDate = text(15, DIM);
        hijriDate.setMaxLines(2);
        hijriDate.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        hijriDate.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        dates.addView(date); dates.addView(hijriDate);
        // الطقس: سطر صغير تحت الساعة مباشرة (بلا زر زجاجي؛ لا يمسّ التاريخ ولا أزرار اليمين). يُضاف إلى العمود الأيسر بعد الساعة.
        weatherPanel = new WeatherPanel(this);
        weatherPanel.onUpdate = this::updateWeatherPill;
        LinearLayout wx = new LinearLayout(this);
        wx.setGravity(Gravity.CENTER_VERTICAL);
        weatherIcon = new ImageView(this); weatherIcon.setImageResource(R.drawable.ic_w_cloud); weatherIcon.setColorFilter(TEXT);
        wx.addView(weatherIcon, new LinearLayout.LayoutParams(dp(22), dp(22)));
        weatherTemp = text(18, TEXT); weatherTemp.setTypeface(Fonts.bold(this)); weatherTemp.setSingleLine(true);
        weatherTemp.setEllipsize(android.text.TextUtils.TruncateAt.END); weatherTemp.setMaxWidth(dp(300));
        weatherTemp.setPadding(dp(8), 0, 0, 0); weatherTemp.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        wx.addView(weatherTemp);
        wx.setClickable(true); wx.setFocusable(true);            // OK على الريموت يفتح بطاقة التوقعات
        wx.setPadding(dp(12), dp(5), dp(16), dp(5));
        wx.setBackground(wxBg(false));                           // خلفية دائمة داكنة بإطار ذهبي؛ تتوهّج عند التركيز
        wx.setOnFocusChangeListener((v, fo) -> v.setBackground(wxBg(fo)));
        wx.setOnClickListener(v -> weatherPanel.show(WeatherRepository.cached(this)));
        wx.setVisibility(View.GONE); weatherPill = wx;
        wxLp = new LinearLayout.LayoutParams(-2, -2); wxLp.topMargin = dp(4);
        row.addView(dates);
        // بطاقة الصلاة: صغيرة، خلفية مسجد خافتة، ونص واضح
        FrameLayout card = new FrameLayout(this);
        card.setBackgroundResource(R.drawable.prayer_card_bg);
        card.setClipToOutline(true);
        card.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(18)); }
        });
        card.setFocusable(true); card.setClickable(true);
        card.setOnFocusChangeListener((v, f) -> { v.setScaleX(f ? 1.04f : 1f); v.setScaleY(f ? 1.04f : 1f); ((FrameLayout) v).setForeground(f ? round(0x00000000, 18, 3) : null); });
        card.setOnClickListener(v -> showPrayerPanel());
        ImageView mosque = new ImageView(this);
        mosque.setImageResource(R.drawable.mosque_bg);
        mosque.setScaleType(ImageView.ScaleType.CENTER_CROP);
        mosque.setAlpha(0.50f);                       // شفافة: المسجد خافت خلف المعلومات
        card.addView(mosque, new FrameLayout.LayoutParams(-1, -1));
        View scrim2 = new View(this); scrim2.setBackgroundColor(0x22000000);
        card.addView(scrim2, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(18), dp(10), dp(18), dp(10)); info.setGravity(Gravity.CENTER_VERTICAL);
        prayerName = cardText(text(24, TEXT)); prayerName.setTypeface(Fonts.bold(this));
        prayerSub = cardText(text(14, TEXT));
        prayerCity = text(11, TEXT);
        prayerCity.setPadding(dp(10), dp(3), dp(10), dp(3));
        prayerCity.setBackground(round(0x88000000, 10, 0));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(-2, -2); pl.bottomMargin = dp(6);
        info.addView(prayerCity, pl); info.addView(prayerName); info.addView(prayerSub);
        card.addView(info, new FrameLayout.LayoutParams(-1, -1));
        prayerCard = card;
        speedView = text(13, DIM); speedView.setSingleLine(true);
        speedView.setPadding(dp(22), 0, 0, 0);
        showSpeed(0, 0);
        LinearLayout greetRow = new LinearLayout(this);
        greetRow.setOrientation(LinearLayout.HORIZONTAL); greetRow.setGravity(Gravity.CENTER_VERTICAL);
        greetRow.addView(greeting); greetRow.addView(speedView);
        left.addView(greetRow); left.addView(row, new LinearLayout.LayoutParams(-2, -2)); clockRow = row;
        left.addView(weatherPill, wxLp);
        // حجم البطاقة نسبة إلى الشاشة (≈ 35.5% من العرض، ونسبة 2.8:1) كما في التصميم المطلوب
        android.util.DisplayMetrics sdm = getResources().getDisplayMetrics();
        int cardW = Math.round(sdm.widthPixels * (21f / 70.8f));     // 21 سم من 70.8 سم (تلفاز 32 بوصة)
        int cardH = Math.round(sdm.heightPixels * (5.5f / 39.8f));   // 5.5 سم من 39.8 سم
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(cardW, cardH); cp.topMargin = dp(14);
        prayerCity.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sdm.heightPixels * 0.019f);
        prayerName.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sdm.heightPixels * 0.034f);
        prayerSub.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sdm.heightPixels * 0.022f);
        prayerCity.setPadding(dp(8), dp(2), dp(8), dp(2));
        info.setPadding(dp(14), Math.round(sdm.heightPixels * 0.008f), dp(14), Math.round(sdm.heightPixels * 0.008f));
        left.addView(card, cp);

        matchCard = new LinearLayout(this);
        matchCard.setOrientation(LinearLayout.VERTICAL);
        matchCard.setLayoutDirection(View.LAYOUT_DIRECTION_LTR); matchCard.setGravity(Gravity.RIGHT);
        matchCard.setPadding(dp(8), dp(8), dp(8), dp(8));
        matchCard.setBackground(round(0x00000000, 22, 0));
        matchCard.setFocusable(true); matchCard.setClickable(true);
        matchCard.setOnFocusChangeListener((v, f) -> v.setBackground(round(0x00000000, 22, f ? 3 : 0)));  // بلا خلفية؛ إطار رفيع عند التحديد فقط
        matchCard.setOnClickListener(v -> matchesPanel.show());
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        lp.setMargins(dp(40), dp(28), 0, 0);
        root.addView(left, lp);

        // أعلى اليمين: أزرار واي فاي / بحث / إعدادات
        LinearLayout pills = new LinearLayout(this);
        radioPanel = new RadioPanel(this);
        View radio = iconPill(R.drawable.ic_radio, getString(R.string.radio), () -> radioPanel.show());
        radioWave = new WaveformView(this, 5, false);
        radioWave.setVisibility(View.GONE);
        // الموجة تحلّ محلّ الأيقونة في نفس المكان والحجم (24dp) فلا يكبر زر الراديو عند التشغيل ولا يتراكب مع التاريخ
        LinearLayout.LayoutParams rwp = new LinearLayout.LayoutParams(dp(24), dp(24));
        radioIcon = ((LinearLayout) radio).getChildAt(0);
        ((LinearLayout) radio).addView(radioWave, 1, rwp);
        radioPill = radio;
        View wifi = iconPill(R.drawable.ic_wifi, getString(R.string.wifi), this::onWifiClick);
        wifiText = (TextView) ((LinearLayout) wifi).getChildAt(1);   // نفس خط «الإعدادات» (Outfit)
        wifiText.setSingleLine(true); wifiText.setEllipsize(android.text.TextUtils.TruncateAt.END); wifiText.setMaxWidth(dp(240));
        View search = iconPill(R.drawable.ic_search, null, this::showSearch);
        View set = iconPill(R.drawable.ic_gear, getString(R.string.settings), null);
        set.setOnClickListener(v -> showMenu(v));
        wifiPill = wifi; searchPill = search; settingsPill = set;
        for (View v : new View[]{radio, wifi, search, set}) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(v == search ? dp(48) : -2, dp(48)); p.setMarginStart(dp(12));
            pills.addView(v, p);
        }
        topPills = pills;
        // على التلفاز: عرض الأزرار (اسم الشبكة + موجة الراديو) قد يتجاوز المتاح فيتراكب مع التاريخ؛ نقصّ اسم الشبكة عند الحاجة
        View.OnLayoutChangeListener fit = (fv, fl, ft, fr, fb, fol, fot, for0, fob) -> { if (fr - fl != for0 - fol) rootFrame.post(this::fitPills); };
        pills.addOnLayoutChangeListener(fit);
        datesBox.addOnLayoutChangeListener(fit);
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        rp.setMargins(0, dp(28), dp(40), 0);
        root.addView(pills, rp);

        // بطاقة المباريات: يمين الشاشة تحت الأزرار
        FrameLayout.LayoutParams mcp = new FrameLayout.LayoutParams(Math.round(getResources().getDisplayMetrics().widthPixels * 0.40f), -2, Gravity.BOTTOM | Gravity.END);
        mcp.setMargins(0, 0, dp(32), dp(212));
        matchLp = mcp;
        root.addView(matchCard, mcp);

        // أسفل: عنوان التطبيق المحدد + الشريط (المفضلة وصفوف إضافية)
        selTitle = text(22, TEXT);
        selTitle.setSingleLine(true); selTitle.setShadowLayer(14, 0, 2, 0xCC000000);
        selTitle.setPadding(dp(10), 0, 0, dp(8));
        dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.VERTICAL);
        dock.setPadding(dp(10), dp(10), dp(10), dp(10));
        dock.setBackground(round(PANEL, 28, 0));
        dock.setClipChildren(false); dock.setClipToPadding(false);
        dockWrap = new LinearLayout(this);
        dockWrap.setOrientation(LinearLayout.VERTICAL);
        dockWrap.setClipChildren(false); dockWrap.setClipToPadding(false);
        dockWrap.addView(selTitle, new LinearLayout.LayoutParams(-2, -2));
        // نافذة عمودية: الشريط الأسود (المفضلة + الأكثر استعمالاً) ثم صفوف باقي التطبيقات تحته
        stack = new LinearLayout(this); stack.setOrientation(LinearLayout.VERTICAL);
        stack.setClipChildren(false); stack.setClipToPadding(false);
        stack.setPadding(dp(8), dp(8), dp(8), dp(8));
        stack.addView(dock, new LinearLayout.LayoutParams(-2, -2));
        appsList = new LinearLayout(this); appsList.setOrientation(LinearLayout.VERTICAL);
        appsList.setClipChildren(false); appsList.setClipToPadding(false);
        LinearLayout.LayoutParams alp0 = new LinearLayout.LayoutParams(-2, -2); alp0.topMargin = dp(6);
        stack.addView(appsList, alp0);
        appsScroll = new ScrollView(this);
        appsScroll.setVerticalScrollBarEnabled(false); appsScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        appsScroll.setClipChildren(false); appsScroll.setClipToPadding(false);
        appsScroll.addView(stack);
        dockWrap.addView(appsScroll, new LinearLayout.LayoutParams(-2, -2));
        FrameLayout.LayoutParams dp_ = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        dp_.bottomMargin = dp(10);
        root.setClipChildren(false);
        root.addView(dockWrap, dp_);
        focusGlass = new FocusGlass(this);
        root.addView(focusGlass, new FrameLayout.LayoutParams(-1, -1));   // فوق الشريط، تحت اللوحات المنبثقة
        // بطاقة المباريات تلتصق بأعلى الشريط الأسود الفعلي (يمين الشاشة)، وتُحسب من موضعه الحقيقي
        appsScroll.addOnLayoutChangeListener((v0, l0, t0, r0, b0, ol, ot, or_, ob) -> {
            if (dockExpanded || dock.getBottom() <= 0 || dock.getVisibility() != View.VISIBLE) return;
            int top = dockWrap.getTop() + appsScroll.getTop() + dock.getTop();
            int bm = root.getHeight() - top + dp(8);
            if (bm > 0 && matchLp.bottomMargin != bm) { matchLp.bottomMargin = bm; matchCard.post(() -> matchCard.setLayoutParams(matchLp)); }
        });
        return root;
    }

    private void applyVisibility() {
        boolean clean = Background.clean(this);
        int mode = Background.mode(this);
        boolean photo = mode >= 1 && Background.hasSaved(this, mode);
        boolean hide = clean || (photo && !Background.flag(this, "vis_onphotos"));
        boolean clk = !hide && Background.flag(this, "vis_clock");
        greeting.setVisibility(clk && pref("show_greeting", true) ? View.VISIBLE : View.GONE);
        clockRow.setVisibility(clk ? View.VISIBLE : View.GONE);
        date.setVisibility(pref("show_date", true) ? View.VISIBLE : View.GONE);
        speedView.setVisibility(!hide && Background.flag(this, "vis_speed") ? View.VISIBLE : View.GONE);
        prayerCard.setVisibility((!hide && Background.flag(this, "vis_prayer")) ? View.VISIBLE : View.GONE);
        matchCard.setVisibility((!hide && Background.flag(this, "vis_matches") && Football.hasKey(this)) ? View.VISIBLE : View.GONE);
        wifiPill.setVisibility((!clean && Background.flag(this, "vis_net")) ? View.VISIBLE : View.GONE);
        radioPill.setVisibility(!clean ? View.VISIBLE : View.GONE);
        updateWeatherPill();
        // صيغة الساعة
        int cf = prefs.getInt("clock_fmt", 0);
        if (cf == 0) { clock.setFormat12Hour(null); clock.setFormat24Hour(null); }
        else if (cf == 1) { clock.setFormat12Hour("h:mm a"); clock.setFormat24Hour("h:mm a"); }
        else { clock.setFormat12Hour("HH:mm"); clock.setFormat24Hour("HH:mm"); }
        fitClockWidth();
        // التباين المعزّز
        boolean hc = pref("contrast", false);
        for (TextView tv : new TextView[]{greeting, clock, date, speedView}) tv.setShadowLayer(hc ? 16 : 8, 0, 2, hc ? 0xEE000000 : 0x88000000);
        scrimView.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{hc ? 0xAA000000 : 0x66000000, 0x00000000}));
    }

    private boolean pref(String k, boolean d) { return prefs.getBoolean(k, d); }

    private void refreshMatchCard() {
        matchCard.removeAllViews();
        List<Football.M> top = Football.featured(this);
        if (top.isEmpty()) {
            TextView t = cardGlow(text(20, TEXT), true);
            t.setText(getString(!Football.hasKey(this) ? R.string.matches_no_key : Football.p(this).getString("fb_err", "").isEmpty() ? R.string.no_matches_now : R.string.matches_update_failed));
            TextView s = cardGlow(text(11, DIM), false); s.setText(R.string.tap_to_open); s.setLetterSpacing(0.12f);
            matchCard.addView(t); matchCard.addView(s);
            return;
        }
        // المباراة المهمة: عنوان كبير بلا إطار + سطر صغير متباعد الحروف
        Football.M f = top.get(0);
        boolean started = f.hg >= 0 && f.ag >= 0;
        TextView title = cardGlow(text(26, TEXT), true); title.setGravity(Gravity.CENTER);
        title.setText(started ? f.home + "  " + f.hg + " – " + f.ag + "  " + f.away : f.home + " v " + f.away);
        title.setMaxLines(1); title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        if (android.os.Build.VERSION.SDK_INT >= 26)
            title.setAutoSizeTextTypeUniformWithConfiguration(14, 26, 1, android.util.TypedValue.COMPLEX_UNIT_SP);
        LinearLayout teams = new LinearLayout(this); teams.setGravity(Gravity.CENTER_VERTICAL); teams.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        ImageView homeCrest = matchLogo(f.homeLogo, 38), awayCrest = matchLogo(f.awayLogo, 38);
        LinearLayout.LayoutParams crestLp = new LinearLayout.LayoutParams(dp(48), dp(48)); crestLp.setMargins(0, 0, 0, 0);
        teams.addView(homeCrest, crestLp);
        teams.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        teams.addView(awayCrest, crestLp);
        TextView sub = cardGlow(text(11, Football.live(f.st) ? LIVE : DIM), false);
        sub.setGravity(Gravity.RIGHT);
        sub.setLetterSpacing(0.14f); sub.setSingleLine(true); sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        sub.setText(Football.subline(this, f).toUpperCase(Locale.getDefault()));
        sub.setPadding(dp(2), dp(3), 0, dp(10));
        matchCard.addView(teams); matchCard.addView(sub);

        // حتى مباراتين تحت الكبيرة، جنبًا إلى جنب (إن وُجدتا). مباراة واحدة إضافية تأخذ النصف الأيمن.
        int extra = Math.min(2, top.size() - 1);
        if (extra > 0) {
            LinearLayout row = new LinearLayout(this);
            if (extra == 1) {
                View gap = new View(this);
                row.addView(gap, new LinearLayout.LayoutParams(0, 1, 1));   // ارتفاع صريح: View العادي بـ wrap يملأ كل المساحة المتاحة
            }
            for (int i = 1; i <= extra; i++) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
                lp.setMargins(i == 1 && extra == 2 ? 0 : dp(10), 0, 0, 0);
                row.addView(matchTile(top.get(i)), lp);
            }
            matchCard.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    private View matchTile(Football.M x) {
        boolean live = Football.live(x.st);
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(14), dp(10), dp(14), dp(10));
        t.setGravity(Gravity.RIGHT); t.setPadding(dp(6), dp(4), dp(6), dp(4)); // بلا خلفية
        TextView lg = cardGlow(text(10, live ? LIVE : 0xFFE9C46A), false);
        lg.setLetterSpacing(0.14f); lg.setSingleLine(true); lg.setEllipsize(android.text.TextUtils.TruncateAt.END);
        lg.setText(x.league.toUpperCase(Locale.getDefault()));
        TextView main = cardGlow(text(14, TEXT), false); main.setTypeface(Fonts.bold(this)); main.setGravity(Gravity.CENTER);
        main.setMaxLines(2); main.setEllipsize(android.text.TextUtils.TruncateAt.END);
        main.setText(x.home + " v " + x.away);
        LinearLayout teams = new LinearLayout(this); teams.setGravity(Gravity.CENTER_VERTICAL); teams.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        ImageView homeCrest = matchLogo(x.homeLogo, 24), awayCrest = matchLogo(x.awayLogo, 24);
        LinearLayout.LayoutParams crestLp = new LinearLayout.LayoutParams(dp(32), dp(32)); crestLp.setMargins(0, 0, 0, 0);
        teams.addView(homeCrest, crestLp); teams.addView(main, new LinearLayout.LayoutParams(0, -2, 1)); teams.addView(awayCrest, crestLp);
        TextView st = cardGlow(text(11, live ? LIVE : DIM), false); st.setGravity(Gravity.RIGHT);
        st.setText(x.hg >= 0 && x.ag >= 0 ? x.hg + " – " + x.ag + (live ? "  " + Football.shortStatus(x) : "") : Football.statusText(this, x));
        st.setSingleLine(true); st.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.addView(lg); t.addView(teams); t.addView(st);
        return t;
    }

    private ImageView matchLogo(String url, int sizeDp) {
        CrestView image = new CrestView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setPadding(dp(5), dp(5), dp(5), dp(5));     // هامش يتسع لانتشار الظل حول الشعار
        Football.loadLogo(this, url, image);
        return image;
    }

    /** شعار بظل ناعم يتبع شكله الفعلي (لا دائرة خلفه): يبقى الشعار متمركزًا وواضحًا فوق أي خلفية أو صورة. */
    private static class CrestView extends ImageView {
        private Bitmap shadow; private int sx, sy;
        private final Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
        CrestView(Context c) { super(c); sp.setColor(0xB3000000); }
        @Override public void setImageBitmap(Bitmap bm) {
            super.setImageBitmap(bm); shadow = null;
            if (bm == null || bm.isRecycled()) return;
            try {
                float r = Math.max(2f, Math.max(bm.getWidth(), bm.getHeight()) * 0.06f);
                Paint blur = new Paint(); blur.setMaskFilter(new BlurMaskFilter(r, BlurMaskFilter.Blur.NORMAL));
                int[] off = new int[2];
                shadow = bm.extractAlpha(blur, off);
                sx = off[0]; sy = off[1] + Math.round(r * 0.35f);
            } catch (Throwable ignored) { shadow = null; }
        }
        @Override protected void onDraw(Canvas c) {
            if (shadow != null && getDrawable() != null && getImageMatrix() != null) {
                c.save(); c.translate(getPaddingLeft(), getPaddingTop()); c.concat(getImageMatrix());
                c.drawBitmap(shadow, sx, sy, sp); c.restore();
            }
            super.onDraw(c);
        }
    }

    /** نص بطاقة (الصلاة/المباريات): حدّ أسود رقيق + ظل منزاح ناعم كما في PowerPoint، فيبقى واضحًا فوق أي خلفية. */
    private TextView cardText(TextView t) {
        if (t instanceof OutlineText) ((OutlineText) t).setOutline(dp(1) * 1.4f, 0xE6000000);
        t.setShadowLayer(dp(3), dp(1), dp(2), 0xAA000000);
        return t;
    }
    private TextView cardGlow(TextView t, boolean bold) {
        if (bold) t.setTypeface(Fonts.bold(this));
        return cardText(t);
    }

    /** نص فوق الخلفية بلا إطار: ظل قوي + خط عريض اختياريًا. */
    private TextView glow(TextView t, boolean bold) {
        if (bold) t.setTypeface(Fonts.bold(this));
        t.setShadowLayer(14, 0, 2, 0xCC000000);
        return t;
    }

    /** عرض الساعة = أعرض رقم × 4 + النقطتان (+ ص/م عند نظام 12 ساعة): يلاصق التاريخ الساعة دون فراغ زائد ودون قص. */

    /** يمنع تراكب أزرار أعلى اليمين (راديو/واي فاي/…) مع التاريخ: يقصّ اسم الشبكة حسب المساحة المتاحة. */
    private void fitPills() {
        if (topPills == null || datesBox == null || wifiText == null || topPills.getWidth() == 0 || datesBox.getWidth() == 0) return;
        int cap = dp(240);
        // اسم الشبكة يظهر كاملاً دائماً (حتى 240dp): نثبّت حدّه الأدنى على عرضه الطبيعي ولا نقصّه أبداً لإفساح المكان
        int natural = Math.round(wifiText.getPaint().measureText(wifiText.getText().toString()))
                + wifiText.getPaddingLeft() + wifiText.getPaddingRight() + dp(6);
        int minW = Math.min(cap, Math.max(natural, dp(56)));
        if (wifiText.getMaxWidth() != cap) wifiText.setMaxWidth(cap);
        if (wifiText.getMinWidth() != minW) wifiText.setMinWidth(minW);

        int[] a = new int[2], b = new int[2];
        datesBox.getLocationOnScreen(a); topPills.getLocationOnScreen(b);
        int dateRight = a[0] + datesBox.getWidth();
        int overlap = dateRight + dp(24) - b[0];         // > 0 : يوجد تراكب
        if (overlap > 0) {
            // التراكب يُحلّ بتضييق التاريخ فيلتفّ على سطرين، لا بقصّ اسم الشبكة
            int w = Math.max(date.getWidth(), hijriDate.getWidth());
            int nd = Math.max(dp(140), w - overlap);
            if (nd < w) { date.setMaxWidth(nd); hijriDate.setMaxWidth(nd); }
        } else if (-overlap > dp(70) && date.getMaxWidth() != Integer.MAX_VALUE) {   // مساحة فائضة: توسيع تدريجي
            int nd = date.getMaxWidth() + (-overlap - dp(40));
            if (nd > dp(900)) nd = Integer.MAX_VALUE;
            date.setMaxWidth(nd); hijriDate.setMaxWidth(nd);
        }
    }

    private void fitClockWidth() {
        int cf = prefs.getInt("clock_fmt", 0);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(clock.getTypeface()); p.setTextSize(clock.getTextSize());
        float digit = 0;
        for (char ch = '0'; ch <= '9'; ch++) digit = Math.max(digit, p.measureText(String.valueOf(ch)));
        float w = digit * 4 + p.measureText(":");
        boolean ampm = cf == 1 || (cf == 0 && !android.text.format.DateFormat.is24HourFormat(this));
        if (ampm) {
            float m = 0;
            for (String t : new java.text.DateFormatSymbols(Locale.getDefault()).getAmPmStrings()) m = Math.max(m, p.measureText(" " + t));
            w += m;
        }
        clock.setMinWidth(Math.round(w) + dp(2));   // عرض أعرض رقم: لا يُقصّ 22:22 ولا 11:59 م، ويبقى التاريخ ثابتاً
    }

    private void refreshHeader() {
        greeting.setText(Greetings.pick(this, prefs, Calendar.getInstance()));
        Locale locale = Locale.getDefault();
        date.setText(LocaleHelper.westernDigits(new java.text.SimpleDateFormat("EEEE d MMMM", locale)
                .format(new Date()).toUpperCase(locale)));
        hijriDate.setText(LocaleHelper.westernDigits(Hijri.formatHeader(this)));

        String nn = netName();
        if (!nn.contentEquals(wifiText.getText())) {      // اسم جديد: نبدأ من أقصى عرض ثم نعيد الملاءمة
            wifiText.setText(nn); wifiText.setMaxWidth(dp(240));
            if (rootFrame != null) rootFrame.post(this::fitPills);
        }

        // الصلاة القادمة
        String[] names = {getString(R.string.fajr), null, PrayerInfo.dhuhrName(this), getString(R.string.asr),
                getString(R.string.maghrib), getString(R.string.isha)};
        Calendar now = Calendar.getInstance(PrayerTimes.TZ);
        prayerCity.setText(prefs.getString("city", getString(R.string.default_city)));
        double nowH = now.get(Calendar.HOUR_OF_DAY) + now.get(Calendar.MINUTE) / 60.0;
        double[] t = PrayerTimes.compute(now);
        int next = -1;
        for (int i = 0; i < 6; i++) if (names[i] != null && t[i] > nowH) { next = i; break; }
        boolean tomorrow = false;
        if (next < 0) {
            Calendar tm = (Calendar) now.clone(); tm.add(Calendar.DAY_OF_MONTH, 1);
            t = PrayerTimes.compute(tm); next = 0; tomorrow = true;
        }
        double diff = t[next] + (tomorrow ? 24 : 0) - nowH;
        int mins = (int) Math.round(diff * 60);
        prayerName.setText(names[next] + " : " + PrayerTimes.fmt(t[next]));
        String in = getString(R.string.in_time, mins / 60, mins % 60);
        prayerSub.setText(tomorrow ? getString(R.string.tomorrow) + " · " + in : in);
    }

    /** اسم الشبكة المتصل بها الجهاز (الواي فاي، أو Ethernet). */
    private String netName() {
        String fallback = getString(R.string.wifi);
        ssidOk = false;
        if (Build.VERSION.SDK_INT < 23) return fallback;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
            if (nc == null) return fallback;
            boolean wifi = nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
            if (!wifi && nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet";
            {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                WifiInfo wi = wm == null ? null : wm.getConnectionInfo();
                String ssid = wi == null ? null : wi.getSSID();
                if (ssid != null && ssid.length() > 1 && ssid.startsWith("\"") && ssid.endsWith("\"")) ssid = ssid.substring(1, ssid.length() - 1);
                if (ssid != null && !ssid.isEmpty() && !ssid.equals("<unknown ssid>") && !ssid.equals("0x")) { ssidOk = true; return ssid; }
            }
        } catch (Exception ignored) { }
        return fallback;
    }

    // ---------- الشريط الأسود: المفضلة + الأكثر استعمالاً. كل التطبيقات في قائمة تحته (تظهر بزر «أسفل») ----------
    private ScrollView appsScroll;
    private LinearLayout appsList, stack;
    private boolean dockExpanded = false;
    private int collapsedH = 0;
    private static final boolean UP_TO_BAR = false;  // false = «أعلى» يصعد صفاً واحداً (كالفيديو)؛ true = يقفز من أي صف إلى المفضلة
    private static final int PEEK_DP = 12;  // شريحة الصف التالي عند الطي كما في الفيديو (0 = صف المفضلة فقط)
    private android.animation.ValueAnimator heightAnim;

    private boolean isInside(View v, View ancestor) {
        while (v != null) { if (v == ancestor) return true; v = (v.getParent() instanceof View) ? (View) v.getParent() : null; }
        return false;
    }

    /** يفتح/يغلق قائمة التطبيقات تحت الشريط (حركة ناعمة: اللوحة تصعد وتظهر الصفوف تحتها). */
    // ===== نسخة الهاتف: لا يوجد دي-باد، فنضيف السحب العمودي لتوسيع الشريط وطيّه =====
    private GestureDetector touchGd;
    @Override public boolean dispatchTouchEvent(MotionEvent ev) {
        if (BuildConfig.PHONE) {
            if (touchGd == null) touchGd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                    if (a == null || Math.abs(vy) < 900 || Math.abs(vy) < Math.abs(vx) * 1.5f) return false;
                    if (vy < 0) setDockExpanded(true);                                                     // سحب للأعلى: توسيع
                    else if (appsScroll == null || appsScroll.getScrollY() == 0) setDockExpanded(false);   // سحب للأسفل: طيّ
                    return false;
                }
            });
            touchGd.onTouchEvent(ev);
        }
        return super.dispatchTouchEvent(ev);
    }

    private void setDockExpanded(boolean ex) {
        if (ex && appsList.getChildCount() == 0) return;
        if (ex == dockExpanded) return;
        dockExpanded = ex;
        for (final View card : new View[]{prayerCard, matchCard}) {
            card.animate().cancel();
            if (ex) {
                if (card.getVisibility() == View.VISIBLE) card.animate().alpha(0f).setDuration(160).withEndAction(() -> card.setVisibility(View.INVISIBLE)).start();
            } else {
                boolean wasHidden = card.getVisibility() != View.VISIBLE;
                applyVisibility();                                   // يعيد الظهور حسب الإعدادات
                if (wasHidden && card.getVisibility() == View.VISIBLE) { card.setAlpha(0f); card.animate().alpha(1f).setDuration(200).start(); }
                else card.setAlpha(1f);
            }
        }
        if (!ex) {                                           // الصعود إلى المفضلة: الشريط يهبط بسلاسة والتمرير يعود للأعلى معه
            animateHeight(collapsedH > 0 ? collapsedH : ViewGroup.LayoutParams.WRAP_CONTENT, true);
            return;
        }
        appsList.setVisibility(View.VISIBLE);
        int maxH = Math.round(getResources().getDisplayMetrics().heightPixels * 0.66f);
        int target = Math.min(stack.getHeight(), maxH);
        animateHeight(target > 0 ? target : ViewGroup.LayoutParams.WRAP_CONTENT, false);
    }

    private void animateHeight(int target, boolean collapse) {
        if (heightAnim != null) heightAnim.cancel();
        final ViewGroup.LayoutParams lp = appsScroll.getLayoutParams();
        if (target < 0 || lp.height < 0) {
            lp.height = target; appsScroll.setLayoutParams(lp);
            if (collapse) appsScroll.scrollTo(0, 0);
            return;
        }
        final int startScroll = appsScroll.getScrollY();
        heightAnim = android.animation.ValueAnimator.ofInt(lp.height, target);
        heightAnim.setDuration(pref("anim", true) ? 340 : 0);                 // حركة هادئة كالفيديو
        heightAnim.setInterpolator(new android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f));
        heightAnim.addUpdateListener(an -> {
            lp.height = (Integer) an.getAnimatedValue();
            if (collapse) appsScroll.scrollTo(0, Math.round(startScroll * (1f - an.getAnimatedFraction())));   // يعود للأعلى مع الطي
            appsScroll.setLayoutParams(lp);
        });
        heightAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator a) {
                if (collapse) { appsScroll.scrollTo(0, 0); if (PEEK_DP <= 0 && extraRows() == 0) appsList.setVisibility(View.INVISIBLE); }
            }
        });
        heightAnim.start();
    }

    // ---------- التنقل بالريموت بين عناصر الشاشة الرئيسية (حلقة شبه مربعة) ----------
    //   الواي فاي ←  بطاقة الصلاة   |   بطاقة الصلاة ↔ المباريات   |   الأعلى من البطاقتين ↑ الأزرار
    //   من المفضلة: يسار الشاشة ↑ الصلاة، يمينها ↑ المباريات.  بطاقة الصلاة لا ترجع للواي فاي إلا بـ «أعلى».
    private boolean usable(View v) { return v != null && v.getVisibility() == View.VISIBLE && v.isFocusable() && v.getWidth() > 0; }

    private int centerX(View v) { int[] xy = new int[2]; v.getLocationOnScreen(xy); return xy[0] + v.getWidth() / 2; }

    /** أقرب عنصر من القائمة أفقيًا إلى مركز المصدر. */
    private View nearestX(View from, List<View> candidates) {
        View best = null; int bd = Integer.MAX_VALUE, fx = centerX(from);
        for (View c : candidates) {
            if (!usable(c)) continue;
            int d = Math.abs(centerX(c) - fx);
            if (d < bd) { bd = d; best = c; }
        }
        return best;
    }

    private View barTileNear(View from) {
        if (dock == null || dock.getVisibility() != View.VISIBLE || dock.getChildCount() == 0) return null;
        ViewGroup bar = (ViewGroup) dock.getChildAt(0);
        List<View> tiles = new ArrayList<>();
        for (int i = 0; i < bar.getChildCount(); i++) tiles.add(bar.getChildAt(i));
        return nearestX(from, tiles);
    }

    private View pillNear(View from) { return nearestX(from, Arrays.asList(radioPill, wifiPill, searchPill, settingsPill)); }

    /** يعيد الهدف المطلوب، أو null ليتصرف النظام بشكل افتراضي. */
    private View homeNavTarget(View f, int k) {
        if (f == null || prayerPanel != null || matchesPanel.isShowing() || dockExpanded) return null;
        boolean up = k == KeyEvent.KEYCODE_DPAD_UP, down = k == KeyEvent.KEYCODE_DPAD_DOWN,
                left = k == KeyEvent.KEYCODE_DPAD_LEFT, right = k == KeyEvent.KEYCODE_DPAD_RIGHT;
        if (!(up || down || left || right)) return null;
        View prayer = usable(prayerCard) ? prayerCard : null, matches = usable(matchCard) ? matchCard : null;

        if (f == prayerCard) {
            if (right) return matches != null ? matches : f;
            if (left) return f;                                   // لا شيء يسار البطاقة
            if (up) { if (usable(weatherPill)) return weatherPill; View p = pillNear(f); return p != null ? p : f; }
            if (down) return barTileNear(f);
        } else if (f == weatherPill) {                        // سطر الطقس: تحته الصلاة، يمينه/أعلاه الأزرار
            if (down) return prayer != null ? prayer : f;
            if (up || right) { View p = pillNear(f); return p != null ? p : f; }
            return f;
        } else if (f == matchCard) {
            if (left) return prayer != null ? prayer : f;
            if (right) return f;
            if (up) { View p = pillNear(f); return p != null ? p : f; }
            if (down) return barTileNear(f);
        } else if (f == radioPill || f == wifiPill || f == searchPill || f == settingsPill) {
            View[] pills = {radioPill, wifiPill, searchPill, settingsPill};
            View leftmost = null; for (View v : pills) if (usable(v)) { leftmost = v; break; }
            if (left && f == leftmost) { View t = usable(weatherPill) ? weatherPill : prayer; if (t != null) return t; }   // أول زر يسارًا ← الطقس (إن ظهر) وإلا بطاقة الصلاة
            if (down) return matches != null ? matches : prayer;           // نزولاً: بطاقة المباريات (يمين) ثم الصلاة
            if (up) return f;
        } else if (up && dock != null && dock.getChildCount() > 0 && isInside(f, dock.getChildAt(0))) {
            // من المفضلة صعودًا: الأقرب أفقيًا من البطاقتين (يسار → الصلاة، يمين → المباريات)
            int fx = centerX(f);
            if (prayer != null && matches != null)
                return Math.abs(centerX(prayer) - fx) <= Math.abs(centerX(matches) - fx) ? prayer : matches;
            return prayer != null ? prayer : matches;
        }
        return null;
    }

    private int adhanSwallow = -1;
    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) idleReset();
        // أثناء الأذان وبقاء اللانشر في الواجهة: OK أو رجوع يوقفانه فقط (ونبتلع الضغطة)
        int kc0 = e.getKeyCode();
        if (adhanSwallow == kc0) { if (e.getAction() == KeyEvent.ACTION_UP) adhanSwallow = -1; return true; }
        if (AdhanService.active && e.getAction() == KeyEvent.ACTION_DOWN
                && (kc0 == KeyEvent.KEYCODE_BACK || kc0 == KeyEvent.KEYCODE_DPAD_CENTER || kc0 == KeyEvent.KEYCODE_ENTER)) {
            adhanSwallow = kc0; Adhan.stop(this); return true;
        }
        if (dock != null && e.getAction() == KeyEvent.ACTION_DOWN) {
            View target = homeNavTarget(getCurrentFocus(), e.getKeyCode());
            if (target != null) { if (target != getCurrentFocus()) target.requestFocus(); return true; }
            int k = e.getKeyCode();
            if (!dockExpanded && k == KeyEvent.KEYCODE_DPAD_DOWN && appsList.getChildCount() > 0 && isInside(getCurrentFocus(), dock)) {
                View f = getCurrentFocus();
                ViewGroup row0 = (ViewGroup) dock.getChildAt(0);
                View tile = f; while (tile != null && tile.getParent() != row0) tile = (tile.getParent() instanceof View) ? (View) tile.getParent() : null;
                final int pos = tile == null ? 0 : row0.indexOfChild(tile);
                setDockExpanded(true);
                appsList.post(() -> {
                    ViewGroup rr = (ViewGroup) appsList.getChildAt(0);
                    if (rr != null && rr.getChildCount() > 0) rr.getChildAt(Math.min(pos, rr.getChildCount() - 1)).requestFocus();
                });
                return true;
            }
            if (dockExpanded && k == KeyEvent.KEYCODE_DPAD_UP && isInside(getCurrentFocus(), appsList)) {
                View f = getCurrentFocus();
                View row = f;
                while (row != null && row.getParent() != appsList) row = (row.getParent() instanceof View) ? (View) row.getParent() : null;
                View tl = f;
                while (tl != null && row != null && tl.getParent() != row) tl = (tl.getParent() instanceof View) ? (View) tl.getParent() : null;
                int pos = (row instanceof ViewGroup && tl != null) ? ((ViewGroup) row).indexOfChild(tl) : 0;   // نفس العمود
                ViewGroup bar = dock.getChildCount() > 0 ? (ViewGroup) dock.getChildAt(0) : null;
                boolean firstRow = row != null && appsList.indexOfChild(row) == 0;   // الصف الأول تحت المفضلة فقط يصعد إلى الشريط
                if ((UP_TO_BAR || firstRow) && bar != null && bar.getChildCount() > 0) {
                    setDockExpanded(false);                       // الطي أولاً ثم التركيز: لا إطار وسيط ولا ضغطة ثانية
                    bar.getChildAt(Math.min(Math.max(pos, 0), bar.getChildCount() - 1)).requestFocus();
                    return true;
                }
            }
            if (dockExpanded && (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_ESCAPE)) {
                setDockExpanded(false);
                View first = dock.getChildCount() > 0 ? ((ViewGroup) dock.getChildAt(0)).getChildAt(0) : null;
                if (first != null) first.requestFocus();
                return true;
            }
        }
        boolean r = super.dispatchKeyEvent(e);
        if (dockExpanded && e.getAction() == KeyEvent.ACTION_DOWN && !isInside(getCurrentFocus(), appsList)) setDockExpanded(false);
        return r;
    }

    private String sortName() {
        int[] ids = {R.string.sort_az, R.string.sort_most, R.string.sort_recent, R.string.sort_new};
        return getString(ids[Math.max(0, Math.min(3, prefs.getInt("apps_sort", 0)))]);
    }

    private int extraRows() { return Math.max(0, Math.min(3, prefs.getInt("extra_rows", 0))); }
    private int perRow() { return Math.max(4, Math.min(7, prefs.getInt("apps_per_row", 5))); }

    private static int orderIdx(List<String> ord, String pkg) { int i = ord.indexOf(pkg); return i < 0 ? Integer.MAX_VALUE : i; }

    /** يحسب التوزيع المعروض: row0 = الشريط الأول، rest = بقية التطبيقات (تُقسَّم لاحقاً إلى صفوف من n). */
    private void computeLayout(int n, List<App> row0, List<App> rest) {
        boolean manual = prefs.getBoolean("manual_layout", false);
        List<App> bar = new ArrayList<>();
        for (String pkg : favorites()) { App a = find(pkg); if (a != null && !isHidden(pkg) && !bar.contains(a)) bar.add(a); }
        if (!manual) {
            List<App> freq = new ArrayList<>();
            for (App a : apps) if (!isFav(a.pkg) && !isHidden(a.pkg) && prefs.getInt("cnt_" + a.pkg, 0) >= 3) freq.add(a);
            Collections.sort(freq, (x, y) -> prefs.getInt("cnt_" + y.pkg, 0) - prefs.getInt("cnt_" + x.pkg, 0));
            for (int i = 0; i < Math.min(4, freq.size()); i++) bar.add(freq.get(i));
        }
        row0.addAll(bar.subList(0, Math.min(n, bar.size())));
        List<App> r = new ArrayList<>();
        for (App a : apps) if (!isHidden(a.pkg) && !row0.contains(a)) r.add(a);
        r = sortedApps(r);
        if (manual) {
            final List<String> ord = new ArrayList<>();
            String v = prefs.getString("rest_order", "");
            if (!v.isEmpty()) ord.addAll(Arrays.asList(v.split(",")));
            Collections.sort(r, (x, y) -> Integer.compare(orderIdx(ord, x.pkg), orderIdx(ord, y.pkg)));   // مستقر: الجديد يبقى بترتيب الفرز
        }
        rest.addAll(r);
    }

    private static List<String> pkgs(List<App> l) { List<String> o = new ArrayList<>(); for (App a : l) o.add(a.pkg); return o; }

    /** مكان التطبيق في الشبكة المعروضة: {صف، عمود} (الصف 0 = الشريط) أو null. */
    private int[] appCell(String pkg) {
        int n = perRow();
        List<App> row0 = new ArrayList<>(), rest = new ArrayList<>();
        computeLayout(n, row0, rest);
        int i = pkgs(row0).indexOf(pkg);
        if (i >= 0) return new int[]{0, i};
        i = pkgs(rest).indexOf(pkg);
        return i < 0 ? null : new int[]{1 + i / n, i % n};
    }

    /** ينقل التطبيق خانة واحدة: dx = يسار/يمين، dy = أعلى/أسفل (صف كامل). يتحوّل الترتيب إلى يدوي ويُحفظ. */
    private boolean moveApp(String pkg, int dx, int dy) {
        int n = perRow();
        List<App> r0 = new ArrayList<>(), rs = new ArrayList<>();
        computeLayout(n, r0, rs);
        List<String> row0 = pkgs(r0), rest = pkgs(rs);
        boolean changed = false;
        int i0 = row0.indexOf(pkg), ir = rest.indexOf(pkg);
        if (i0 >= 0) {                                              // التطبيق في الشريط
            if (dx != 0) {
                int j = i0 + dx;
                if (j >= 0 && j < row0.size()) { Collections.swap(row0, i0, j); changed = true; }
            } else if (dy > 0 && !rest.isEmpty()) {
                if (i0 < rest.size()) { String o = rest.get(i0); rest.set(i0, pkg); row0.set(i0, o); }
                else { row0.remove(i0); rest.add(pkg); }
                changed = true;
            }
        } else if (ir >= 0) {                                       // التطبيق في الصفوف السفلية
            if (dx != 0) {
                int j = ir + dx;
                if (j >= 0 && j < rest.size()) { Collections.swap(rest, ir, j); changed = true; }
            } else if (dy < 0) {
                if (ir >= n) { Collections.swap(rest, ir, ir - n); changed = true; }
                else {                                              // الصف الأول تحت الشريط: يصعد إلى الشريط
                    if (ir < row0.size()) { String o = row0.get(ir); row0.set(ir, pkg); rest.set(ir, o); changed = true; }
                    else if (row0.size() < n) { rest.remove(ir); row0.add(pkg); changed = true; }
                }
            } else if (dy > 0) {
                int j = Math.min(ir + n, rest.size() - 1);
                if (j != ir) { Collections.swap(rest, ir, j); changed = true; }
            }
        }
        if (!changed) return false;
        List<String> favs = new ArrayList<>(row0);
        for (String f : favorites()) if (!favs.contains(f) && !rest.contains(f)) favs.add(f);   // المفضلة المخفية تبقى محفوظة
        prefs.edit().putString("favs", android.text.TextUtils.join(",", favs))
                .putString("rest_order", android.text.TextUtils.join(",", rest))
                .putBoolean("manual_layout", true).apply();
        refreshDock();
        return true;
    }

    /** نافذة «نقل التطبيق»: أسهم الريموت (أو الأزرار على الشاشة) تحرّك التطبيق يساراً/يميناً/أعلى/أسفل؛ OK للإنهاء. */
    private void showMover(final App a) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(24), dp(18), dp(24), dp(16));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(0xFF0F1B2D); bg.setCornerRadius(dp(24)); bg.setStroke(dp(2), 0xFF2E5C80);
        box.setBackground(bg);
        TextView title = text(22, TEXT); title.setTypeface(Typeface.DEFAULT_BOLD); title.setText(a.label); title.setGravity(Gravity.CENTER);
        TextView pos = text(16, ACCENT); pos.setGravity(Gravity.CENTER); pos.setPadding(0, dp(6), 0, dp(2));
        TextView hint = text(14, DIM); hint.setGravity(Gravity.CENTER); hint.setText(R.string.move_hint); hint.setPadding(0, 0, 0, dp(10));
        box.addView(title); box.addView(pos); box.addView(hint);

        final Runnable upd = () -> {
            int[] c = appCell(a.pkg);
            if (c != null) pos.setText(getString(R.string.move_pos, c[0] + 1, c[1] + 1));
        };
        upd.run();
        final int[][] dirs = {{0, -1}, {-1, 0}, {1, 0}, {0, 1}};          // أعلى، يسار، يمين، أسفل: {dx, dy}
        final String[] arrows = {"▲", "◀", "▶", "▼"};
        LinearLayout rUp = new LinearLayout(this), rMid = new LinearLayout(this), rDown = new LinearLayout(this);
        for (LinearLayout r : new LinearLayout[]{rUp, rMid, rDown}) { r.setGravity(Gravity.CENTER); box.addView(r, new LinearLayout.LayoutParams(-2, -2)); }
        View[] btn = new View[4];
        for (int k = 0; k < 4; k++) {
            final int[] dv = dirs[k];
            TextView t = text(26, TEXT); t.setText(arrows[k]); t.setGravity(Gravity.CENTER);
            t.setFocusable(true); t.setClickable(true);
            t.setBackground(menuRowBg(false));
            t.setOnFocusChangeListener((v, f) -> v.setBackground(menuRowBg(f)));
            t.setOnClickListener(v -> { moveApp(a.pkg, dv[0], dv[1]); upd.run(); });
            btn[k] = t;
        }
        int bw = dp(72), bh = dp(56), m = dp(4);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(bw, bh); lp.setMargins(m, m, m, m);
        rUp.addView(btn[0], lp);
        rMid.addView(btn[1], lp);
        TextView ok = text(18, TEXT); ok.setText("OK"); ok.setGravity(Gravity.CENTER);
        ok.setFocusable(true); ok.setClickable(true); ok.setBackground(menuRowBg(false));
        ok.setOnFocusChangeListener((v, f) -> v.setBackground(menuRowBg(f)));
        ok.setOnClickListener(v -> d.dismiss());
        LinearLayout.LayoutParams lpOk = new LinearLayout.LayoutParams(bw, bh); lpOk.setMargins(m, m, m, m);
        rMid.addView(ok, lpOk);
        rMid.addView(btn[2], lp);
        rDown.addView(btn[3], lp);
        // ريموت التلفاز: الأسهم تنقل التطبيق مباشرة (بدل تحريك التركيز)، وOK/رجوع ينهيان
        d.setOnKeyListener((dlg, code, ev) -> {
            int dx = 0, dy = 0;
            if (code == KeyEvent.KEYCODE_DPAD_LEFT) dx = -1;
            else if (code == KeyEvent.KEYCODE_DPAD_RIGHT) dx = 1;
            else if (code == KeyEvent.KEYCODE_DPAD_UP) dy = -1;
            else if (code == KeyEvent.KEYCODE_DPAD_DOWN) dy = 1;
            else return false;
            if (ev.getAction() == KeyEvent.ACTION_DOWN) { moveApp(a.pkg, dx, dy); upd.run(); }
            return true;
        });
        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels - dp(32), dp(420)), ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            w.getAttributes().y = dp(60);
            w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);       // بلا تعتيم: نرى الشريط وهو يتحرك
        }
        d.show();
        ok.requestFocus();
    }

    private List<App> sortedApps(List<App> list) {
        final int mode = prefs.getInt("apps_sort", 0);
        List<App> all = new ArrayList<>(list);
        if (mode == 1) Collections.sort(all, (x, y) -> prefs.getInt("cnt_" + y.pkg, 0) - prefs.getInt("cnt_" + x.pkg, 0));
        else if (mode == 2) Collections.sort(all, (x, y) -> Long.compare(prefs.getLong("last_" + y.pkg, 0), prefs.getLong("last_" + x.pkg, 0)));
        else if (mode == 3) {
            final Map<String, Long> inst = new HashMap<>();
            for (App a : all) { try { inst.put(a.pkg, getPackageManager().getPackageInfo(a.pkg, 0).firstInstallTime); } catch (Exception e) { inst.put(a.pkg, 0L); } }
            Collections.sort(all, (x, y) -> Long.compare(inst.get(y.pkg), inst.get(x.pkg)));
        }
        return all;
    }

    private void refreshDock() {
        if (heightAnim != null) heightAnim.cancel();
        dock.removeAllViews();
        appsList.removeAllViews();
        int n = Math.max(4, Math.min(7, prefs.getInt("apps_per_row", 5)));
        // قياسات من الفيديو: الفراغ الأفقي ≈ 18% من عرض البطاقة، والعمودي بين الصفوف ≈ 50% من ارتفاعها
        int pitch = (screenDp() - 80 - 20) / n;
        int tw = Math.round(pitch / 1.18f);
        int th = Math.max(64, Math.round(tw * 0.56f));
        rowGx = Math.max(4, Math.round((pitch - tw) / 2f));
        rowGy = Math.round(th * 0.25f);
        int rowW = n * pitch;

        // الشريط: المفضلة المختارة ثم الأكثر استعمالاً (إلا في الترتيب اليدوي)، بحد أقصى صف واحد؛ ثم باقي التطبيقات في صفوف تحته
        List<App> row0 = new ArrayList<>(), rest = new ArrayList<>();
        computeLayout(n, row0, rest);

        if (!row0.isEmpty()) dock.addView(dockRow(row0, tw, th, true));
        ViewGroup.LayoutParams dlp = dock.getLayoutParams(); dlp.width = dp(rowW + 20); dock.setLayoutParams(dlp);
        for (int from = 0; from < rest.size(); from += n)
            appsList.addView(dockRow(rest.subList(from, Math.min(rest.size(), from + n)), tw, th, false));
        LinearLayout.LayoutParams alp1 = (LinearLayout.LayoutParams) appsList.getLayoutParams();
        alp1.topMargin = dp(rowGy);                    // + هامش الصف الأول = الفراغ بين الشريط الأسود والصفوف
        ViewGroup.LayoutParams alp = appsList.getLayoutParams(); alp.width = dp(rowW + 20); appsList.setLayoutParams(alp);
        appsList.setPadding(dp(10), 0, dp(10), 0);

        dockExpanded = false;
        dock.setVisibility(dock.getChildCount() > 0 ? View.VISIBLE : View.GONE);
        selTitle.setVisibility(Background.flag(this, "vis_title") ? View.VISIBLE : View.GONE);

        // الحالة المطوية: الشريط + شريحة صغيرة من الصف التالي (كما في التصميم المطلوب)
        final boolean hasRows = appsList.getChildCount() > 0;
        ViewGroup.LayoutParams vlp = appsScroll.getLayoutParams();
        vlp.height = ViewGroup.LayoutParams.WRAP_CONTENT; appsScroll.setLayoutParams(vlp);
        appsScroll.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override public void onGlobalLayout() {
                if (dock.getBottom() <= 0) return;                      // لم يكتمل القياس بعد
                appsScroll.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                appsScroll.scrollTo(0, 0);
                if (hasRows) {
                    // «صفوف تحت المفضلة» (0–3): تبقى ظاهرة كاملة في الحالة المطوية، ثم شريحة من الصف التالي إن وُجد صف آخر
                    int shown = Math.min(extraRows(), appsList.getChildCount());
                    int base = shown > 0 ? appsList.getTop() + appsList.getChildAt(shown - 1).getBottom() : dock.getBottom();
                    boolean more = appsList.getChildCount() > shown;
                    collapsedH = base + dp(8) + (more && PEEK_DP > 0 ? dp(2 * rowGy) + dp(PEEK_DP) : 0);
                    appsList.setVisibility((PEEK_DP > 0 || shown > 0) ? View.VISIBLE : View.INVISIBLE);   // مخفية = لا رسم ولا تركيز = بلا لاغ
                    ViewGroup.LayoutParams l2 = appsScroll.getLayoutParams(); l2.height = collapsedH; appsScroll.setLayoutParams(l2);
                } else collapsedH = stack.getHeight();
            }
        });
        if (dock.getChildCount() > 0 && getCurrentFocus() == null) {
            View first = ((ViewGroup) dock.getChildAt(0)).getChildAt(0);
            if (first != null) first.requestFocus();
        }
    }

    private int screenDp() {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        return Math.round(dm.widthPixels / dm.density);
    }

    private LinearLayout dockRow(List<App> items, int tw, int th, boolean inBar) {
        LinearLayout r = new LinearLayout(this);
        r.setClipChildren(false); r.setClipToPadding(false);
        for (App a : items) {
            View t = tile(a, tw, th, true, inBar);
            t.setOnClickListener(v -> launch(a));
            t.setOnLongClickListener(v -> { showAppMenu(a, null); return true; });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(tw), dp(th));
            int vy = inBar ? 6 : rowGy;                    // داخل الشريط الأسود هامش صغير، وبين الصفوف هامش أكبر
            p.setMargins(dp(rowGx), dp(vy), dp(rowGx), dp(vy));
            r.addView(t, p);
        }
        return r;
    }

    // ---------- لوحة مواقيت الصلاة (طبقة داخل الشاشة الرئيسية) ----------
    private void showPrayerPanel() {
        if (prayerPanel != null) return;
        if (prefs.getInt("prayer_style", 1) == 1) { startActivity(new Intent(this, MosqueBoardActivity.class)); return; }
        prayerPanel = PrayerPanel.show(this, this::buildPrayerPanelData, () -> prayerPanel = null);
    }

    private void hidePrayerPanel() {
        if (prayerPanel == null) return;
        prayerPanel.dismiss();
        prayerPanel = null;
        if (prayerCard != null) prayerCard.requestFocus();
    }

    private PrayerPanel.PageData buildPrayerPanelData() {
        Calendar now = Calendar.getInstance(PrayerTimes.TZ);
        double nowH = now.get(Calendar.HOUR_OF_DAY) + now.get(Calendar.MINUTE) / 60.0;
        double[] times = PrayerTimes.compute(now);
        String[] names = {getString(R.string.fajr), getString(R.string.sunrise), PrayerInfo.dhuhrName(this),
                getString(R.string.asr), getString(R.string.maghrib), getString(R.string.isha)};
        String[] icons = {"\uD83C\uDF19", "\uD83C\uDF05", "\u2600", "\uD83C\uDF24", "\uD83C\uDF07", "\uD83C\uDF0C"};

        // Sunrise is shown in the cards, but is not one of the five prayers.
        int next = -1;
        for (int i = 0; i < times.length; i++) {
            if (i != 1 && times[i] > nowH) { next = i; break; }
        }
        int nextPrayer = next;
        double nextTime;
        if (next >= 0) {
            nextTime = times[next];
        } else {
            nextPrayer = 0;
            Calendar tomorrow = (Calendar) now.clone();
            tomorrow.add(Calendar.DAY_OF_MONTH, 1);
            nextTime = PrayerTimes.compute(tomorrow)[0] + 24.0;
        }
        int minutes = Math.max(0, (int) Math.round((nextTime - nowH) * 60));
        String countdown = getString(R.string.prayer_countdown, names[nextPrayer],
                getString(R.string.in_time, minutes / 60, minutes % 60));

        List<PrayerPanel.PrayerItem> items = new ArrayList<>();
        for (int i = 0; i < times.length; i++) {
            items.add(new PrayerPanel.PrayerItem(names[i], PrayerTimes.fmt(times[i]), icons[i], i == nextPrayer));
        }
        String city = prefs.getString("city", getString(R.string.default_city));
        java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("EEEE d MMMM", Locale.getDefault());
        dateFormat.setTimeZone(PrayerTimes.TZ);
        String dateText = city + " \u00b7 " + dateFormat.format(now.getTime());
        String methodName = "";
        String[] methods = getResources().getStringArray(R.array.method_names);
        for (int i = 0; i < PrayerTimes.TABLE.length; i++) {
            if ((int) PrayerTimes.TABLE[i][0] == PrayerTimes.METHOD && i < methods.length) {
                methodName = methods[i];
                break;
            }
        }
        String methodText = methodName.isEmpty() ? "" : getString(R.string.prayer_method_line, methodName);
        return new PrayerPanel.PageData(dateText, Hijri.formatHeader(this), countdown, methodText, items);
    }
    // ---------- القائمة والمكتبة ----------
    private void showMenu(View anchor) {
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF2101C2E); bg.setCornerRadius(dp(22)); bg.setStroke(dp(2), 0xFF3C5A78);
        list.setBackground(bg);
        final android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        final int menuW = Math.round(dm.widthPixels * (18.5f / 70.8f));    // العرض 18.5 سم
        final int menuH = Math.round(dm.heightPixels * (26f / 39.8f));    // الارتفاع 26 سم
        final int vpad = Math.round(dm.heightPixels * 0.011f);
        final PopupWindow pw = new PopupWindow(list, menuW, menuH, true);
        pw.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        // الترتيب: اللغة · إعدادات اللانشر · التطبيقات (3 أزرار) · الصلاة · الطقس · المباريات · إعدادات التلفاز
        int[] labels = {R.string.menu_launcher_settings, R.string.menu_prayer, R.string.ls_weather_section,
                R.string.matches, R.string.tv_settings};
        Paint mp = new Paint(); mp.setTypeface(Fonts.outfit(this)); mp.setTextSize(100f);
        float maxW = 1f; for (int id : labels) maxW = Math.max(maxW, mp.measureText(getString(id)));
        float avail = menuW - dp(6) * 2 - dp(12) * 2 - dp(4) - dp(8);
        final float menuTxt = Math.min(dm.heightPixels * 0.04f, avail / maxW * 100f);
        final Intent svc = new Intent(this, LauncherSettingsActivity.class).putExtra("section", "services");
        final String curLang = prefs.getString("lang", "");
        final String[] codes = {"ar", "fr", "en"};

        // 1) اللغة: ثلاثة مربعات AR · FR · EN
        list.addView(menuBlock(chipsRow(getString(R.string.language), new String[]{"AR", "FR", "EN"},
                new boolean[]{"ar".equals(curLang), "fr".equals(curLang), "en".equals(curLang)},
                new Runnable[]{
                    () -> setLang(codes[0]), () -> setLang(codes[1]), () -> setLang(codes[2])}, menuTxt, pw)));
        // 2) إعدادات اللانشر
        View first = menuRow(getString(R.string.menu_launcher_settings), menuTxt, pw,
                () -> open(new Intent(this, LauncherSettingsActivity.class)));
        list.addView(first);
        // 3) التطبيقات: مكتبة · ترتيب · بحث في صف واحد
        list.addView(menuBlock(chipsRow(getString(R.string.menu_apps),
                new String[]{getString(R.string.apps_short_lib), getString(R.string.apps_short_sort), getString(R.string.apps_short_search)},
                new boolean[]{false, false, false},
                new Runnable[]{this::showLibrary, this::showReorder, this::showSearch}, menuTxt, pw)));
        // 4) البطاقات خارج الإعدادات: الصلاة · الطقس · المباريات
        list.addView(menuRow(getString(R.string.menu_prayer), menuTxt, pw, this::showPrayerPanel));
        list.addView(menuRow(getString(R.string.ls_weather_section), menuTxt, pw, () -> {
            if (WeatherRepository.enabled(this)) weatherPanel.show(WeatherRepository.cached(this)); else open(svc);
        }));
        list.addView(menuRow(getString(R.string.matches), menuTxt, pw, () -> {
            if (Football.hasKey(this)) matchesPanel.show(); else open(svc);
        }));
        // 5) إعدادات التلفاز
        list.addView(menuRow(getString(R.string.tv_settings), menuTxt, pw, () -> open(new Intent(Settings.ACTION_SETTINGS))));
        pw.showAsDropDown(anchor, anchor.getWidth() - menuW, dp(6));
        final View f0 = first;
        list.post(() -> f0.requestFocus());
    }

    private void setLang(String code) {
        if (code.equals(prefs.getString("lang", ""))) return;
        prefs.edit().putString("lang", code).apply();
        recreate();                                       // يعيد بناء الواجهة بالغة الجديدة
    }

    /** يجعل الصف يتمدّد ليتوزع على ارتفاع القائمة مثل بقية البنود. */
    private View menuBlock(View v) {
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, 0, 1f); rlp.bottomMargin = dp(3);
        v.setLayoutParams(rlp);
        return v;
    }

    private View menuRow(String label, float txt, final PopupWindow pw, final Runnable act) {
        View row = textRow(label, null, false, () -> { pw.dismiss(); act.run(); }, null);
        TextView rt = (TextView) ((LinearLayout) row).getChildAt(0);
        rt.setPadding(dp(4), 0, 0, 0);
        rt.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, txt);
        row.setPadding(dp(12), 0, dp(12), 0);
        return menuBlock(row);
    }

    /** صف بعنوان صغير وتحته مربعات متساوية العرض (اللغة، التطبيقات). */
    private View chipsRow(String title, String[] names, boolean[] sel, Runnable[] acts, float txt, final PopupWindow pw) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setBackground(rowBg(false));
        r.setPadding(dp(12), dp(4), dp(12), dp(4));
        TextView t = text(14, DIM); t.setText(title);
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, txt * 0.62f);
        r.addView(t);
        LinearLayout cr = new LinearLayout(this); cr.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < names.length; i++) {
            final int idx = i; final boolean on = sel[i];
            final TextView b = libPill(names[i]);
            b.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, txt * 0.6f);
            b.setPadding(dp(3), dp(8), dp(3), dp(8)); b.setSingleLine(true); b.setEllipsize(android.text.TextUtils.TruncateAt.END);
            stylePill(b, on, false);
            b.setOnFocusChangeListener((x, f) -> stylePill(b, on, f));
            b.setOnClickListener(x -> { pw.dismiss(); acts[idx].run(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f); lp.setMargins(dp(3), dp(2), dp(3), dp(2));
            cr.addView(b, lp);
        }
        r.addView(cr, new LinearLayout.LayoutParams(-1, -2));
        return r;
    }

    private boolean isNewApp(App a, Set<String> seen) {
        if (seen.contains(a.pkg)) return false;
        try { return System.currentTimeMillis() - getPackageManager().getPackageInfo(a.pkg, 0).firstInstallTime < 7L * 86400000L; }
        catch (Exception e) { return false; }
    }

    /** مكتبة التطبيقات: لوحة زجاجية عائمة بصفّ أفقي (ضغطة = إضافة للرئيسية، ضغط مطوّل = خيارات). */
    /** وضع المكتبة الحالي: false = المفضلة (ضغطة = إضافة/إزالة من الرئيسية) · true = إظهار/إخفاء التطبيق. */
    private boolean libVisMode;

    private void stylePill(TextView b, boolean sel, boolean focus) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        g.setColor(focus ? 0x55FFFFFF : sel ? 0x663DA5D9 : 0x22FFFFFF);
        if (focus || sel) g.setStroke(dp(2), focus ? 0xFFEAF6FF : ACCENT);
        b.setBackground(g);
    }

    private TextView libPill(String label) {
        TextView b = text(13, TEXT);
        b.setText(label); b.setGravity(Gravity.CENTER); b.setPadding(dp(14), dp(6), dp(14), dp(6));
        b.setFocusable(true); b.setClickable(true);
        return b;
    }

    /** صف خيارات رقمية (مثل التطبيقات في كل صف) يحفظ في التفضيلات ويعيد رسم الرئيسية فورًا. */
    private View libOptionRow(String label, final String key, final int[] vals, final int def) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(0, dp(2), 0, dp(2));
        TextView l = text(13, TEXT); l.setText(label);
        r.addView(l, new LinearLayout.LayoutParams(dp(210), -2));
        final List<TextView> ps = new ArrayList<>();
        for (final int v : vals) {
            final TextView b = libPill(String.valueOf(v));
            ps.add(b);
            stylePill(b, prefs.getInt(key, def) == v, false);
            b.setOnFocusChangeListener((x, f) -> stylePill(b, prefs.getInt(key, def) == v, f));
            b.setOnClickListener(x -> {
                prefs.edit().putInt(key, v).apply();
                for (int i = 0; i < ps.size(); i++) stylePill(ps.get(i), prefs.getInt(key, def) == vals[i], ps.get(i).isFocused());
                refreshDock();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.setMargins(dp(4), 0, dp(4), 0);
            r.addView(b, lp);
        }
        return r;
    }

    private void showLibrary() {
        libVisMode = false;
        final Dialog d = new Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar);
        Window w = d.getWindow();
        w.setBackgroundDrawable(new ColorDrawable(0x00000000));
        w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND); w.setDimAmount(0.55f);
        w.setLayout(-1, -1);
        FrameLayout frame = new FrameLayout(this);
        frame.setOnClickListener(v -> d.dismiss());
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(14), dp(18), dp(14));
        GradientDrawable pb = new GradientDrawable(); pb.setColor(0xE61B1D24); pb.setCornerRadius(dp(18)); pb.setStroke(dp(1), 0x22FFFFFF);
        panel.setBackground(pb);

        Set<String> seen = new HashSet<>(Arrays.asList(prefs.getString("lib_seen", "").split(",")));
        final Set<String> newSet = new HashSet<>();
        for (App a : apps) if (!isHidden(a.pkg) && isNewApp(a, seen)) newSet.add(a.pkg);

        RelativeLayout head = new RelativeLayout(this);
        TextView title = text(16, TEXT); title.setTypeface(Fonts.bold(this)); title.setText(R.string.library);
        final TextView count = text(12, DIM);
        RelativeLayout.LayoutParams cl = new RelativeLayout.LayoutParams(-2, -2); cl.addRule(RelativeLayout.ALIGN_PARENT_END);
        head.addView(title); head.addView(count, cl);
        panel.addView(head);

        // تنظيم الرئيسية: التطبيقات في كل صف · صفوف تحت المفضلة
        LinearLayout ctl = new LinearLayout(this); ctl.setOrientation(LinearLayout.VERTICAL); ctl.setPadding(0, dp(8), 0, dp(2));
        ctl.addView(libOptionRow(getString(R.string.ls_apps_per_row), "apps_per_row", new int[]{4, 5, 6, 7}, 5));
        ctl.addView(libOptionRow(getString(R.string.ls_extra_rows), "extra_rows", new int[]{0, 1, 2, 3}, 0));
        panel.addView(ctl);

        // الترتيب + وضع المكتبة (مفضلة / إظهار-إخفاء)
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(0, dp(4), 0, dp(4));
        final TextView sortB = libPill(getString(R.string.sort_label) + " · " + sortName());
        stylePill(sortB, false, false);
        sortB.setOnFocusChangeListener((x, f) -> stylePill(sortB, false, f));
        sortB.setOnClickListener(x -> {
            prefs.edit().putInt("apps_sort", (prefs.getInt("apps_sort", 0) + 1) % 4).remove("manual_layout").remove("rest_order").apply();
            sortB.setText(getString(R.string.sort_label) + " · " + sortName());
            refreshDock();
        });
        final TextView favB = libPill(getString(R.string.lib_mode_fav)), visB = libPill(getString(R.string.lib_mode_vis));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2); bl.setMargins(0, 0, dp(18), 0);
        bar.addView(sortB, bl);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-2, -2); ml.setMargins(dp(4), 0, dp(4), 0);
        bar.addView(favB, ml); bar.addView(visB, ml);
        panel.addView(bar);

        final TextView hint = text(11, DIM); hint.setPadding(0, dp(3), 0, dp(10));
        panel.addView(hint);
        final LinearLayout row = new LinearLayout(this);
        row.setPadding(dp(4), dp(6), dp(4), dp(6)); row.setClipChildren(false); row.setClipToPadding(false);
        final HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false); hs.setClipChildren(false); hs.setClipToPadding(false); hs.addView(row);
        panel.addView(hs);

        final java.text.Collator col = java.text.Collator.getInstance();
        final Runnable fill = () -> {
            row.removeAllViews();
            List<App> list = new ArrayList<>();
            for (App a : apps) if (libVisMode || !isHidden(a.pkg)) list.add(a);
            Collections.sort(list, (x, y) -> {
                boolean nx = !libVisMode && newSet.contains(x.pkg), ny = !libVisMode && newSet.contains(y.pkg);
                return nx != ny ? (nx ? -1 : 1) : col.compare(x.label, y.label);
            });
            count.setText(getString(R.string.lib_count, list.size()));
            hint.setText(libVisMode ? R.string.lib_hint_vis : R.string.lib_hint2);
            for (App a : list) row.addView(libTile(a, !libVisMode && newSet.contains(a.pkg), d, libVisMode),
                    new LinearLayout.LayoutParams(dp(128), dp(132)) {{ setMargins(dp(6), 0, dp(6), 0); }});
            hs.scrollTo(0, 0);
        };
        final Runnable styleModes = () -> {
            stylePill(favB, !libVisMode, favB.isFocused());
            stylePill(visB, libVisMode, visB.isFocused());
        };
        favB.setOnFocusChangeListener((x, f) -> styleModes.run());
        visB.setOnFocusChangeListener((x, f) -> styleModes.run());
        favB.setOnClickListener(x -> { libVisMode = false; styleModes.run(); fill.run(); });
        visB.setOnClickListener(x -> { libVisMode = true; styleModes.run(); fill.run(); });
        styleModes.run();
        fill.run();

        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(Math.round(getResources().getDisplayMetrics().widthPixels * 0.78f), -2, Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        pl.bottomMargin = dp(120);
        frame.addView(panel, pl);
        d.setOnDismissListener(x -> {
            StringBuilder sb = new StringBuilder();
            for (App a : apps) sb.append(a.pkg).append(',');
            prefs.edit().putString("lib_seen", sb.toString()).apply();
        });
        d.setContentView(frame);
        d.show();
        if (row.getChildCount() > 0) row.getChildAt(0).requestFocus();
    }

    private View libTile(App a, boolean isNew, Dialog d, final boolean visMode) {
        FrameLayout t = new FrameLayout(this);
        t.setFocusable(true); t.setClickable(true);
        t.setBackground(round(0x26FFFFFF, 14, 0));
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER_HORIZONTAL); c.setPadding(dp(8), dp(12), dp(8), dp(8));
        ImageView iv = new ImageView(this); iv.setImageDrawable(a.icon); iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        c.addView(iv, new LinearLayout.LayoutParams(dp(a.banner ? 88 : 46), dp(a.banner ? 50 : 46)));
        TextView l = text(12, TEXT); l.setTypeface(Fonts.bold(this)); l.setText(a.label); l.setGravity(Gravity.CENTER);
        l.setMaxLines(2); l.setEllipsize(android.text.TextUtils.TruncateAt.END); l.setPadding(0, dp(8), 0, dp(2));
        TextView sub = text(9, DIM); sub.setGravity(Gravity.CENTER); sub.setMaxLines(2);
        c.addView(l); c.addView(sub);
        t.addView(c, new FrameLayout.LayoutParams(-1, -1));
        TextView badge = new TextView(this);
        badge.setGravity(Gravity.CENTER); badge.setTextColor(0xFF08111F); badge.setTextSize(9); badge.setTypeface(Typeface.DEFAULT_BOLD);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.TOP | Gravity.END); bp.setMargins(0, dp(7), dp(7), 0);
        t.addView(badge, bp);
        View ring = new View(this);
        GradientDrawable rg = new GradientDrawable(); rg.setColor(0); rg.setCornerRadius(dp(14)); rg.setStroke(dp(3), 0xFFEAF6FF);
        ring.setBackground(rg); ring.setVisibility(View.INVISIBLE);
        t.addView(ring, new FrameLayout.LayoutParams(-1, -1));
        Runnable bind = () -> {
            GradientDrawable bg = new GradientDrawable(); bg.setShape(GradientDrawable.OVAL); bg.setColor(0xFF3DDC84);
            badge.setBackground(bg);
            ViewGroup.LayoutParams q = badge.getLayoutParams();
            if (visMode) {                                   // وضع الإظهار/الإخفاء: علامة ✓ للظاهر، والمخفي يُعتَّم
                boolean hidden = isHidden(a.pkg);
                t.setAlpha(hidden ? 0.45f : 1f);
                sub.setText(hidden ? R.string.lib_hidden : R.string.lib_visible);
                badge.setText("✓"); badge.setVisibility(hidden ? View.INVISIBLE : View.VISIBLE);
                q.width = dp(16); q.height = dp(16); badge.setLayoutParams(q);
                return;
            }
            boolean on = isFav(a.pkg);
            sub.setText(on ? R.string.lib_on : (isNew ? R.string.lib_new_add : R.string.lib_add));
            badge.setText(on ? "✓" : ""); badge.setVisibility(on || isNew ? View.VISIBLE : View.INVISIBLE);
            if (!on && isNew) { q.width = dp(8); q.height = dp(8); } else { q.width = dp(16); q.height = dp(16); }
            badge.setLayoutParams(q);
        };
        bind.run();
        t.setOnFocusChangeListener((v, f) -> {
            ring.setVisibility(f ? View.VISIBLE : View.INVISIBLE);
            float sc = (f && pref("effects", true)) ? 1.06f : 1f;
            v.animate().scaleX(sc).scaleY(sc).setDuration(pref("anim", true) ? 140 : 0).start();
        });
        t.setOnClickListener(v -> {
            if (visMode) {
                toggleHidden(a.pkg); refreshDock(); bind.run();
                Toast.makeText(this, (isHidden(a.pkg) ? "☐ " : "☑ ") + a.label, Toast.LENGTH_SHORT).show();
            } else {
                toggleFav(a); refreshDock(); bind.run();
                Toast.makeText(this, (isFav(a.pkg) ? "★ " : "☆ ") + a.label, Toast.LENGTH_SHORT).show();
            }
        });
        t.setOnLongClickListener(v -> { showAppMenu(a, () -> d.dismiss()); return true; });
        return t;
    }

    // ---------- قائمة الضغطة المطوّلة على أي تطبيق (عادي أو نظام) ----------
    private boolean isSystemApp(String pkg) {
        try { return (getPackageManager().getApplicationInfo(pkg, 0).flags & ApplicationInfo.FLAG_SYSTEM) != 0; }
        catch (Exception e) { return false; }
    }

    /** إعادة تسمية تطبيق (تُحفظ محلياً؛ تركه فارغاً يعيد الاسم الأصلي). */
    private void showRename(final App a) {
        final EditText et = new EditText(this);
        et.setSingleLine(true); et.setText(a.label); et.setSelection(et.getText().length());
        new android.app.AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(R.string.app_rename).setView(et)
                .setPositiveButton(android.R.string.ok, (di, w) -> {
                    String n = et.getText().toString().trim();
                    if (n.isEmpty()) prefs.edit().remove("ren_" + a.pkg).apply();
                    else prefs.edit().putString("ren_" + a.pkg, n).apply();
                    loadApps(); refreshDock();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    /** onLeave: يُنفَّذ قبل مغادرة الشاشة الحالية (مثل إغلاق مكتبة التطبيقات) عند فتح التطبيق/معلوماته/نقله/إخفائه/حذفه. */
    private void showAppMenu(final App a, final Runnable onLeave) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(10));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(0xFF0F1B2D); bg.setCornerRadius(dp(24)); bg.setStroke(dp(2), 0xFF2E5C80);
        box.setBackground(bg);
        TextView title = text(22, TEXT); title.setTypeface(Typeface.DEFAULT_BOLD); title.setText(a.label);
        title.setPadding(dp(14), dp(6), dp(14), dp(12));
        box.addView(title);

        final List<String> labels = new ArrayList<>();
        final List<Runnable> acts = new ArrayList<>();
        labels.add(getString(R.string.app_open));
        acts.add(() -> { if (onLeave != null) onLeave.run(); launch(a); });
        labels.add(getString(R.string.app_info));
        acts.add(() -> {
            if (onLeave != null) onLeave.run();
            open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + a.pkg)));
        });
        labels.add(getString(R.string.app_hide));
        acts.add(() -> { toggleHidden(a.pkg); if (onLeave != null) onLeave.run(); refreshDock(); });
        labels.add(getString(R.string.app_move));
        acts.add(() -> { if (onLeave != null) onLeave.run(); showMover(a); });
        labels.add(getString(R.string.app_rename));
        acts.add(() -> { if (onLeave != null) onLeave.run(); showRename(a); });
        if (!isSystemApp(a.pkg)) {                       // تطبيقات النظام لا تُحذف: يختفي الخيار فقط
            labels.add(getString(R.string.app_uninstall));
            acts.add(() -> {
                if (onLeave != null) onLeave.run();
                open(new Intent(Intent.ACTION_DELETE, android.net.Uri.parse("package:" + a.pkg)));
            });
        }
        labels.add(getString(R.string.cancel));
        acts.add(null);

        View first = null;
        for (int i = 0; i < labels.size(); i++) {
            final Runnable act = acts.get(i);
            TextView t = text(19, TEXT); t.setText(labels.get(i));
            t.setPadding(dp(14), dp(14), dp(14), dp(14));
            t.setFocusable(true); t.setClickable(true);
            t.setBackground(menuRowBg(false));
            t.setOnFocusChangeListener((v, f) -> v.setBackground(menuRowBg(f)));
            t.setOnClickListener(v -> { d.dismiss(); if (act != null) act.run(); });
            box.addView(t, new LinearLayout.LayoutParams(-1, -2));
            if (first == null) first = t;
        }
        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int sw = getResources().getDisplayMetrics().widthPixels;
            w.setLayout(Math.min(sw - dp(32), dp(560)), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        d.show();
        if (first != null) first.requestFocus();
    }

    private GradientDrawable menuRowBg(boolean focused) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(focused ? 0xFF1B4560 : Color.TRANSPARENT);
        if (focused) g.setStroke(dp(2), ACCENT);
        return g;
    }

    // ---------- أدوات الإخفاء والترتيب ----------
    private Set<String> hiddenSet() {
        Set<String> set = new LinkedHashSet<>();
        String v = prefs.getString("hidden", "");
        if (!v.isEmpty()) set.addAll(Arrays.asList(v.split(",")));
        return set;
    }
    private boolean isHidden(String pkg) { return hiddenSet().contains(pkg); }
    private void toggleHidden(String pkg) {
        Set<String> set = hiddenSet();
        if (!set.remove(pkg)) set.add(pkg);
        prefs.edit().putString("hidden", android.text.TextUtils.join(",", set)).apply();
    }
    private void saveFavs(List<String> l) { prefs.edit().putString("favs", android.text.TextUtils.join(",", l)).apply(); }

    private GradientDrawable rowBg(boolean f) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(14)); g.setColor(f ? 0xFF1B4560 : 0xFF11213A);
        g.setStroke(dp(f ? 3 : 1), f ? ACCENT : 0x55FFFFFF);
        return g;
    }

    private View textRow(String label, Drawable icon, boolean banner, Runnable click, Runnable longClick) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(16), dp(10), dp(16), dp(10));
        r.setFocusable(true); r.setClickable(true);
        r.setBackground(rowBg(false));
        if (icon != null) {
            ImageView iv = new ImageView(this); iv.setImageDrawable(icon);
            r.addView(iv, new LinearLayout.LayoutParams(dp(banner ? 78 : 44), dp(44)));
        }
        TextView l = text(20, TEXT); l.setText(label); l.setPadding(dp(icon != null ? 16 : 0), 0, 0, 0);
        r.addView(l, new LinearLayout.LayoutParams(0, -2, 1));
        r.setOnFocusChangeListener((v, f) -> v.setBackground(rowBg(f)));
        if (click != null) r.setOnClickListener(v -> click.run());
        if (longClick != null) r.setOnLongClickListener(v -> { longClick.run(); return true; });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(6);
        r.setLayoutParams(lp);
        return r;
    }

    private Dialog shell(String title, String hint, View body) {
        Dialog d = new Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(40), dp(28), dp(40), dp(20));
        box.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF08111F, 0xFF12384F}));
        TextView t = text(30, TEXT); t.setText(title); box.addView(t);
        if (hint != null) { TextView h = text(14, DIM); h.setText(hint); h.setPadding(0, dp(4), 0, dp(12)); box.addView(h); }
        box.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        d.setContentView(box);
        return d;
    }

    // ---------- بحث عن تطبيقات ----------
    private void showSearch() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        EditText et = new EditText(this);
        et.setHint(R.string.search_apps_hint); et.setHintTextColor(DIM); et.setTextColor(TEXT);
        et.setSingleLine(true); et.setTypeface(Fonts.outfit(this));
        LinearLayout results = new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this); sv.addView(results);
        body.addView(et); body.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        Dialog d = shell(getString(R.string.search_apps), null, body);
        Runnable fill = () -> {
            results.removeAllViews();
            String q = et.getText().toString().trim().toLowerCase();
            for (App a : apps) {
                if (isHidden(a.pkg) || (!q.isEmpty() && !a.label.toLowerCase().contains(q))) continue;
                results.addView(textRow(a.label, a.icon, a.banner, () -> { d.dismiss(); launch(a); }, null));
            }
        };
        et.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int n) { }
            @Override public void onTextChanged(CharSequence c, int a, int b, int n) { }
            @Override public void afterTextChanged(android.text.Editable e) { fill.run(); }
        });
        fill.run();
        d.show();
    }

    // ---------- ترتيب المفضلة ----------
    private void showReorder() { showReorder(null); }

    private void showReorder(String focusPkg) {
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this); sv.addView(list);
        Dialog d = shell(getString(R.string.reorganize), getString(R.string.reorder_hint), sv);
        int fi = 0;
        if (focusPkg != null) {
            int n = 0;
            for (String pkg : favorites()) if (find(pkg) != null && !isHidden(pkg)) { if (pkg.equals(focusPkg)) fi = n; n++; }
        }
        fillReorder(list, fi);
        d.show();
    }

    private void fillReorder(LinearLayout list, int focus) {
        list.removeAllViews();
        List<String> shown = new ArrayList<>();
        for (String pkg : favorites()) if (find(pkg) != null && !isHidden(pkg)) shown.add(pkg);
        for (int i = 0; i < shown.size(); i++) {
            final int idx = i;
            App a = find(shown.get(i));
            list.addView(textRow((i + 1) + ".  " + a.label, a.icon, a.banner,
                    () -> { moveFav(shown, idx, idx - 1); fillReorder(list, Math.max(0, idx - 1)); },
                    () -> { moveFav(shown, idx, idx + 1); fillReorder(list, Math.min(shown.size() - 1, idx + 1)); }));
        }
        if (focus >= 0 && focus < list.getChildCount()) list.getChildAt(focus).requestFocus();
    }

    private void moveFav(List<String> shown, int i, int j) {
        if (j < 0 || j >= shown.size()) return;
        Collections.swap(shown, i, j);
        List<String> all = new ArrayList<>(shown);
        for (String pkg : favorites()) if (!all.contains(pkg)) all.add(pkg);   // المخفية تبقى في آخر القائمة
        saveFavs(all);
        refreshDock();
    }

    // ---------- حول · الدعم ----------
    private String langName(String code) {
        if ("ar".equals(code)) return "العربية";
        if ("fr".equals(code)) return "Français";
        if ("en".equals(code)) return "English";
        return getString(R.string.lang_system);
    }

    private void showLanguage() {
        final String[] codes = {"", "ar", "fr", "en"};
        final String cur = prefs.getString("lang", "");
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        final Dialog[] dd = new Dialog[1];
        View first = null;
        for (int i = 0; i < codes.length; i++) {
            final String code = codes[i];
            View r = textRow(langName(code) + (code.equals(cur) ? "   ✓" : ""), null, false, () -> {
                prefs.edit().putString("lang", code).apply();
                dd[0].dismiss();
                recreate();                                   // يعيد بناء الواجهة بالغة الجديدة
            }, null);
            list.addView(r);
            if (first == null || code.equals(cur)) first = r;
        }
        dd[0] = shell(getString(R.string.language), null, list);
        dd[0].show();
        if (first != null) first.requestFocus();
    }

    private void showAbout() {
        String ver = "1.0";
        try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) { }
        TextView t = text(18, TEXT); t.setLineSpacing(0, 1.25f);
        t.setText(getString(R.string.about_text, getString(R.string.app_name), ver));
        t.setFocusable(true);
        t.setPadding(0, dp(12), 0, 0);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        final Dialog[] dd = new Dialog[1];
        box.addView(t);
        ScrollView sv = new ScrollView(this); sv.addView(box);
        dd[0] = shell(getString(R.string.about_support), null, sv);
        dd[0].show();
        t.requestFocus();
    }

    // ---------- رسائل الترحيب ----------
    private String periodName(int p) {
        int[] ids = {R.string.gp0, R.string.gp1, R.string.gp2, R.string.gp3, R.string.gp4};
        return getString(ids[Math.max(0, Math.min(4, p))]);
    }
    private String greetLangName(String l) { return l.isEmpty() ? getString(R.string.gl0) : langName(l); }

    private void showGreetings() {
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this); sv.addView(list);
        Dialog d = shell(getString(R.string.greet_title), getString(R.string.greet_hint, Greetings.MAX, Greetings.MAX_LEN), sv);
        d.setOnDismissListener(x -> refreshHeader());
        fillGreetings(list, 0);
        d.show();
    }

    private void fillGreetings(final LinearLayout list, int focus) {
        list.removeAllViews();
        list.addView(textRow(getString(R.string.greet_add_kb), null, false, () -> showGreetEditor(-1, () -> fillGreetings(list, 0)), null));
        list.addView(textRow(getString(R.string.greet_add_qr), null, false, () -> showGreetQr(() -> fillGreetings(list, 1)), null));
        final boolean defOn = prefs.getBoolean(Greetings.KEY_DEF, true);
        list.addView(textRow(getString(R.string.greet_defaults_fmt, getString(defOn ? R.string.on : R.string.off)), null, false,
                () -> { prefs.edit().putBoolean(Greetings.KEY_DEF, !defOn).apply(); fillGreetings(list, 2); }, null));
        TextView note = text(12, DIM);
        note.setText(R.string.greet_defaults_note);
        note.setPadding(dp(16), dp(2), dp(16), dp(10));
        list.addView(note);
        final List<Greetings.Msg> msgs = Greetings.load(prefs);
        if (msgs.isEmpty()) {
            TextView none = text(14, DIM); none.setText(R.string.greet_none); none.setPadding(dp(16), dp(6), dp(16), dp(6));
            list.addView(none);
        }
        for (int i = 0; i < msgs.size(); i++) {
            final int idx = i;
            Greetings.Msg m = msgs.get(i);
            String tag = periodName(m.period) + " · " + greetLangName(m.lang);
            list.addView(textRow("•  " + m.text + "    [" + tag + "]", null, false,
                    () -> showGreetOptions(idx, () -> fillGreetings(list, 4 + Math.max(0, idx - 1))), null));
        }
        int n = Math.max(0, Math.min(focus, list.getChildCount() - 1));
        if (list.getChildAt(n) != null) list.getChildAt(n).requestFocus();
    }

    private void showGreetOptions(final int idx, final Runnable after) {
        final List<Greetings.Msg> all = Greetings.load(prefs);
        if (idx < 0 || idx >= all.size()) { after.run(); return; }
        new android.app.AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(all.get(idx).text)
                .setItems(new String[]{getString(R.string.greet_edit), getString(R.string.greet_delete)}, (di, which) -> {
                    if (which == 0) showGreetEditor(idx, after);
                    else { all.remove(idx); Greetings.save(prefs, all); after.run(); }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    /** إضافة/تعديل رسالة بلوحة المفاتيح. idx = -1 للإضافة. الوقت واللغة بزرّين يتبدّلان بـ OK. */
    private void showGreetEditor(final int idx, final Runnable after) {
        final List<Greetings.Msg> all = Greetings.load(prefs);
        final Greetings.Msg cur = idx >= 0 && idx < all.size() ? all.get(idx) : new Greetings.Msg("", 0, "");
        final int[] per = {cur.period};
        final String[] langs = {"", "ar", "fr", "en"};
        final int[] li = {Math.max(0, Arrays.asList(langs).indexOf(cur.lang))};
        final Dialog d = new Dialog(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(28), dp(24), dp(28), dp(20));
        box.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF08111F, 0xFF12384F}));
        TextView title = text(24, TEXT); title.setText(R.string.greet_edit_title); title.setTypeface(Fonts.bold(this));
        final EditText et = new EditText(this);
        et.setHint(R.string.greet_text_hint); et.setHintTextColor(DIM); et.setTextColor(TEXT);
        et.setSingleLine(true); et.setText(cur.text);
        et.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(Greetings.MAX_LEN)});
        final TextView perB = libPill(getString(R.string.greet_period_fmt, periodName(per[0])));
        final TextView langB = libPill(getString(R.string.greet_lang_fmt, greetLangName(langs[li[0]])));
        for (final TextView b : new TextView[]{perB, langB}) {
            stylePill(b, false, false);
            b.setOnFocusChangeListener((x, f) -> stylePill(b, false, f));
        }
        perB.setOnClickListener(x -> { per[0] = (per[0] + 1) % 5; perB.setText(getString(R.string.greet_period_fmt, periodName(per[0]))); });
        langB.setOnClickListener(x -> { li[0] = (li[0] + 1) % langs.length; langB.setText(getString(R.string.greet_lang_fmt, greetLangName(langs[li[0]]))); });
        TextView note = text(12, DIM); note.setText(R.string.greet_lang_note); note.setPadding(0, dp(6), 0, dp(8));
        Button save = new Button(this); save.setText(R.string.greet_save);
        Button cancel = new Button(this); cancel.setText(R.string.cancel);
        cancel.setOnClickListener(x -> d.dismiss());
        save.setOnClickListener(x -> {
            String txt = Greetings.clean(et.getText().toString());
            if (txt == null) { Toast.makeText(this, R.string.greet_empty, Toast.LENGTH_SHORT).show(); return; }
            Greetings.Msg m = new Greetings.Msg(txt, per[0], langs[li[0]]);
            List<Greetings.Msg> l = Greetings.load(prefs);
            if (idx >= 0 && idx < l.size()) l.set(idx, m);
            else if (l.size() >= Greetings.MAX) { Toast.makeText(this, getString(R.string.greet_full, Greetings.MAX), Toast.LENGTH_SHORT).show(); return; }
            else l.add(m);
            Greetings.save(prefs, l);
            d.dismiss(); after.run();
        });
        LinearLayout btns = new LinearLayout(this); btns.setGravity(Gravity.END); btns.addView(cancel); btns.addView(save);
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(-2, -2); pl.setMargins(0, dp(8), 0, 0);
        box.addView(title); box.addView(et); box.addView(perB, pl); box.addView(langB, pl); box.addView(note); box.addView(btns);
        d.setContentView(box);
        d.show();
        et.requestFocus();
    }

    /** إضافة رسائل من الهاتف: صفحة بسيطة (نص + وقت + لغة). تبقى النافذة مفتوحة لإضافة عدة رسائل. */
    private void showGreetQr(final Runnable onChange) {
        String ip = UploadServer.localIp();
        if (ip == null) { Toast.makeText(this, R.string.up_noip, Toast.LENGTH_LONG).show(); return; }
        final UploadServer srv;
        try {
            srv = new UploadServer(new java.io.File(getCacheDir(), "up"), tmp -> {
                String raw;
                try (java.io.FileInputStream in = new java.io.FileInputStream(tmp)) {
                    java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                    byte[] buf = new byte[512]; int n;
                    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    raw = bo.toString("UTF-8");
                } catch (Exception e) { return false; }
                String[] f = raw.split("\\|", 3);
                if (f.length < 3) return false;
                int per;
                try { per = Integer.parseInt(f[0].trim()); } catch (Exception e) { return false; }
                String lang = f[1].trim();
                String txt = Greetings.clean(f[2]);
                if (txt == null || per < 0 || per > 4 || !(lang.isEmpty() || lang.equals("ar") || lang.equals("fr") || lang.equals("en"))) return false;
                if (!Greetings.add(prefs, new Greetings.Msg(txt, per, lang))) return false;
                runOnUiThread(() -> { Toast.makeText(this, R.string.greet_saved, Toast.LENGTH_SHORT).show(); onChange.run(); });
                return true;
            });
        } catch (java.io.IOException e) { Toast.makeText(this, R.string.save_failed, Toast.LENGTH_SHORT).show(); return; }
        srv.setMessageMode();
        srv.start();
        String url = "http://" + ip + ":" + srv.port() + "/" + srv.code;
        boolean[][] m = QrCode.encode(url);
        int n = m.length, q = 4, sc = Math.max(4, dp(300) / (n + 2 * q));
        Bitmap bm = Bitmap.createBitmap((n + 2 * q) * sc, (n + 2 * q) * sc, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bm); cv.drawColor(Color.WHITE);
        Paint pt = new Paint(); pt.setColor(Color.BLACK);
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
            if (m[y][x]) cv.drawRect((x + q) * sc, (y + q) * sc, (x + q + 1) * sc, (y + q + 1) * sc, pt);
        ImageView iv = new ImageView(this); iv.setImageBitmap(bm);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(28), dp(20), dp(28), dp(20));
        box.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF08111F, 0xFF12384F}));
        TextView title = text(24, TEXT); title.setTypeface(Fonts.bold(this)); title.setText(R.string.greet_qr_title); title.setGravity(Gravity.CENTER);
        TextView link = text(16, ACCENT); link.setText(url); link.setPadding(0, dp(10), 0, dp(4));
        TextView note = text(14, DIM); note.setText(R.string.up_note); note.setGravity(Gravity.CENTER);
        box.addView(title); box.addView(iv); box.addView(link); box.addView(note);
        Dialog d = new Dialog(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        d.setContentView(box);
        d.setOnDismissListener(x -> srv.stop());
        d.show();
    }

    // ---------- طريقة حساب الصلاة ----------
    private void showMethodDialog() {
        Dialog d = new Dialog(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(20), dp(24), dp(16));
        box.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF08111F, 0xFF12384F}));
        TextView title = text(24, TEXT); title.setText(R.string.calc_method); title.setTypeface(Fonts.bold(this));
        title.setPadding(0, 0, 0, dp(10));
        RadioGroup g = new RadioGroup(this);
        View selected = null;
        for (int i = 0; i < PrayerTimes.TABLE.length; i++) {
            final int id = (int) PrayerTimes.TABLE[i][0];
            RadioButton rb = new RadioButton(this);
            rb.setText(id + " · " + getResources().getStringArray(R.array.method_names)[i]); rb.setTextColor(TEXT); rb.setTextSize(18);
            rb.setPadding(dp(12), dp(10), dp(12), dp(10));
            rb.setBackground(round(0xFF16243A, 12, 0));
            rb.setChecked(id == PrayerTimes.METHOD);
            rb.setOnFocusChangeListener((v, f) -> v.setBackground(round(f ? 0xFF1B4560 : 0xFF16243A, 12, f ? 3 : 0)));
            rb.setOnClickListener(v -> {
                PrayerTimes.METHOD = id;
                prefs.edit().putInt("method", id).apply();
                refreshHeader(); d.dismiss();
            });
            RadioGroup.LayoutParams lp = new RadioGroup.LayoutParams(-1, -2); lp.setMargins(0, dp(3), 0, dp(3));
            g.addView(rb, lp);
            if (id == PrayerTimes.METHOD) selected = rb;
        }
        ScrollView sv = new ScrollView(this); sv.addView(g);
        Button cancel = new Button(this); cancel.setText(R.string.cancel); cancel.setOnClickListener(v -> d.dismiss());
        LinearLayout btns = new LinearLayout(this); btns.setGravity(Gravity.END); btns.addView(cancel);
        box.addView(title);
        box.addView(sv, new LinearLayout.LayoutParams(dp(560), dp(330)));
        box.addView(btns);
        d.setContentView(box);
        d.show();
        if (selected != null) { final View s = selected; s.requestFocus(); sv.post(() -> sv.scrollTo(0, Math.max(0, s.getTop() - dp(120)))); }
    }

    // ---------- اختيار مدينة الصلاة (Open-Meteo Geocoding) ----------
    private void showCityDialog() {
        Dialog d = new Dialog(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(28), dp(24), dp(28), dp(20));
        box.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF08111F, 0xFF12384F}));
        TextView title = text(24, TEXT); title.setText(R.string.city_title); title.setTypeface(Fonts.bold(this));
        EditText et = new EditText(this);
        et.setHint(R.string.city_hint); et.setHintTextColor(DIM); et.setTextColor(TEXT);
        et.setSingleLine(true); et.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        TextView status = text(14, DIM); status.setPadding(0, dp(8), 0, dp(8));
        LinearLayout results = new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this); sv.addView(results);
        Button go = new Button(this); go.setText(R.string.search);
        Button cancel = new Button(this); cancel.setText(R.string.cancel);
        LinearLayout btns = new LinearLayout(this); btns.setGravity(Gravity.END);
        btns.addView(cancel); btns.addView(go);
        box.addView(title); box.addView(et); box.addView(status);
        box.addView(sv, new LinearLayout.LayoutParams(dp(560), dp(220)));
        box.addView(btns);

        Runnable search = () -> {
            String q = et.getText().toString().trim();
            if (q.isEmpty()) return;
            status.setText(R.string.searching); results.removeAllViews();
            new Thread(() -> {
                try {
                    URL u = new URL("https://geocoding-api.open-meteo.com/v1/search?count=8&format=json&language="
                            + Locale.getDefault().getLanguage() + "&name=" + URLEncoder.encode(q, "UTF-8"));
                    HttpURLConnection c = (HttpURLConnection) u.openConnection();
                    c.setConnectTimeout(8000); c.setReadTimeout(8000);
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                        String line; while ((line = r.readLine()) != null) sb.append(line);
                    }
                    JSONArray arr = new JSONObject(sb.toString()).optJSONArray("results");
                    runOnUiThread(() -> {
                        results.removeAllViews();
                        if (arr == null || arr.length() == 0) { status.setText(R.string.no_results); return; }
                        status.setText("");
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject o = arr.optJSONObject(i);
                            String label = o.optString("name") + (o.has("admin1") ? ", " + o.optString("admin1") : "")
                                    + (o.has("country") ? ", " + o.optString("country") : "");
                            Button b = new Button(this); b.setText(label); b.setAllCaps(false);
                            b.setOnClickListener(v -> {
                                prefs.edit().putString("city", label)
                                        .putString("lat", String.valueOf(o.optDouble("latitude")))
                                        .putString("lng", String.valueOf(o.optDouble("longitude")))
                                        .putString("tz", o.optString("timezone", "UTC")).apply();
                                PrayerTimes.LAT = o.optDouble("latitude");
                                PrayerTimes.LNG = o.optDouble("longitude");
                                PrayerTimes.TZ = TimeZone.getTimeZone(o.optString("timezone", "UTC"));
                                refreshHeader(); d.dismiss();
                            });
                            results.addView(b);
                        }
                        if (results.getChildCount() > 0) results.getChildAt(0).requestFocus();
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> status.setText(R.string.net_error));
                }
            }).start();
        };
        go.setOnClickListener(v -> search.run());
        cancel.setOnClickListener(v -> d.dismiss());
        et.setOnEditorActionListener((v, a, e) -> { search.run(); return true; });
        d.setContentView(box);
        d.show();
    }

    // ---------- التطبيقات والمفضلة ----------
    /** كتيّبات التلفاز، وضع العرض التجريبي، ومعالجات الإعداد الأولي: تُخفى من القائمة فقط ولا تُحذف. */
    private static boolean isClutter(String pkg) {
        String s = pkg.toLowerCase(Locale.ROOT);
        String[] k = {"retaildemo", "demomode", "storedemo", "emanual", "usermanual", "tvmanual", ".manual", "setupwraith", "setupwizard", "provision"};
        for (String x : k) if (s.contains(x)) return true;
        return false;
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Map<String, App> map = new LinkedHashMap<>();
        final boolean clutter = prefs.getBoolean("hide_clutter", false);
        for (String cat : new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER}) {
            for (ResolveInfo ri : pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(cat), 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || map.containsKey(pkg) || (clutter && isClutter(pkg))) continue;
                App a = new App(); a.pkg = pkg; a.label = prefs.getString("ren_" + pkg, String.valueOf(ri.loadLabel(pm)));
                Drawable ic = ri.activityInfo.loadBanner(pm);
                a.icon = ic != null ? ic : ri.loadIcon(pm);
                a.banner = ic != null;
                map.put(pkg, a);
            }
        }
        apps = new ArrayList<>(map.values());
        Collections.sort(apps, (x, y) -> x.label.compareToIgnoreCase(y.label));
    }

    private List<String> favorites() {
        String s = prefs.getString("favs", null);
        List<String> l = new ArrayList<>();
        if (s == null) { for (int i = 0; i < Math.min(4, apps.size()); i++) l.add(apps.get(i).pkg); }
        else if (!s.isEmpty()) l.addAll(Arrays.asList(s.split(",")));
        return l;
    }
    private boolean isFav(String pkg) { return favorites().contains(pkg); }
    private void toggleFav(App a) {
        List<String> l = favorites();
        if (!l.remove(a.pkg)) l.add(a.pkg);
        prefs.edit().putString("favs", android.text.TextUtils.join(",", l)).apply();
    }
    private App find(String pkg) { for (App a : apps) if (a.pkg.equals(pkg)) return a; return null; }

    private void launch(App a) {
        prefs.edit().putInt("cnt_" + a.pkg, prefs.getInt("cnt_" + a.pkg, 0) + 1).putLong("last_" + a.pkg, System.currentTimeMillis()).apply();
        PackageManager pm = getPackageManager();
        Intent i = pm.getLeanbackLaunchIntentForPackage(a.pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(a.pkg);
        if (i != null) open(i);
    }
    private void open(Intent i) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception e) { Toast.makeText(this, getString(R.string.open_failed), Toast.LENGTH_SHORT).show(); }
    }

    // ---------- عناصر مساعدة ----------
    private View tile(App a, int wDp, int hDp, boolean forDock, boolean inBar) {
        FrameLayout t = new FrameLayout(this);
        t.setFocusable(true); t.setClickable(true);
        t.setBackground(round(0xFF16243A, 16, 0));
        t.setClipToOutline(true);
        if (a.banner) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageDrawable(a.icon);
            t.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        } else {
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER);
            int s = Math.max(dp(32), Math.min(dp(56), dp(hDp) - dp(38)));
            ImageView iv = new ImageView(this); iv.setImageDrawable(a.icon);
            c.addView(iv, new LinearLayout.LayoutParams(s, s));
            TextView l = text(12, TEXT); l.setText(a.label); l.setGravity(Gravity.CENTER);
            l.setSingleLine(true);
            l.setPadding(dp(6), dp(4), dp(6), 0);
            c.addView(l);
            t.addView(c, new FrameLayout.LayoutParams(-1, -1));
        }
        View glass = new View(this);
        GradientDrawable glassBg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x55F2FAFF, 0x25C8E8FF});
        glassBg.setCornerRadius(dp(16));
        glassBg.setStroke(dp(1), 0x88FFFFFF);
        glass.setBackground(glassBg);
        glass.setAlpha(0f);
        glass.setVisibility(View.INVISIBLE);
        if (!forDock) t.addView(glass, new FrameLayout.LayoutParams(-1, -1));

        View glow = new View(this);
        GradientDrawable glowBg = new GradientDrawable();
        glowBg.setColor(0x00000000); glowBg.setCornerRadius(dp(16));
        glowBg.setStroke(dp(7), 0x77C9F0FF);
        glow.setBackground(glowBg); glow.setAlpha(0f); glow.setVisibility(View.INVISIBLE);
        if (!forDock) t.addView(glow, new FrameLayout.LayoutParams(-1, -1));

        View ring = new View(this);
        GradientDrawable rg = new GradientDrawable();
        rg.setColor(0x00000000); rg.setCornerRadius(dp(16)); rg.setStroke(dp(2), 0xFFFFFFFF);
        ring.setBackground(rg); ring.setVisibility(View.INVISIBLE);
        if (!forDock) t.addView(ring, new FrameLayout.LayoutParams(-1, -1));
        t.setOnFocusChangeListener((v, f) -> {
            if (forDock && focusGlass != null) {              // الإطار الزجاجي العائم ينزلق إلى هذه البطاقة
                boolean anim = pref("anim", true);
                if (f) focusGlass.focus(v, anim, inBar ? null : a.label); else focusGlass.release(v);   // خارج المفضلة: الاسم الكامل تحت الزجاج
                float s2 = (f && pref("effects", true)) ? FOCUS_SCALE : 1f;
                v.animate().cancel();
                v.animate().scaleX(s2).scaleY(s2).setDuration(anim ? 200 : 0)
                        .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
                v.setTranslationZ(f ? dp(10) : 0);
                if (f) {                                          // الاسم في الأعلى للمفضلة فقط
                    selTitle.setText(a.label);
                    selTitle.animate().cancel();
                    selTitle.animate().alpha(isInside(v, dock) ? 1f : 0f).setDuration(120).start();
                }
                return;
            }
            ring.setVisibility(f ? View.VISIBLE : View.INVISIBLE);
            glass.animate().cancel(); glow.animate().cancel();
            if (f) { glass.setVisibility(View.VISIBLE); glow.setVisibility(View.VISIBLE); }
            long duration = pref("anim", true) ? 190 : 0;
            glass.animate().alpha(f ? 1f : 0f).setDuration(duration).start();
            glow.animate().alpha(f ? 1f : 0f).setDuration(duration).withEndAction(() -> {
                if (!t.hasFocus()) { glass.setVisibility(View.INVISIBLE); glow.setVisibility(View.INVISIBLE); }
            }).start();
            float sc = (f && pref("effects", true)) ? 1.07f : 1f;
            v.animate().cancel();
            v.animate().scaleX(sc).scaleY(sc).setDuration(duration)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            v.setTranslationZ(f ? dp(10) : 0);          // يرفعه فوق الجيران دون تغيير ترتيب العناصر
            if (f && forDock) selTitle.setText(a.label);
        });
        return t;
    }

    /** خلفية سطر الطقس: كحلي داكن شبه معتم بإطار ذهبي (واضحة فوق أي خلفية)، وتزداد إضاءة عند التركيز. */
    private GradientDrawable wxBg(boolean f) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                f ? new int[]{0xE62A5CAA, 0xE6352C78} : new int[]{0xCC13305E, 0xCC1D2A5E});
        g.setCornerRadius(dp(18));
        g.setStroke(dp(f ? 3 : 1), f ? 0xFFFFE9A8 : 0x99E6BE5A);
        return g;
    }

    private GradientDrawable glass(boolean f) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(f ? 0x66FFFFFF : 0x30FFFFFF); g.setCornerRadius(dp(24));
        g.setStroke(dp(f ? 3 : 1), f ? 0xFFEAF6FF : 0x55FFFFFF);
        return g;
    }
    /** زر زجاجي: أيقونة (+ نص اختياري). بدون نص يصبح دائرة. */
    private View iconPill(int icon, String label, Runnable r) {
        LinearLayout v = new LinearLayout(this);
        v.setGravity(Gravity.CENTER); v.setOrientation(LinearLayout.HORIZONTAL);
        v.setPadding(dp(label == null ? 0 : 20), 0, dp(label == null ? 0 : 22), 0);
        ImageView iv = new ImageView(this); iv.setImageResource(icon);
        v.addView(iv, new LinearLayout.LayoutParams(dp(24), dp(24)));
        if (label != null) {
            TextView t = text(15, TEXT); t.setTypeface(Fonts.bold(this)); t.setText(label); t.setPadding(dp(9), 0, 0, 0);
            v.addView(t);
        }
        v.setFocusable(true); v.setClickable(true);
        v.setBackground(glass(false));
        v.setOnFocusChangeListener((x, f) -> x.setBackground(glass(f)));
        if (r != null) v.setOnClickListener(x -> r.run());
        return v;
    }
    private View pill(String label, Runnable r) {
        TextView v = text(15, TEXT); v.setText(label); v.setGravity(Gravity.CENTER);
        v.setPadding(dp(22), 0, dp(22), 0);
        v.setFocusable(true); v.setClickable(true);
        v.setBackground(glass(false));
        v.setOnFocusChangeListener((x, f) -> x.setBackground(glass(f)));
        if (r != null) v.setOnClickListener(x -> r.run());
        return v;
    }

    private TextView text(int sp, int color) {
        TextView t = new OutlineText(this); t.setTextSize(sp); t.setTextColor(color);
        t.setTypeface(Fonts.outfit(this)); t.setShadowLayer(6, 0, 1, 0x88000000);
        return t;
    }
    private GradientDrawable round(int color, int radiusDp, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), ACCENT);
        return g;
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
