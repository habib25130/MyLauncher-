package com.myfamily.launcher;

import android.app.Activity;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import java.util.*;
import org.json.*;

/** لوحة المباريات: طبقة فوق الشاشة الرئيسية (ليست تطبيقًا مستقلًا). */
class MatchesPanel {
    private static final int TEXT = Color.WHITE, DIM = 0xB3FFFFFF, ACCENT = 0xFF6FD8FF, LIVE = 0xFF5EE29A;
    private final Activity a;
    private final FrameLayout root;
    private View scrim;
    private LinearLayout list;
    private TextView sub, foot;
    private View detailLayer;

    MatchesPanel(Activity a, FrameLayout root) { this.a = a; this.root = root; }

    boolean isShowing() { return scrim != null; }

    void show() {
        if (scrim != null) return;
        FrameLayout sc = new FrameLayout(a);
        sc.setBackgroundColor(0xB3000000);
        sc.setClickable(true);
        sc.setOnClickListener(v -> hide());

        LinearLayout panel = new LinearLayout(a);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        panel.setPadding(dp(30), dp(22), dp(30), dp(18));
        panel.setBackground(round(0xF00B1626, 28, 0, 0));
        panel.setClickable(true);

        TextView title = text(28, TEXT, true); title.setText(R.string.matches);
        sub = text(14, DIM, false); sub.setPadding(0, dp(2), 0, dp(10));
        list = new LinearLayout(a); list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(a); sv.addView(list); sv.setVerticalScrollBarEnabled(false);
        foot = text(12, DIM, false); foot.setPadding(0, dp(8), 0, 0);

        LinearLayout btns = new LinearLayout(a);
        btns.setGravity(Gravity.END);
        TextView refresh = button(a.getString(R.string.refresh));
        TextView close = button(a.getString(R.string.close));
        refresh.setOnClickListener(v -> { Football.refresh(a, true, () -> { if (scrim != null) fill(); }); });
        close.setOnClickListener(v -> hide());
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(dp(150), -2); bl.setMarginStart(dp(10));
        btns.addView(refresh, bl); btns.addView(close, bl);

        panel.addView(title); panel.addView(sub);
        panel.addView(sv, new LinearLayout.LayoutParams(-1, dp(330)));
        panel.addView(foot); panel.addView(btns);

        sc.addView(panel, new FrameLayout.LayoutParams(dp(760), -2, Gravity.CENTER));
        root.addView(sc, new FrameLayout.LayoutParams(-1, -1));
        scrim = sc;
        lockBehind(true);
        fill();
        close.requestFocus();
        boolean old = System.currentTimeMillis() - Football.p(a).getLong("fb_time", 0) > 300000L;
        Football.refresh(a, old, () -> { if (scrim != null) fill(); });
    }

    void hide() {
        if (scrim == null) return;
        root.removeView(scrim);
        scrim = null;
        lockBehind(false);
    }

    /** يمنع التركيز من الخروج إلى ما خلف اللوحة. */
    private void lockBehind(boolean lock) {
        for (int i = 0; i < root.getChildCount(); i++) {
            View c = root.getChildAt(i);
            if (c != scrim && c instanceof ViewGroup)
                ((ViewGroup) c).setDescendantFocusability(lock ? ViewGroup.FOCUS_BLOCK_DESCENDANTS : ViewGroup.FOCUS_AFTER_DESCENDANTS);
        }
    }

    private void fill() {
        List<Football.M> ms = Football.cached(a);
        long t = Football.p(a).getLong("fb_time", 0);
        String when = t == 0 ? a.getString(R.string.not_updated) : a.getString(R.string.updated_at, new java.text.SimpleDateFormat("HH:mm", Locale.US).format(new Date(t)));
        sub.setText(a.getString(Football.p(a).getInt("fb_off", 0) == 1 ? R.string.matches_tomorrow : R.string.matches_today) + " · " + when);
        String rem = Football.p(a).getString("fb_remaining", "");
        foot.setText(rem.isEmpty() ? "" : a.getString(R.string.requests_left, rem));
        if (ms.isEmpty()) {
            if (list.getChildCount() > 0 && Football.hasKey(a)) {
                return; // حفظ العناصر الحالية ظاهرة بدلاً من تفريغ اللوحة أثناء ضغط الشبكة أو تحديث البيانات
            }
            list.removeAllViews();
            String err = Football.p(a).getString("fb_err", "");
            TextView e = text(18, DIM, false);
            e.setText(!Football.hasKey(a) ? a.getString(R.string.matches_no_key) : err.isEmpty() ? a.getString(R.string.no_matches_followed) : a.getString(R.string.update_failed_fmt, err));
            e.setPadding(dp(4), dp(20), dp(4), dp(20));
            list.addView(e);
            return;
        }
        list.removeAllViews();
        for (Football.M m : ms) list.addView(row(m));
    }

    private View row(Football.M m) {
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(14), dp(10), dp(14), dp(10));
        r.setFocusable(true);
        r.setBackground(round(0x00000000, 14, 0, 0));
        r.setOnFocusChangeListener((v, f) -> v.setBackground(round(f ? 0xFF1B4560 : 0x00000000, 14, f ? 2 : 0, ACCENT)));

        boolean isLive = Football.live(m.st);
        TextView st = text(18, isLive ? LIVE : DIM, true); st.setText(Football.shortStatus(m)); st.setGravity(Gravity.CENTER);
        r.addView(st, new LinearLayout.LayoutParams(dp(78), -2));

        LinearLayout col = new LinearLayout(a); col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout leagueRow = new LinearLayout(a); leagueRow.setGravity(Gravity.CENTER_VERTICAL);
        ImageView leagueLogo = logo(m.leagueLogo, 18);
        TextView lg = text(12, DIM, false); lg.setText(m.league); lg.setSingleLine(true); lg.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(18), dp(18)); logoLp.setMarginEnd(dp(6));
        leagueRow.addView(leagueLogo, logoLp); leagueRow.addView(lg, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout line = new LinearLayout(a); line.setGravity(Gravity.CENTER_VERTICAL);
        TextView h = text(20, TEXT, true); h.setText(m.home); h.setGravity(Gravity.END); h.setSingleLine(true); h.setEllipsize(TextUtils.TruncateAt.END);
        ImageView homeLogo = logo(m.homeLogo, 26);
        TextView sc = text(22, isLive ? LIVE : ACCENT, true); sc.setGravity(Gravity.CENTER);
        sc.setText(m.hg >= 0 && m.ag >= 0 ? m.hg + " – " + m.ag : "vs");
        TextView aw = text(20, TEXT, true); aw.setText(m.away); aw.setSingleLine(true); aw.setEllipsize(TextUtils.TruncateAt.END);
        ImageView awayLogo = logo(m.awayLogo, 26);
        line.addView(h, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams teamLogoLp = new LinearLayout.LayoutParams(dp(26), dp(26)); teamLogoLp.setMargins(dp(5), 0, dp(5), 0);
        line.addView(homeLogo, teamLogoLp);
        line.addView(sc, new LinearLayout.LayoutParams(dp(90), -2));
        line.addView(awayLogo, teamLogoLp);
        line.addView(aw, new LinearLayout.LayoutParams(0, -2, 1));
        col.addView(leagueRow); col.addView(line);
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        r.setClickable(true);
        r.setOnClickListener(v -> showFixtureDetails(m));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(4);
        r.setLayoutParams(lp);
        return r;
    }

    private ImageView logo(String url, int sizeDp) {
        ImageView image = new ImageView(a);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setPadding(dp(2), dp(2), dp(2), dp(2));
        image.setBackground(round(0x33FFFFFF, 8, 0, 0));
        Football.loadLogo(a, url, image);
        return image;
    }

    private void showFixtureDetails(Football.M m) {
        if (!(scrim instanceof FrameLayout)) return;
        if (detailLayer != null) ((FrameLayout) scrim).removeView(detailLayer);
        FrameLayout overlay = new FrameLayout(a); overlay.setBackgroundColor(0xF208111F); overlay.setFocusableInTouchMode(true);
        LinearLayout panel = new LinearLayout(a); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(28), dp(24), dp(28), dp(20)); panel.setBackground(round(0xFF0B1626, 24, 2, 0xFF31516D));
        TextView title = text(25, TEXT, true); title.setText(m.home + "  ·  " + (m.hg >= 0 && m.ag >= 0 ? m.hg + "–" + m.ag : "vs") + "  ·  " + m.away);
        title.setMaxLines(2); title.setEllipsize(TextUtils.TruncateAt.END);
        TextView league = text(14, DIM, false); league.setText(m.league + "  ·  " + Football.time(m));
        LinearLayout body = new LinearLayout(a); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(0, dp(12), 0, dp(8));
        addMessage(body, a.getString(R.string.fixture_details));
        ScrollView scroll = new ScrollView(a); scroll.setVerticalScrollBarEnabled(false); scroll.addView(body);
        // ارتفاع منطقة المحتوى يُحسب من الشاشة (بدل 390dp الثابتة) كي لا تُقص اللوحة ولا تتداخل مع الأزرار
        int screenH = a.getResources().getDisplayMetrics().heightPixels;
        detailScrollH = Math.max(dp(220), Math.min(dp(390), screenH - dp(32) - dp(190)));
        // قابلة للتركيز: بالريموت ↑↓ تمرّر المحتوى (ملعب ثم بدلاء)
        scroll.setFocusable(true);
        scroll.setOnFocusChangeListener((v, f) -> v.setBackground(round(0x00000000, 14, f ? 2 : 0, ACCENT)));
        LinearLayout actions = new LinearLayout(a); actions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        TextView lineup = button(a.getString(R.string.lineups));
        TextView back = button(a.getString(R.string.close));
        for (TextView b : new TextView[]{lineup, back}) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); p.setMarginStart(dp(8)); actions.addView(b, p);
        }
        // تشكيلة + تبديلات + مسجلو الأهداف دفعة واحدة؛ الضغط مرة أخرى = تحديث (يحترم الكاش وسقف الطلبات)
        lineup.setOnClickListener(v -> loadLineupView(m, body, scroll));
        back.setOnClickListener(v -> { ((FrameLayout) scrim).removeView(overlay); detailLayer = null; });
        panel.addView(title); panel.addView(league); panel.addView(scroll, new LinearLayout.LayoutParams(-1, detailScrollH));
        panel.addView(actions);
        overlay.addView(panel, new FrameLayout.LayoutParams(Math.min(dp(900), a.getResources().getDisplayMetrics().widthPixels - dp(48)), -2, Gravity.CENTER));
        ((FrameLayout) scrim).addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        detailLayer = overlay; lineup.requestFocus();
    }

    private CharSequence errorText(String error) {
        if (error != null && error.toLowerCase(Locale.ROOT).contains("budget")) return a.getString(R.string.daily_budget_reached);
        return a.getString(R.string.fixture_data_error);
    }

    private void addMessage(LinearLayout container, CharSequence message) {
        TextView t = text(17, DIM, false); t.setText(message); t.setPadding(dp(4), dp(14), dp(4), dp(14));
        container.addView(t, new LinearLayout.LayoutParams(-1, -2));
    }

    private static final int HOME_COLOR = 0xFF2E7DFF, AWAY_COLOR = 0xFFFF6B4A;
    private int detailScrollH = 0;

    private static final int IN_COLOR = 0xFF2ECC71, OUT_RED = 0xFFFF5C5C;

    private void loadLineupView(Football.M m, LinearLayout body, ScrollView scroll) {
        final Object token = new Object(); body.setTag(token);
        body.removeAllViews(); addMessage(body, a.getString(R.string.lineups_loading));
        Football.loadLineups(a, m, (json, error) -> {
            if (body.getTag() != token || !body.isAttachedToWindow()) return;
            if (json == null) { body.removeAllViews(); addMessage(body, errorText(error)); return; }
            renderLineups(body, json, null, error);
            scroll.scrollTo(0, 0); scroll.requestFocus();
            if (!(Football.live(m.st) || Football.done(m.st))) return;      // قبل الانطلاق: لا أحداث ولا طلب إضافي
            Football.loadGoalEvents(a, m, (events, err2) -> {
                if (body.getTag() != token || !body.isAttachedToWindow()) return;
                if (events == null) { if (err2 != null && err2.toLowerCase(Locale.ROOT).contains("budget")) addMessage(body, errorText(err2)); return; }
                int y = scroll.getScrollY();
                renderLineups(body, json, events, error);
                scroll.scrollTo(0, y);
            });
        });
    }

    /** حالة فريق بعد تطبيق التبديلات: التشكيلة الحالية على الملعب + قائمة التغييرات. */
    private static class TeamState {
        JSONObject lineup;
        final List<String[]> changes = new ArrayList<>();           // {دقيقة, الخارج, الداخل}
        final Set<Integer> enteredIds = new HashSet<>();
        final Set<String> enteredNames = new HashSet<>();
    }

    private static String minute(JSONObject t) {
        if (t == null) return "";
        int el = t.optInt("elapsed", 0), ex = t.optInt("extra", 0);
        return el + (ex > 0 ? "+" + ex : "") + "'";
    }

    /** في API-Football: حدث التبديل يحمل player = الخارج، assist = الداخل. الداخل يأخذ مكان الخارج على الملعب. */
    private TeamState applyChanges(JSONObject lineup, JSONArray events) throws JSONException {
        TeamState st = new TeamState();
        JSONObject copy = new JSONObject(lineup.toString());
        JSONArray xi = copy.optJSONArray("startXI"), bench = lineup.optJSONArray("substitutes");
        JSONObject team = lineup.optJSONObject("team");
        int teamId = team == null ? 0 : team.optInt("id", 0);
        if (xi != null && events != null) for (int i = 0; i < events.length(); i++) {
            JSONObject e = events.optJSONObject(i);
            if (e == null || !"subst".equalsIgnoreCase(e.optString("type"))) continue;
            JSONObject et = e.optJSONObject("team"), outP = e.optJSONObject("player"), inP = e.optJSONObject("assist");
            if (et == null || et.optInt("id", -1) != teamId || outP == null || inP == null) continue;
            int outId = outP.optInt("id", 0), inId = inP.optInt("id", 0);
            String outName = outP.optString("name", ""), inName = inP.optString("name", "");
            JSONObject slot = null;
            for (int k = 0; k < xi.length() && slot == null; k++) {
                JSONObject item = xi.optJSONObject(k), pl = item == null ? null : item.optJSONObject("player");
                if (pl == null) continue;
                boolean same = outId > 0 ? pl.optInt("id", 0) == outId : pl.optString("name", "").equalsIgnoreCase(outName);
                if (same) slot = pl;
            }
            int number = 0;
            if (bench != null) for (int k = 0; k < bench.length(); k++) {
                JSONObject item = bench.optJSONObject(k), pl = item == null ? null : item.optJSONObject("player");
                if (pl == null) continue;
                if ((inId > 0 && pl.optInt("id", 0) == inId) || pl.optString("name", "").equalsIgnoreCase(inName)) { number = pl.optInt("number", 0); break; }
            }
            if (slot != null) { slot.put("id", inId); slot.put("name", inName); slot.put("number", number); slot.put("in", true); }
            if (inId > 0) st.enteredIds.add(inId);
            st.enteredNames.add(inName.toLowerCase(Locale.ROOT));
            st.changes.add(new String[]{minute(e.optJSONObject("time")), shortName(outName), shortName(inName)});
        }
        st.lineup = copy;
        return st;
    }

    private void renderLineups(LinearLayout container, String raw, String rawEvents, String error) {
        container.removeAllViews();   // يمسح رسالة «جارٍ التحميل»
        try {
            JSONArray teams = new JSONArray(raw);
            if (teams.length() < 2) { addMessage(container, a.getString(R.string.lineups_unavailable)); return; }
            JSONObject home = teams.getJSONObject(0), away = teams.getJSONObject(1);
            JSONArray hx = home.optJSONArray("startXI"), ax = away.optJSONArray("startXI");
            if ((hx == null || hx.length() == 0) && (ax == null || ax.length() == 0)) { addMessage(container, a.getString(R.string.lineups_unavailable)); return; }
            JSONArray events = null;
            if (rawEvents != null && !rawEvents.isEmpty()) { try { events = new JSONArray(rawEvents); } catch (Exception ignored) { } }
            TeamState hs = applyChanges(home, events), as = applyChanges(away, events);
            addLineupHeader(container, home, away);
            int pitchH = Math.max(dp(230), Math.min(dp(340), detailScrollH - dp(70)));
            LinearLayout.LayoutParams pitchLp = new LinearLayout.LayoutParams(-1, pitchH);
            pitchLp.topMargin = dp(6); pitchLp.bottomMargin = dp(6);
            container.addView(new Pitch(hs.lineup, as.lineup), pitchLp);
            container.addView(coachRow(home, away), new LinearLayout.LayoutParams(-1, dp(36)));
            if (events != null) { addChanges(container, hs, as); addGoals(container, events, home); }
            addBench(container, hs, as);
            if (error != null && error.toLowerCase(Locale.ROOT).contains("budget")) addMessage(container, a.getString(R.string.daily_budget_reached));
        } catch (Exception e) { container.removeAllViews(); addMessage(container, a.getString(R.string.no_lineups)); }
    }

    private TextView sectionTitle(CharSequence label) {
        TextView t = text(15, ACCENT, true); t.setText(label); t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(10), 0, dp(4));
        return t;
    }

    private LinearLayout column() { LinearLayout c = new LinearLayout(a); c.setOrientation(LinearLayout.VERTICAL); return c; }

    private View twoColumns(View left, View right) {
        LinearLayout cols = new LinearLayout(a); cols.setBaselineAligned(false);
        cols.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
        View divider = new View(a); divider.setBackgroundColor(0x22FFFFFF);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(1), -1); dl.setMargins(dp(6), dp(2), dp(6), dp(2));
        cols.addView(divider, dl);
        cols.addView(right, new LinearLayout.LayoutParams(0, -2, 1));
        return cols;
    }

    /** رموز ▲▼⚽ بالخط الافتراضي للنظام لأن خط Outfit قد لا يحتويها. */
    private TextView symbol(String s, int color, int sp) {
        TextView t = new TextView(a); t.setText(s); t.setTextColor(color); t.setTextSize(sp); t.setGravity(Gravity.CENTER);
        return t;
    }

    /** التغييرات: الخارج بالأحمر مع سهم ▼، والداخل بالأخضر مع سهم ▲. */
    private void addChanges(LinearLayout container, TeamState home, TeamState away) {
        if (home.changes.isEmpty() && away.changes.isEmpty()) return;
        container.addView(sectionTitle(a.getString(R.string.lineup_changes)), new LinearLayout.LayoutParams(-1, -2));
        container.addView(twoColumns(changesColumn(home), changesColumn(away)), new LinearLayout.LayoutParams(-1, -2));
    }

    private View changesColumn(TeamState st) {
        LinearLayout col = column();
        for (String[] c : st.changes) {
            LinearLayout row = new LinearLayout(a); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView min = text(12, DIM, false); min.setText(c[0]);
            TextView out = text(12, OUT_RED, true); out.setText(c[1]); out.setSingleLine(true); out.setEllipsize(TextUtils.TruncateAt.END);
            TextView in = text(12, LIVE, true); in.setText(c[2]); in.setSingleLine(true); in.setEllipsize(TextUtils.TruncateAt.END);
            row.addView(min, new LinearLayout.LayoutParams(dp(40), -2));
            row.addView(symbol("▼", OUT_RED, 10), new LinearLayout.LayoutParams(dp(14), -2));
            row.addView(out, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(symbol("▲", LIVE, 10), new LinearLayout.LayoutParams(dp(14), -2));
            row.addView(in, new LinearLayout.LayoutParams(0, -2, 1));
            col.addView(row, new LinearLayout.LayoutParams(-1, dp(24)));
        }
        return col;
    }

    /** المسجلون: كل هدف في عمود فريقه (الهدف في مرماه يُنسب للخصم). نفس طلب التبديلات، بلا كلفة إضافية. */
    private void addGoals(LinearLayout container, JSONArray events, JSONObject home) {
        JSONObject ht = home.optJSONObject("team");
        int homeId = ht == null ? 0 : ht.optInt("id", 0);
        LinearLayout left = column(), right = column(); int count = 0;
        for (int i = 0; i < events.length(); i++) {
            JSONObject e = events.optJSONObject(i);
            if (e == null || !"goal".equalsIgnoreCase(e.optString("type"))) continue;
            String detail = e.optString("detail", "").toLowerCase(Locale.ROOT);
            if (detail.contains("missed")) continue;
            JSONObject et = e.optJSONObject("team"), pl = e.optJSONObject("player");
            String name = pl == null ? "" : shortName(pl.optString("name", ""));
            if (name.isEmpty()) continue;
            boolean own = detail.contains("own");
            boolean homeSide = (et != null && et.optInt("id", -1) == homeId) != own;
            LinearLayout row = new LinearLayout(a); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView min = text(12, DIM, false); min.setText(minute(e.optJSONObject("time")));
            TextView who = text(12, TEXT, true); who.setText(name + (own ? " (og)" : detail.contains("penalty") ? " (pen)" : ""));
            who.setSingleLine(true); who.setEllipsize(TextUtils.TruncateAt.END);
            row.addView(min, new LinearLayout.LayoutParams(dp(40), -2));
            row.addView(symbol("⚽", TEXT, 11), new LinearLayout.LayoutParams(dp(20), -2));
            row.addView(who, new LinearLayout.LayoutParams(0, -2, 1));
            (homeSide ? left : right).addView(row, new LinearLayout.LayoutParams(-1, dp(24)));
            count++;
        }
        container.addView(sectionTitle(a.getString(R.string.goal_scorers)), new LinearLayout.LayoutParams(-1, -2));
        if (count == 0) { TextView none = text(13, DIM, false); none.setText(R.string.no_goal_scorers); none.setGravity(Gravity.CENTER); container.addView(none, new LinearLayout.LayoutParams(-1, -2)); }
        else container.addView(twoColumns(left, right), new LinearLayout.LayoutParams(-1, -2));
    }

    private void addLineupHeader(LinearLayout container, JSONObject home, JSONObject away) {
        LinearLayout header = new LinearLayout(a); header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(teamHeader(home, true), new LinearLayout.LayoutParams(0, dp(48), 1));
        TextView vs = text(13, DIM, true); vs.setText("VS"); vs.setGravity(Gravity.CENTER);
        header.addView(vs, new LinearLayout.LayoutParams(dp(42), -1));
        header.addView(teamHeader(away, false), new LinearLayout.LayoutParams(0, dp(48), 1));
        container.addView(header);
    }

    private View teamHeader(JSONObject lineup, boolean homeSide) {
        JSONObject team = lineup.optJSONObject("team");
        String name = team == null ? "" : team.optString("name", "");
        String crest = team == null ? "" : team.optString("logo", "");
        String formation = lineup.optString("formation", "");
        LinearLayout box = new LinearLayout(a); box.setGravity(homeSide ? Gravity.CENTER_VERTICAL | Gravity.START : Gravity.CENTER_VERTICAL | Gravity.END);
        ImageView crestView = logo(crest, 34);
        TextView label = text(14, TEXT, true); label.setText(name + (formation.isEmpty() ? "" : "  ·  " + formation));
        label.setSingleLine(true); label.setEllipsize(TextUtils.TruncateAt.END);
        label.setGravity(homeSide ? Gravity.START : Gravity.END);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34)); lp.setMarginStart(dp(5)); lp.setMarginEnd(dp(5));
        if (homeSide) { box.addView(crestView, lp); box.addView(label, new LinearLayout.LayoutParams(0, -2, 1)); }
        else { box.addView(label, new LinearLayout.LayoutParams(0, -2, 1)); box.addView(crestView, lp); }
        return box;
    }

    /** المدرب أسفل الملعب: صورته (من الكاش) واسمه، كل جهة تحت فريقها. */
    private View coachRow(JSONObject home, JSONObject away) {
        LinearLayout row = new LinearLayout(a); row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(coachView(home, true), new LinearLayout.LayoutParams(0, -1, 1));
        row.addView(coachView(away, false), new LinearLayout.LayoutParams(0, -1, 1));
        return row;
    }

    private View coachView(JSONObject lineup, boolean homeSide) {
        LinearLayout box = new LinearLayout(a); box.setGravity(Gravity.CENTER_VERTICAL | (homeSide ? Gravity.START : Gravity.END));
        JSONObject coach = lineup.optJSONObject("coach");
        String name = coach == null ? "" : coach.optString("name", "");
        if (name.isEmpty()) return box;
        ImageView photo = new ImageView(a); photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photo.setBackground(round(0x33FFFFFF, 50, 0, 0)); photo.setClipToOutline(true);
        Football.loadLogo(a, coach.optString("photo", ""), photo);
        TextView label = text(12, DIM, false); label.setText(a.getString(R.string.lineup_coach, name));
        label.setSingleLine(true); label.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(dp(26), dp(26)); pl.setMarginStart(dp(5)); pl.setMarginEnd(dp(6));
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        if (homeSide) { box.addView(photo, pl); box.addView(label, tl); }
        else { box.addView(label, tl); box.addView(photo, pl); }
        return box;
    }

    /** البدلاء المتبقون: عمودان (المضيف/الضيف) وكل لاعب «رقم القميص  الاسم»؛ من دخل الملعب يُحذف من القائمة. */
    private void addBench(LinearLayout container, TeamState home, TeamState away) {
        JSONArray bh = home.lineup.optJSONArray("substitutes"), ba = away.lineup.optJSONArray("substitutes");
        if ((bh == null || bh.length() == 0) && (ba == null || ba.length() == 0)) return;
        container.addView(sectionTitle(a.getString(R.string.lineup_substitutes)), new LinearLayout.LayoutParams(-1, -2));
        container.addView(twoColumns(benchColumn(bh, HOME_COLOR, home), benchColumn(ba, AWAY_COLOR, away)), new LinearLayout.LayoutParams(-1, -2));
    }

    private View benchColumn(JSONArray players, int color, TeamState st) {
        LinearLayout box = new LinearLayout(a); box.setBaselineAligned(false);
        LinearLayout left = column(), right = column();
        box.addView(left, new LinearLayout.LayoutParams(0, -2, 1)); box.addView(right, new LinearLayout.LayoutParams(0, -2, 1));
        if (players == null) return box;
        int shown = 0;
        for (int i = 0; i < players.length(); i++) {
            JSONObject item = players.optJSONObject(i), player = item == null ? null : item.optJSONObject("player");
            if (player == null) continue;
            String full = player.optString("name", "");
            if (st.enteredIds.contains(player.optInt("id", -1)) || st.enteredNames.contains(full.toLowerCase(Locale.ROOT))) continue;
            String name = shortName(full);
            if (name.isEmpty()) continue;
            int number = player.optInt("number", 0);
            LinearLayout line = new LinearLayout(a); line.setGravity(Gravity.CENTER_VERTICAL);
            TextView num = text(12, color, true); num.setText(number > 0 ? String.valueOf(number) : "–"); num.setGravity(Gravity.CENTER);
            TextView nm = text(12, TEXT, false); nm.setText(name); nm.setSingleLine(true); nm.setEllipsize(TextUtils.TruncateAt.END);
            line.addView(num, new LinearLayout.LayoutParams(dp(26), -2));
            line.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
            (shown % 2 == 0 ? left : right).addView(line, new LinearLayout.LayoutParams(-1, dp(24)));
            shown++;
        }
        return box;
    }

    /** «Paul Michael Junior Okon-Engstler» → «Okon-Engstler»، «J. Stanišić» → «Stanišić»، «Virgil van Dijk» → «van Dijk». */
    private static String shortName(String full) {
        if (full == null) return "";
        String s = full.trim();
        String[] w = s.split("\\s+");
        if (w.length <= 1) return s;
        int i = w.length - 1;
        String last = w[i].toLowerCase(Locale.ROOT);
        if (i > 0 && (last.equals("jr") || last.equals("jr.") || last.equals("junior") || last.equals("júnior"))) i--;
        while (i > 0 && isParticle(w[i - 1])) i--;
        StringBuilder sb = new StringBuilder();
        for (int j = i; j < w.length; j++) { if (sb.length() > 0) sb.append(' '); sb.append(w[j]); }
        return sb.toString();
    }

    private static boolean isParticle(String t) {
        switch (t.toLowerCase(Locale.ROOT)) {
            case "van": case "von": case "de": case "da": case "di": case "do": case "dos": case "del": case "der": case "den":
            case "du": case "la": case "le": case "el": case "al": case "bin": case "ter": case "ten": return true;
            default: return false;
        }
    }

    /**
     * ملعب أفقي: المضيف يسار والضيف يمين، حارس كل فريق عند مرماه.
     * كل خط (حراس/دفاع/وسط/هجوم) يُوزَّع على ارتفاع الملعب بالتساوي وبالتمركز،
     * وأحجام الوجوه والأسماء تُحسب من ارتفاع الملعب الفعلي فلا يتداخل شيء ولا يُقص.
     */
    private class Pitch extends FrameLayout {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final JSONObject home, away;
        private final List<int[]> rects = new ArrayList<>();
        private int builtW = -1, builtH = -1;

        Pitch(JSONObject home, JSONObject away) {
            super(a); this.home = home; this.away = away;
            setWillNotDraw(false);
            setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(14)); }
            });
            setClipToOutline(true);
        }

        /** يرجع لاعبي الفريق مجمّعين حسب الخط (1 = الحارس) ومرتّبين حسب العمود. */
        private List<List<JSONObject>> lines(JSONObject lineup) {
            JSONArray xi = lineup.optJSONArray("startXI");
            TreeMap<Integer, List<JSONObject>> byLine = new TreeMap<>();
            final Map<JSONObject, Integer> order = new HashMap<>();
            if (xi != null) for (int i = 0; i < xi.length(); i++) {
                JSONObject item = xi.optJSONObject(i), player = item == null ? null : item.optJSONObject("player");
                if (player == null) continue;
                int line, col = i;
                String pos = player.optString("pos", "");
                line = pos.startsWith("G") ? 1 : pos.startsWith("D") ? 2 : pos.startsWith("M") ? 3 : 4;
                try {
                    String[] g = player.optString("grid", "").split(":");
                    line = Math.max(1, Integer.parseInt(g[0].trim())); col = Integer.parseInt(g[1].trim());
                } catch (Exception ignored) { }
                List<JSONObject> list = byLine.get(line);
                if (list == null) { list = new ArrayList<>(); byLine.put(line, list); }
                list.add(player); order.put(player, col * 100 + i);
            }
            List<List<JSONObject>> out = new ArrayList<>(byLine.values());
            for (List<JSONObject> l : out) Collections.sort(l, (x, y) -> Integer.compare(order.get(x), order.get(y)));
            return out;
        }

        @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            if (w > 0 && h > 0 && (w != builtW || h != builtH)) build(w, h);
        }

        private void build(int w, int h) {
            builtW = w; builtH = h;
            removeAllViews(); rects.clear();
            List<List<JSONObject>> hl = lines(home), al = lines(away);
            int maxN = 4, maxL = 2;
            for (List<List<JSONObject>> t : Arrays.asList(hl, al)) {
                maxL = Math.max(maxL, t.size());
                for (List<JSONObject> l : t) maxN = Math.max(maxN, l.size());
            }
            float half = w / 2f;
            int face = Math.round(Math.max(dp(22), Math.min(dp(38), h / (float) maxN * 0.58f)));
            int chipH = face + dp(2) + dp(14);
            int chipW = Math.round(Math.min(dp(86), half * 0.76f / Math.max(1, maxL - 1) - dp(4)));
            placeTeam(hl, true, w, h, half, face, chipW, chipH, HOME_COLOR);
            placeTeam(al, false, w, h, half, face, chipW, chipH, AWAY_COLOR);
        }

        private void placeTeam(List<List<JSONObject>> lines, boolean homeSide, int w, int h, float half,
                               int face, int chipW, int chipH, int color) {
            int count = lines.size();
            for (int li = 0; li < count; li++) {
                List<JSONObject> line = lines.get(li);
                float progress = count <= 1 ? 0.5f : li / (float) (count - 1);
                float frac = 0.12f + 0.76f * progress;
                float x = homeSide ? half * frac : w - half * frac;
                int n = line.size();
                for (int k = 0; k < n; k++) {
                    float yFrac = 0.5f + ((k + 0.5f) / n - 0.5f) * 0.94f;
                    if (!homeSide) yFrac = 1f - yFrac;        // عمود 1 = يسار الفريق = أسفل الشاشة للضيف
                    int left = Math.max(dp(2), Math.min(w - chipW - dp(2), Math.round(x - chipW / 2f)));
                    int top = Math.max(dp(2), Math.min(h - chipH - dp(2), Math.round(yFrac * h - chipH / 2f)));
                    addView(playerChip(line.get(k), face, chipW, color));
                    rects.add(new int[]{left, top, chipW, chipH});
                }
            }
        }

        private View playerChip(JSONObject player, int face, int chipW, int color) {
            LinearLayout chip = new LinearLayout(a); chip.setOrientation(LinearLayout.VERTICAL); chip.setGravity(Gravity.CENTER_HORIZONTAL);
            boolean entered = player.optBoolean("in", false);
            if (entered) color = IN_COLOR;                      // اللاعب الداخل: حلقة وشارة وخط بالأخضر
            FrameLayout faceBox = new FrameLayout(a); faceBox.setBackground(round(0xFFFFFFFF, 50, entered ? 3 : 2, entered ? IN_COLOR : 0xFFFFFFFF));
            ImageView img = new ImageView(a); img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setBackground(round(0xFF244A3A, 50, 0, 0)); img.setClipToOutline(true);
            if (player.optInt("id", 0) > 0) Football.loadLogo(a, "https://media.api-sports.io/football/players/" + player.optInt("id") + ".png", img);
            faceBox.addView(img, new FrameLayout.LayoutParams(face - dp(3), face - dp(3), Gravity.CENTER));
            TextView number = text(9, TEXT, true); number.setGravity(Gravity.CENTER); number.setIncludeFontPadding(false);
            number.setText(player.optInt("number", 0) > 0 ? String.valueOf(player.optInt("number")) : "•");
            number.setBackground(round(color, 8, 0, 0));
            faceBox.addView(number, new FrameLayout.LayoutParams(dp(16), dp(14), Gravity.TOP | Gravity.END));
            chip.addView(faceBox, new LinearLayout.LayoutParams(face, face));
            TextView name = text(face >= dp(32) ? 10 : 9, entered ? 0xFFB9F6CA : TEXT, true); name.setIncludeFontPadding(false);
            name.setText(shortName(player.optString("name", ""))); name.setGravity(Gravity.CENTER);
            name.setSingleLine(true); name.setEllipsize(TextUtils.TruncateAt.END); name.setShadowLayer(3, 0, 1, 0xDD000000);
            LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(chipW, dp(14)); nl.topMargin = dp(2);
            chip.addView(name, nl);
            return chip;
        }

        @Override protected void onDraw(Canvas canvas) {
            float w = getWidth(), h = getHeight(), inset = dp(6);
            paint.setStyle(Paint.Style.FILL);
            int stripes = 12; float sw = w / stripes;
            for (int i = 0; i < stripes; i++) { paint.setColor(i % 2 == 0 ? 0xFF0B9159 : 0xFF0A8852); canvas.drawRect(i * sw, 0, (i + 1) * sw, h, paint); }
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(1)); paint.setColor(0xB3FFFFFF);
            canvas.drawRect(inset, inset, w - inset, h - inset, paint);
            canvas.drawLine(w / 2, inset, w / 2, h - inset, paint);
            canvas.drawCircle(w / 2, h / 2, Math.min(h * 0.17f, w * 0.085f), paint);
            float boxW = w * 0.115f, boxH = h * 0.56f, goalW = w * 0.04f, goalH = h * 0.30f;
            canvas.drawRect(inset, (h - boxH) / 2, inset + boxW, (h + boxH) / 2, paint);
            canvas.drawRect(w - inset - boxW, (h - boxH) / 2, w - inset, (h + boxH) / 2, paint);
            canvas.drawRect(inset, (h - goalH) / 2, inset + goalW, (h + goalH) / 2, paint);
            canvas.drawRect(w - inset - goalW, (h - goalH) / 2, w - inset, (h + goalH) / 2, paint);
            paint.setStyle(Paint.Style.FILL); canvas.drawCircle(w / 2, h / 2, dp(2), paint);
        }

        @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
            for (int i = 0; i < getChildCount() && i < rects.size(); i++) {
                int[] q = rects.get(i); View child = getChildAt(i);
                child.measure(MeasureSpec.makeMeasureSpec(q[2], MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(q[3], MeasureSpec.EXACTLY));
                child.layout(q[0], q[1], q[0] + q[2], q[1] + q[3]);
            }
        }
    }

    private TextView button(String label) {
        TextView t = text(18, TEXT, false); t.setText(label); t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(12), dp(16), dp(12));
        t.setFocusable(true); t.setClickable(true);
        t.setBackground(round(0xFF11213A, 14, 1, 0x55FFFFFF));
        t.setOnFocusChangeListener((v, f) -> v.setBackground(round(f ? 0xFF1B4560 : 0xFF11213A, 14, f ? 3 : 1, f ? ACCENT : 0x55FFFFFF)));
        return t;
    }

    private TextView text(int sp, int color, boolean bold) {
        TextView t = new TextView(a); t.setTextSize(sp); t.setTextColor(color);
        t.setTypeface(bold ? Fonts.bold(a) : Fonts.outfit(a));
        return t;
    }
    private GradientDrawable round(int fill, int radius, int strokeDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(radius));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke);
        return g;
    }
    private int dp(int v) { return Math.round(v * a.getResources().getDisplayMetrics().density); }
}
