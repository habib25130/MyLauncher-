package com.myfamily.launcher;

import android.content.*;

public class AdhanReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (a != null) {      // إقلاع / تحديث التطبيق / تغيير الوقت أو المنطقة (مزامنة الشبكة): إعادة جدولة فقط، ولا أذان أبدًا
            if (Intent.ACTION_BOOT_COMPLETED.equals(a)) HomeKeyService.enableViaSecureSettings(c);   // يعيد تفعيل زر Home إن أسقطه النظام
            Adhan.schedule(c); return;
        }
        int k = i.getIntExtra("k", -1);
        long due = i.getLongExtra("t", 0), now = System.currentTimeMillis();
        // لا نؤذّن إلا في وقت الصلاة نفسه: إن وصل المنبّه متأخرًا (التلفاز كان في الاستعداد أو الساعة قفزت) فالصلاة فاتت
        long tolerance = i.getBooleanExtra("x", true) ? 3 * 60 * 1000L : 10 * 60 * 1000L;
        boolean onTime = due > 0 && Math.abs(now - due) <= tolerance;
        if (k >= 0 && onTime && Adhan.enabled(c)) {
            int m = Adhan.mode(c, k);
            if (m > 0) Adhan.play(c, m, k);
        }
        Adhan.schedule(c);   // الصلاة التالية
    }
}
