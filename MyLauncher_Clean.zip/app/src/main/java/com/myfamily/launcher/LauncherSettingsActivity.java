package com.myfamily.launcher;

import android.app.Activity;
import android.app.Dialog;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

/** إعدادات اللانشر: صفحة واحدة بتخطيط يشبه لانشرك الأصلي. */
public class LauncherSettingsActivity extends Activity {
    static final int TEXT = Color.WHITE, DIM = 0xB3FFFFFF, GREY = 0xFF8E9AAB, ACCENT = 0xFF6FD8FF;
    private SharedPreferences p;
    private LinearLayout page;
    private ScrollView sv;
    private String pendingFocus, lastTag;

    @Override protected void attachBaseContext(Context base) { super.attachBaseContext(LocaleHelper.wrap(base)); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        PersistentBackup.restoreIfNeeded(this);
        CleanStart.run(this);
        p = getSharedPreferences("launcher", MODE_PRIVATE);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(40), dp(28), dp(40), dp(40));
        sv = new ScrollView(this);
        sv.addView(page);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF08111F, 0xFF12384F}));
        setContentView(sv);
        String init = b != null ? b.getString("section") : getIntent().getStringExtra("section");
        if (init != null && java.util.Arrays.asList(CATS).contains(init)) section = init;
        render();
        if (b == null && getIntent().getBooleanExtra("open_weather", false)) { getIntent().removeExtra("open_weather"); showWeatherDialog(); }
    }

    @Override protected void onResume() { super.onResume(); render(); }
    @Override protected void onPause() { super.onPause(); PersistentBackup.saveSoon(this); }

    /** null = الصفحة الرئيسية (الباقات) · وإلا اسم الباقة المفتوحة. */
    private String section;
    private boolean noHead;

    private static final String[] CATS = {"appearance", "home", "apps", "prayer", "services", "media", "system"};

    private void render() {
        page.removeAllViews();
        noHead = false;
        if (section == null) renderHome(); else renderSection();
        String tg = pendingFocus != null ? pendingFocus : lastTag;     // يبقى التركيز على الصف الذي ضغطته (حتى بعد العودة من شاشة أخرى)
        pendingFocus = null;
        View v = tg != null ? sv.findViewWithTag(tg) : null;
        if (v == null && sv.findFocus() == null) {
            java.util.ArrayList<View> fl = sv.getFocusables(View.FOCUS_DOWN);
            if (!fl.isEmpty()) v = fl.get(0);
        }
        if (v != null) v.requestFocus();
        lastTag = tg;
    }


    // ---------- الصفحة الرئيسية: باقات ----------
    private void renderHome() {
        TextView title = text(34, TEXT, true); title.setText(R.string.menu_launcher_settings);
        title.setPadding(0, 0, 0, dp(12));
        page.addView(title);
        boolean wide = getResources().getConfiguration().screenWidthDp >= 720;
        LinearLayout row = null;
        for (int i = 0; i < CATS.length; i++) {
            if (!wide || i % 2 == 0) {
                row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
                page.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
            View c = categoryCard(CATS[i]);
            LinearLayout.LayoutParams lp = wide ? new LinearLayout.LayoutParams(0, -1, 1) : new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(dp(4), dp(6), dp(4), dp(6));
            row.addView(c, lp);
        }
        if (wide && CATS.length % 2 == 1 && row != null) {          // يبقي عرض البطاقة الأخيرة بنفس بقية البطاقات
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, -1, 1); sp.setMargins(dp(4), dp(6), dp(4), dp(6));   // ارتفاعها match_parent كالبطاقة، وإلا ينهار الصف
            row.addView(new View(this), sp);
        }
    }

    private String catTitle(String c) {
        switch (c) {
            case "appearance": return getString(R.string.cat_appearance);
            case "home":       return getString(R.string.cat_home);
            case "apps":       return getString(R.string.menu_apps);
            case "prayer":     return getString(R.string.sec_prayer);
            case "services":   return getString(R.string.cat_services);
            case "media":      return getString(R.string.cat_media);
            default:           return getString(R.string.sec_system);
        }
    }
    private String catSub(String c) {
        switch (c) {
            case "appearance": return getString(R.string.cat_appearance_sub);
            case "home":       return getString(R.string.cat_home_sub);
            case "apps":       return getString(R.string.cat_apps_sub);
            case "prayer":     return getString(R.string.cat_prayer_sub);
            case "services":   return getString(R.string.cat_services_sub);
            case "media":      return getString(R.string.cat_media_sub);
            default:           return getString(R.string.cat_system_sub);
        }
    }

    private View categoryCard(final String c) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(22), dp(20), dp(22), dp(20));
        TextView t = text(22, TEXT, true); t.setText(catTitle(c) + "  \u203A");
        TextView s = text(14, GREY, false); s.setText(catSub(c)); s.setPadding(0, dp(6), 0, 0);
        card.addView(t); card.addView(s);
        card.setFocusable(true); card.setClickable(true); card.setTag("c_" + c);
        style(card, false, false);
        card.setOnFocusChangeListener((x, f) -> style(x, f, false));
        card.setOnClickListener(x -> { section = c; lastTag = null; pendingFocus = null; render(); sv.scrollTo(0, 0); });
        return card;
    }

    // ---------- داخل باقة ----------
    private void renderSection() {
        TextView back = text(18, ACCENT, true); back.setText("\u2039  " + getString(R.string.cat_back));
        back.setPadding(dp(20), dp(12), dp(20), dp(12));
        back.setFocusable(true); back.setClickable(true); back.setTag("back");
        style(back, false, false);
        back.setOnFocusChangeListener((x, f) -> style(x, f, false));
        back.setOnClickListener(x -> goHome());
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2); bl.bottomMargin = dp(8);
        page.addView(back, bl);
        TextView title = text(30, TEXT, true); title.setText(catTitle(section));
        title.setPadding(0, 0, 0, dp(6));
        page.addView(title);
        switch (section) {
            case "appearance": blkA(); blkI(); break;
            case "home":       blkB(); blkC(); break;
            case "apps":       blkApps(); break;
            case "prayer":     noHead = true; blkD(); break;
            case "services":   blkE(); blkF(); blkBackup(); break;
            case "media":      blkG(); blkH(); break;
            default:           noHead = true; blkJ(); break;
        }
    }

    private void goHome() {
        String old = section;
        section = null; lastTag = null; pendingFocus = old == null ? null : "c_" + old;
        render(); sv.scrollTo(0, 0);
    }

    @Override public void onBackPressed() {
        if (section != null) goHome(); else super.onBackPressed();
    }

    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); o.putString("section", section); }

    private void blkA() {
        // ----- الخلفية -----
        heading(getString(R.string.sec_wallpaper));
        action(getString(R.string.wallpaper_studio), "ws", () -> startActivity(new Intent(this, WallpaperStudioActivity.class)));
        note(getString(R.string.wallpaper_note));
        if (Background.canPin(this)) {
            action(getString(Background.pinned(this) ? R.string.ls_unpin_wp : R.string.ls_pin_wp), "pin", () -> Background.togglePin(this));
            note(getString(R.string.ls_pin_note));
        }
        toggle(getString(R.string.ls_contrast), "contrast", false);
        note(getString(R.string.ls_contrast_note));
    }

    private void blkB() {
        // ----- عناصر الشاشة الرئيسية (ما يظهر وما يُخفى) -----
        heading(getString(R.string.visibility_title));
        toggle(getString(R.string.clean_bg), "bg_clean", false);
        note(getString(R.string.clean_note));
        toggle(getString(R.string.vis_clock), "vis_clock", true);
        note(getString(R.string.note_vis_clock));
        toggle(getString(R.string.vis_prayer), "vis_prayer", true);
        note(getString(R.string.note_vis_prayer));
        toggle(getString(R.string.ls_weather_show), WeatherRepository.P_SHOW, true);
        note(getString(R.string.note_vis_weather));
        toggle(getString(R.string.vis_matches), "vis_matches", true);
        note(getString(R.string.note_vis_matches));
        toggle(getString(R.string.vis_net), "vis_net", true);
        note(getString(R.string.note_vis_net));
        toggle(getString(R.string.vis_title), "vis_title", true);
        note(getString(R.string.note_vis_title));
        toggle(getString(R.string.vis_onphotos), "vis_onphotos", true);
        note(getString(R.string.vis_onphotos_note));
    }

    private void blkC() {
        // ----- الساعة والتاريخ -----
        heading(getString(R.string.ls_clock_section));
        int cf = p.getInt("clock_fmt", 0);
        String[] fmts = {getString(R.string.fmt_system), getString(R.string.fmt_12), getString(R.string.fmt_24)};
        action(getString(R.string.ls_time_format, fmts[cf]), "cf", () -> p.edit().putInt("clock_fmt", (p.getInt("clock_fmt", 0) + 1) % 3).apply());
        toggle(getString(R.string.ls_show_date), "show_date", true);
        toggle(getString(R.string.ls_show_greeting), "show_greeting", true);
        action(getString(R.string.greet_row, Greetings.load(p).size()), "greet",
                () -> startActivity(new Intent(this, MainActivity.class).putExtra("dlg", "greet")));
    }

    private void blkD() {
        // ----- الصلاة والأذان -----
        heading(getString(R.string.sec_prayer));
        action(getString(R.string.prayer_city_line, p.getString("city", getString(R.string.default_city))), "city",
                () -> startActivity(new Intent(this, MainActivity.class).putExtra("dlg", "city")));
        action(getString(R.string.timezone_line, p.getString("tz", "Africa/Algiers")), "tz",
                () -> startActivity(new Intent(this, MainActivity.class).putExtra("dlg", "city")));
        int m = p.getInt("method", 19);
        String mn = "";
        for (int i = 0; i < PrayerTimes.TABLE.length; i++)
            if ((int) PrayerTimes.TABLE[i][0] == m) mn = getResources().getStringArray(R.array.method_names)[i];
        action(getString(R.string.method_line, String.valueOf(m), mn), "method",
                () -> startActivity(new Intent(this, MainActivity.class).putExtra("dlg", "method")));
        note(getString(R.string.method_note));
        action(getString(R.string.adhan_channel), "adhan", () -> startActivity(new Intent(this, AdhanSettingsActivity.class)));
        action(getString(R.string.prayer_style, getString(p.getInt("prayer_style", 1) == 1 ? R.string.style_board : R.string.style_panel)), "pst",
                () -> p.edit().putInt("prayer_style", p.getInt("prayer_style", 1) == 1 ? 0 : 1).apply());
        note(getString(R.string.prayer_style_note));
        label(getString(R.string.hijri_adjust, String.valueOf(p.getInt("hijri_adj", 0))));
        options("ha", "hijri_adj", new int[]{-2, -1, 0, 1, 2}, 0);
        note(getString(R.string.hijri_note));
    }

    private void blkE() {
        heading(getString(R.string.ls_weather_section));
        toggle(getString(R.string.ls_weather_f), WeatherRepository.P_FAHRENHEIT, false);
        final boolean keyed = WeatherRepository.useKey(this);
        action(getString(R.string.ls_weather_src, keyed ? "WeatherAPI" : getString(R.string.ls_src_free)), "wsrc", () -> {
            p.edit().putInt(WeatherRepository.P_SRC, keyed ? 0 : 1).apply();
            WeatherRepository.refresh(this, true, null);
        });
        String city = WeatherRepository.city(this).trim();
        action(getString(R.string.ls_weather_city, city.isEmpty() ? getString(R.string.ls_weather_city_auto) : city), "wcity", this::showWeatherDialog);
        if (keyed) {
            String ks = WeatherRepository.keyRejected(this) ? getString(R.string.ls_weather_key_bad)
                    : WeatherRepository.hasKey(this) ? getString(R.string.ls_weather_key_ok) : getString(R.string.ls_weather_key_none);
            action(getString(R.string.ls_weather_key) + " \u00b7 " + ks, "wkey", this::showWeatherDialog);
            note(getString(R.string.ls_weather_note));
        } else {
            note(getString(R.string.ls_weather_free_note));
        }
    }

    private void blkF() {
        // ----- كرة القدم -----
        heading(getString(R.string.ls_fb_section));
        String fs = Football.keyRejected(this) ? getString(R.string.ls_weather_key_bad)
                : Football.hasBothKeys(this) ? getString(R.string.ls_fb_key_both)
                : Football.hasKey(this) ? getString(R.string.ls_fb_key_ok) : getString(R.string.ls_fb_key_none);
        action(getString(R.string.ls_fb_key) + " · " + fs, "fkey", this::showFootballDialog);
        note(getString(R.string.ls_fb_note));
    }

    private void blkBackup() {
        // ----- النسخ الاحتياطي للإعدادات -----
        heading(getString(R.string.sec_backup));
        action(getString(R.string.ls_export_settings), "export_cfg", () -> {
            try {
                String path = SettingsBackup.exportSettings(this);
                Toast.makeText(this, getString(R.string.backup_success, path), Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.backup_failed, String.valueOf(e.getMessage())), Toast.LENGTH_LONG).show();
            }
        });
        action(getString(R.string.ls_import_settings), "import_cfg", () -> {
            java.io.File file = SettingsBackup.getImportFile(this);
            if (file == null) {
                Toast.makeText(this, R.string.no_backup_found, Toast.LENGTH_LONG).show();
                return;
            }
            try {
                SettingsBackup.importSettings(this, file);
                Toast.makeText(this, R.string.restore_success, Toast.LENGTH_LONG).show();
                render();
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.restore_failed, String.valueOf(e.getMessage())), Toast.LENGTH_LONG).show();
            }
        });
        note(getString(R.string.ls_backup_note));
        // ----- نسخة دائمة تبقى بعد إلغاء التثبيت -----
        toggle(getString(R.string.ls_persist), PersistentBackup.ENABLED, true);
        action(getString(R.string.ls_persist_now), "persist_now", () -> {
            boolean ok; try { ok = PersistentBackup.write(this); } catch (Exception e) { ok = false; }
            Toast.makeText(this, ok ? R.string.persist_saved : R.string.persist_failed, Toast.LENGTH_SHORT).show();
        });
        action(getString(R.string.ls_persist_restore), "persist_restore", () -> {
            boolean ok = PersistentBackup.restoreNow(this);
            Toast.makeText(this, ok ? R.string.persist_restored : R.string.persist_none, Toast.LENGTH_SHORT).show();
        });
        note(getString(R.string.ls_persist_note));
    }

    private void blkG() {
        // ----- شاشة التوقف -----
        heading(getString(R.string.sec_screensaver));
        String[] dcs = {getString(R.string.dream_clock_digital), getString(R.string.dream_clock_analog), getString(R.string.dream_clock_both)};
        action(getString(R.string.ls_dream_clock, dcs[Math.max(0, Math.min(2, p.getInt("dream_clock", 0)))]), "dc",
                () -> p.edit().putInt("dream_clock", (p.getInt("dream_clock", 0) + 1) % 3).apply());
        String[] dls = {getString(R.string.dial_black), getString(R.string.dial_white), getString(R.string.dial_coral)};
        int curDial = Math.max(0, Math.min(2, p.getInt("dream_dial", p.getBoolean("dream_dial_light", false) ? 1 : 0)));
        action(getString(R.string.ls_dream_dial, dls[curDial]), "dd",
                () -> p.edit().putInt("dream_dial", (curDial + 1) % 3).remove("dream_dial_light").apply());
        note(getString(R.string.dream_note));
        action(getString(R.string.screensaver_set), "ss", () -> {
            if (!launch(new Intent(Settings.ACTION_DREAM_SETTINGS),
                    comp("com.android.tv.settings", "com.android.tv.settings.device.display.daydream.DaydreamActivity"),
                    comp("com.android.tv.settings", "com.android.tv.settings.device.display.daydream.DaydreamActivity$DaydreamActivity"),
                    comp("com.android.settings", "com.android.settings.Settings$DreamSettingsActivity"))) {
                Toast.makeText(this, R.string.dream_path_help, Toast.LENGTH_LONG).show();
                launch(new Intent(Settings.ACTION_DISPLAY_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
            }
        });
        note(getString(R.string.screensaver_note));
    }

    private void blkH() {
        // ----- الراديو وشاشة الاستماع -----
        heading(getString(R.string.sec_ambient));
        String[] ambS = {getString(R.string.amb_s_ribbon), getString(R.string.amb_s_notes), getString(R.string.amb_s_black)};
        action(getString(R.string.amb_style_fmt, ambS[Math.max(0, Math.min(2, p.getInt("amb_style", 0)))]), "amb_style",
                () -> p.edit().putInt("amb_style", (p.getInt("amb_style", 0) + 1) % 3).apply());
        String[] ambP = {getString(R.string.amb_p_spectrum), getString(R.string.amb_p_amber), getString(R.string.amb_p_gold)};
        action(getString(R.string.amb_palette_fmt, ambP[Math.max(0, Math.min(2, p.getInt("amb_palette", 0)))]), "amb_palette",
                () -> p.edit().putInt("amb_palette", (p.getInt("amb_palette", 0) + 1) % 3).apply());
        String[] ambB = {getString(R.string.amb_b_low), getString(R.string.amb_b_mid), getString(R.string.amb_b_high)};
        action(getString(R.string.amb_bright_fmt, ambB[Math.max(0, Math.min(2, p.getInt("amb_bright", 1)))]), "amb_bright",
                () -> p.edit().putInt("amb_bright", (p.getInt("amb_bright", 1) + 1) % 3).apply());
        final int[] ambAutos = {0, 1, 5, 15};
        int ambAu = p.getInt("amb_auto", 0);
        action(getString(R.string.amb_auto_fmt, ambAu == 0 ? getString(R.string.amb_auto_never) : getString(R.string.amb_auto_after, ambAu)), "amb_auto", () -> {
            int cur = p.getInt("amb_auto", 0), nx = 0;
            for (int q = 0; q < ambAutos.length; q++) if (ambAutos[q] == cur) nx = (q + 1) % ambAutos.length;
            p.edit().putInt("amb_auto", ambAutos[nx]).apply();
        });
        note(getString(R.string.amb_settings_note));
    }

    private void blkI() {
        // ----- الحركات والمؤثرات -----
        heading(getString(R.string.sec_motion));
        String[] mls = {getString(R.string.motion_full), getString(R.string.motion_light), getString(R.string.motion_off)};
        action(getString(R.string.ls_motion, mls[motionLevel()]), "motion", () -> {
            int n = (motionLevel() + 1) % 3;                       // كاملة ← خفيفة ← متوقفة
            p.edit().putBoolean("anim", n != 2).putBoolean("effects", n == 0).apply();
        });
        note(getString(R.string.ls_motion_note));
        action(getString(R.string.ls_reset_appearance), "reset", () -> {
            p.edit().remove("apps_per_row").remove("extra_rows").remove("contrast").remove("clock_fmt").remove("dream_clock").remove("dream_dial_light").remove("dream_dial")
                    .remove("show_date").remove("show_greeting").remove("anim").remove("effects").apply();
            Toast.makeText(this, R.string.ls_reset_done, Toast.LENGTH_SHORT).show();
        });
        note(getString(R.string.ls_reset_note));
        toggle(getString(R.string.ls_focus_tint), "focus_tint", true);
        note(getString(R.string.ls_focus_tint_note));
    }

    private void blkJ() {
        // ----- النظام -----
        heading(getString(R.string.sec_system));
        action(getString(R.string.home_key, onOff(HomeKeyService.isEnabled(this))), "hk", this::setupHomeKey);
        note(getString(R.string.home_key_note));
        action(getString(R.string.ls_default_home), "home", () -> {
            try { startActivity(new Intent(Settings.ACTION_HOME_SETTINGS)); }
            catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        });
        note(getString(R.string.ls_default_home_note));
        action(getString(R.string.ls_dns, dnsLabel()), "dns", this::showDnsDialog);
        note(getString(R.string.ls_dns_note));
        action(getString(R.string.tv_settings), "tv", () -> startActivity(new Intent(Settings.ACTION_SETTINGS)));
        action(getString(R.string.about_support), "about",
                () -> startActivity(new Intent(this, MainActivity.class).putExtra("dlg", "about")));
    }

    // ----- DNS خاص (يتطلب WRITE_SECURE_SETTINGS الممنوح عبر ADB كزر Home) -----
    private static final String[] DNS_HOSTS = {"", "dns.adguard-dns.com", "one.one.one.one", "security.cloudflare-dns.com", "family.cloudflare-dns.com", "dns.quad9.net"};

    private String[] dnsNames() {
        return new String[]{getString(R.string.ls_dns_auto), "AdGuard", "Cloudflare 1.1.1.1",
                "Cloudflare 1.1.1.2 \u00b7 " + getString(R.string.ls_dns_cf_sec),
                "Cloudflare 1.1.1.3 \u00b7 " + getString(R.string.ls_dns_cf_fam), "Quad9"};
    }

    private int dnsIndex() {
        try {
            String m = Settings.Global.getString(getContentResolver(), "private_dns_mode");
            String h = Settings.Global.getString(getContentResolver(), "private_dns_specifier");
            if ("hostname".equals(m) && h != null) for (int i = 1; i < DNS_HOSTS.length; i++) if (DNS_HOSTS[i].equals(h)) return i;
        } catch (Exception ignored) { }
        return 0;
    }

    private String dnsLabel() { return dnsNames()[dnsIndex()]; }

    /** قائمة بكل الخيارات (تلقائي، AdGuard، Cloudflare بثلاثة أنماط، Quad9) بدل التبديل بالضغط المتكرر. */
    private void showDnsDialog() {
        new android.app.AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(R.string.ls_dns_title)
                .setSingleChoiceItems(dnsNames(), dnsIndex(), (d, which) -> { d.dismiss(); applyDns(which); })
                .setNegativeButton(android.R.string.cancel, null)
                .setOnDismissListener(d -> render())
                .show();
    }

    private void applyDns(int n) {
        try {
            if (n == 0) Settings.Global.putString(getContentResolver(), "private_dns_mode", "opportunistic");
            else {
                Settings.Global.putString(getContentResolver(), "private_dns_specifier", DNS_HOSTS[n]);
                Settings.Global.putString(getContentResolver(), "private_dns_mode", "hostname");
            }
        } catch (SecurityException e) {
            Toast.makeText(this, getString(R.string.ls_dns_denied, getPackageName()), Toast.LENGTH_LONG).show();
        }
    }

    // ----- التطبيقات -----
    private void blkApps() {
        noHead = true; heading("");
        label(getString(R.string.ls_apps_per_row));
        options("apr", "apps_per_row", new int[]{4, 5, 6, 7}, 5);
        label(getString(R.string.ls_extra_rows));
        options("xr", "extra_rows", new int[]{0, 1, 2, 3}, 0);
        action(getString(R.string.sort_label) + " \u00b7 " + sortLabel(), "sort",
                () -> p.edit().putInt("apps_sort", (p.getInt("apps_sort", 0) + 1) % 4).remove("manual_layout").remove("rest_order").apply());
        note(getString(R.string.ls_sort_note));
        action(getString(R.string.ls_reset_order), "rorder", () -> {
            p.edit().remove("manual_layout").remove("rest_order").apply();
            Toast.makeText(this, R.string.ls_reset_order_done, Toast.LENGTH_SHORT).show();
        });
        toggle(getString(R.string.ls_hide_clutter), "hide_clutter", false);
        note(getString(R.string.ls_hide_clutter_note));
        action(getString(R.string.ls_hidden_apps, hiddenPkgs().size()), "hid", this::showHiddenDialog);
    }

    private java.util.List<String> hiddenPkgs() {
        java.util.List<String> l = new java.util.ArrayList<>();
        for (String x : p.getString("hidden", "").split(",")) if (!x.isEmpty()) l.add(x);
        return l;
    }

    /** قائمة التطبيقات المخفية: علّم ما تريد إعادته ثم «إعادة». */
    private void showHiddenDialog() {
        final java.util.List<String> pk = hiddenPkgs();
        if (pk.isEmpty()) { Toast.makeText(this, R.string.ls_hidden_none, Toast.LENGTH_SHORT).show(); return; }
        final PackageManager pm = getPackageManager();
        final String[] names = new String[pk.size()];
        final boolean[] back = new boolean[pk.size()];
        for (int i = 0; i < names.length; i++) {
            try { names[i] = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pk.get(i), 0))); }
            catch (Exception e) { names[i] = pk.get(i); }
        }
        new android.app.AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(R.string.ls_hidden_title)
                .setMultiChoiceItems(names, back, (d, i, c) -> back[i] = c)
                .setPositiveButton(R.string.ls_hidden_restore, (d, w) -> {
                    java.util.List<String> keep = new java.util.ArrayList<>();
                    for (int i = 0; i < pk.size(); i++) if (!back[i]) keep.add(pk.get(i));
                    p.edit().putString("hidden", android.text.TextUtils.join(",", keep)).apply();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .setOnDismissListener(d -> render())
                .show();
    }

    // ---------- عناصر ----------
    private void options(String tagPrefix, String key, int[] values, int def) {
        LinearLayout row = new LinearLayout(this);
        int cur = p.getInt(key, def);
        for (int v : values) {
            final int vv = v;
            TextView t = text(20, TEXT, false); t.setText(String.valueOf(v)); t.setGravity(Gravity.CENTER);
            t.setPadding(dp(8), dp(18), dp(8), dp(18));
            t.setFocusable(true); t.setClickable(true); t.setTag(tagPrefix + v);
            style(t, false, cur == v);
            t.setOnFocusChangeListener((x, f) -> style(x, f, p.getInt(key, def) == vv));
            t.setOnClickListener(x -> { p.edit().putInt(key, vv).apply(); pendingFocus = tagPrefix + vv; render(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.setMargins(0, dp(4), dp(10), dp(4));
            row.addView(t, lp);
        }
        page.addView(row);
    }

    private Intent comp(String pkg, String cls) { return new Intent().setComponent(new ComponentName(pkg, cls)); }

    /** يجرّب الأهداف بالترتيب، ولا يبدأ إلا ما يوجد فعلًا على الجهاز (بعض التلفازات تعرض رسالة خطأ بدل رفع استثناء). */
    private boolean launch(Intent... list) {
        for (Intent i : list) {
            try {
                if (i.resolveActivity(getPackageManager()) != null) { startActivity(i); return true; }
            } catch (Exception ignored) { }
        }
        return false;
    }

    /** تفعيل خدمة زر Home: مباشرة إن مُنح الإذن عبر ADB، وإلا شاشة إمكانية الوصول، وإلا شرح الأوامر. */
    private void setupHomeKey() {
        if (HomeKeyService.isEnabled(this)) { Toast.makeText(this, R.string.home_enabled, Toast.LENGTH_SHORT).show(); return; }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED) {
            try {
                String me = new ComponentName(this, HomeKeyService.class).flattenToString();
                String cur = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
                String all = (cur == null || cur.isEmpty()) ? me : (cur.contains(me) ? cur : cur + ":" + me);
                Settings.Secure.putString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, all);
                Settings.Secure.putInt(getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 1);
                Toast.makeText(this, R.string.home_enabled, Toast.LENGTH_LONG).show();
                return;
            } catch (Exception ignored) { }
        }
        if (launch(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
                comp("com.android.tv.settings", "com.android.tv.settings.accessibility.AccessibilityActivity"),
                comp("com.android.settings", "com.android.settings.Settings$AccessibilitySettingsActivity"))) return;
        new android.app.AlertDialog.Builder(this).setMessage(getString(R.string.home_adb_help, getPackageName())).setPositiveButton(android.R.string.ok, null).show();
    }

    /** إدخال مفتاح WeatherAPI (يُحفظ مشفّراً) والمدينة الاختيارية. لا يُعرض المفتاح الحالي أبداً. */
    private void showWeatherDialog() {
        final int pad = dp(20);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, dp(8), pad, 0);
        final boolean keyed = WeatherRepository.useKey(this);
        TextView help = new TextView(this); help.setText(R.string.weather_help); help.setTextSize(15); help.setPadding(0, 0, 0, dp(10));
        if (keyed) box.addView(help);
        final android.widget.EditText key = new android.widget.EditText(this);
        key.setHint(R.string.weather_key_hint); key.setSingleLine(true);
        key.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        final android.widget.EditText city = new android.widget.EditText(this);
        city.setHint(R.string.weather_city_hint); city.setSingleLine(true);
        city.setText(WeatherRepository.city(this));
        final Button wqr = new Button(this); wqr.setText(R.string.fb_qr_btn);
        key.setId(View.generateViewId()); wqr.setId(View.generateViewId()); city.setId(View.generateViewId());
        key.setNextFocusDownId(wqr.getId()); wqr.setNextFocusUpId(key.getId());
        wqr.setNextFocusDownId(city.getId()); city.setNextFocusUpId(wqr.getId());
        if (keyed) { box.addView(key); box.addView(wqr); }
        box.addView(city);
        android.app.AlertDialog.Builder wb = new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.weather_dlg_title).setView(box)
                .setPositiveButton(android.R.string.ok, (d, w) -> {
                    String k = key.getText().toString().trim();
                    if (!k.isEmpty()) WeatherRepository.saveKey(this, k);
                    WeatherRepository.saveCity(this, city.getText().toString());
                    WeatherRepository.refresh(this, true, null);
                })
                .setNegativeButton(android.R.string.cancel, null)
                .setOnDismissListener(d -> render());
        if (keyed) wb.setNeutralButton(R.string.weather_remove_key, (d, w) -> WeatherRepository.saveKey(this, ""));
        final android.app.AlertDialog wdlg = wb.create();
        wqr.setOnClickListener(v -> { wdlg.dismiss(); showWeatherQr(); });
        wdlg.show();
    }

    /** مفتاح API-Football: إدخال يدوي للمفتاح الرئيسي والثانوي أو عبر QR من الهاتف. لا يُعرض المفتاح الحالي أبداً. */
    private void showFootballDialog() {
        final int pad = dp(20);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, dp(8), pad, 0);
        TextView help = new TextView(this); help.setText(R.string.fb_help); help.setTextSize(15); help.setPadding(0, 0, 0, dp(10));
        final android.widget.EditText key1 = new android.widget.EditText(this);
        key1.setHint(R.string.fb_key_hint1); key1.setSingleLine(true);
        key1.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        final android.widget.EditText key2 = new android.widget.EditText(this);
        key2.setHint(R.string.fb_key_hint2); key2.setSingleLine(true);
        key2.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);

        final Button qr = new Button(this); qr.setText(R.string.fb_qr_btn);
        key1.setId(View.generateViewId()); key2.setId(View.generateViewId()); qr.setId(View.generateViewId());
        key1.setNextFocusDownId(key2.getId()); key2.setNextFocusUpId(key1.getId());
        key2.setNextFocusDownId(qr.getId()); qr.setNextFocusUpId(key2.getId());

        box.addView(help); box.addView(key1); box.addView(key2); box.addView(qr);
        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.fb_dlg_title).setView(box)
                .setPositiveButton(android.R.string.ok, (d, w) -> {
                    String k1 = key1.getText().toString().trim();
                    String k2 = key2.getText().toString().trim();
                    if (k1.isEmpty() && k2.isEmpty()) return;
                    if (!k1.isEmpty() && !Football.validKey(k1)) { Toast.makeText(this, R.string.fb_key_invalid, Toast.LENGTH_LONG).show(); return; }
                    if (!k2.isEmpty() && !Football.validKey(k2)) { Toast.makeText(this, R.string.fb_key_invalid, Toast.LENGTH_LONG).show(); return; }
                    String saveK1 = k1.isEmpty() ? Football.key1(this) : k1;
                    String saveK2 = k2.isEmpty() ? Football.key2(this) : k2;
                    Football.saveKey(this, saveK1, saveK2);
                    Football.refresh(this, true, null);
                })
                .setNeutralButton(R.string.weather_remove_key, (d, w) -> Football.saveKey(this, "", ""))
                .setNegativeButton(android.R.string.cancel, null)
                .setOnDismissListener(d -> render())
                .create();
        qr.setOnClickListener(v -> { dlg.dismiss(); showFootballQr(); });
        dlg.show();
    }

    private interface KeySaver { void save(String k); }
    private interface KeysSaver { boolean save(String[] v); }

    /** مفتاحا API-Football في اتصال QR واحد: الحقل الأول للمفتاح الأول والثاني اختياري، والفارغ يُترك كما هو. */
    private void showFootballQr() {
        showKeysQr("API-Football", new String[]{"API-Football 1", "API-Football 2 (اختياري · optional)"}, v -> {
            String a = v.length > 0 ? v[0] : "", b = v.length > 1 ? v[1] : "";
            Football.saveKey(this, a.isEmpty() ? Football.key1(this) : a, b.isEmpty() ? Football.key2(this) : b);
            Football.refresh(this, true, null);
            return true;
        });
    }

    private void showWeatherQr() {
        showKeyQr("WeatherAPI", k -> { WeatherRepository.saveKey(this, k); WeatherRepository.refresh(this, true, null); });
    }

    /** نافذة QR لمفتاح واحد. */
    private void showKeyQr(String pageTitle, final KeySaver saver) {
        showKeysQr(pageTitle, null, v -> { saver.save(v[0]); return true; });
    }

    /** نافذة QR عامة: يرسل الهاتف مفتاحاً أو أكثر (سطر لكل حقل)، فيُتحقق منها وتُحفظ عبر saver. */
    private void showKeysQr(String pageTitle, final String[] labels, final KeysSaver saver) {
        String ip = UploadServer.localIp();
        if (ip == null) { Toast.makeText(this, R.string.up_noip, Toast.LENGTH_LONG).show(); return; }
        final Dialog[] holder = new Dialog[1];
        final UploadServer srv;
        try {
            srv = new UploadServer(new java.io.File(getCacheDir(), "up"), tmp -> {
                java.util.List<String> ls = new java.util.ArrayList<>();
                try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader(tmp))) {
                    String line; while ((line = r.readLine()) != null && ls.size() < 5) ls.add(line.trim());
                } catch (Exception e) { return false; }
                boolean any = false;
                for (String k : ls) { if (k.isEmpty()) continue; if (!Football.validKey(k)) return false; any = true; }
                if (!any) return false;
                if (!saver.save(ls.toArray(new String[0]))) return false;
                runOnUiThread(() -> { Toast.makeText(this, R.string.fb_key_saved, Toast.LENGTH_LONG).show(); if (holder[0] != null) holder[0].dismiss(); });
                return true;
            }, true);
        } catch (java.io.IOException e) { Toast.makeText(this, R.string.save_failed, Toast.LENGTH_SHORT).show(); return; }
        if (labels != null) srv.setFields(labels);
        srv.setKeyTitle(pageTitle);
        srv.start();
        String url = "http://" + ip + ":" + srv.port() + "/" + srv.code;
        boolean[][] m = QrCode.encode(url);
        int n = m.length, q = 4, sc = Math.max(4, dp(300) / (n + 2 * q));
        Bitmap bm = Bitmap.createBitmap((n + 2 * q) * sc, (n + 2 * q) * sc, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bm); cv.drawColor(Color.WHITE);
        Paint pt = new Paint(); pt.setColor(Color.BLACK);
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
            if (m[y][x]) cv.drawRect((x + q) * sc, (y + q) * sc, (x + q + 1) * sc, (y + q + 1) * sc, pt);
        ImageView iv = new ImageView(this); iv.setImageBitmap(bm);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(28), dp(20), dp(28), dp(20));
        box.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF08111F, 0xFF12384F}));
        TextView title = text(24, TEXT, true); title.setText(R.string.fb_qr_title); title.setGravity(Gravity.CENTER);
        TextView link = text(16, ACCENT, false); link.setText(url); link.setPadding(0, dp(10), 0, dp(4));
        TextView note = text(14, DIM, false); note.setText(R.string.up_note); note.setGravity(Gravity.CENTER);
        box.addView(title); box.addView(iv); box.addView(link); box.addView(note);
        Dialog d = new Dialog(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        holder[0] = d;
        d.setContentView(box);
        d.setOnDismissListener(x -> { srv.stop(); render(); });
        d.show();
    }

    private String sortLabel() {
        int[] ids = {R.string.sort_az, R.string.sort_most, R.string.sort_recent, R.string.sort_new};
        return getString(ids[Math.max(0, Math.min(3, p.getInt("apps_sort", 0)))]);
    }

    private String onOff(boolean b) { return getString(b ? R.string.on : R.string.off); }

    private void toggle(String label, String key, boolean def) { toggle(label, key, def, false); }

    /** labelHasState: النص يحوي الحالة أصلًا (مثل «Animations : Activé»). */
    private void toggle(String label, String key, boolean def, boolean labelHasState) {
        boolean on = p.getBoolean(key, def);
        TextView t = text(20, TEXT, false);
        t.setText(labelHasState ? label : label + " · " + onOff(on));
        t.setPadding(dp(20), dp(18), dp(20), dp(18));
        t.setFocusable(true); t.setClickable(true); t.setTag("t_" + key);
        style(t, false, on);
        t.setOnFocusChangeListener((x, f) -> style(x, f, p.getBoolean(key, def)));
        t.setOnClickListener(x -> { p.edit().putBoolean(key, !p.getBoolean(key, def)).apply(); pendingFocus = "t_" + key; render(); });
        page.addView(t, rowLp());
    }

    private void action(String label, String tag, Runnable r) {
        TextView t = text(20, TEXT, false); t.setText(label);
        t.setPadding(dp(20), dp(18), dp(20), dp(18));
        t.setFocusable(true); t.setClickable(true); t.setTag(tag);
        style(t, false, false);
        t.setOnFocusChangeListener((x, f) -> style(x, f, false));
        t.setOnClickListener(x -> { r.run(); pendingFocus = tag; render(); });
        page.addView(t, rowLp());
    }

    /** عنوان قسم: لون مميّز + خط فاصل رفيع تحته. */
    private void heading(String s) {
        if (noHead) { noHead = false; return; }
        TextView t = text(22, ACCENT, true); t.setText(s); t.setPadding(0, dp(22), 0, dp(6));
        page.addView(t);
        View line = new View(this); line.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Math.max(1, dp(1))); lp.bottomMargin = dp(4);
        page.addView(line, lp);
    }
    /** عنوان فرعي داخل قسم. */
    private void label(String s) {
        TextView t = text(18, TEXT, true); t.setText(s); t.setPadding(dp(2), dp(10), 0, dp(2));
        page.addView(t);
    }
    /** شرح صغير رمادي تحت الخانة. */
    private void note(String s) {
        TextView t = text(13, GREY, false); t.setText(s); t.setPadding(dp(6), dp(1), dp(6), dp(8));
        page.addView(t);
    }
    /** 0 كاملة (حركة + تكبير) · 1 خفيفة (حركة بلا تكبير) · 2 متوقفة. */
    private int motionLevel() {
        boolean a = p.getBoolean("anim", true), e = p.getBoolean("effects", true);
        return !a ? 2 : (e ? 0 : 1);
    }
    private void spacer() { page.addView(new View(this), new LinearLayout.LayoutParams(-1, dp(14))); }

    private LinearLayout.LayoutParams rowLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(4), 0, dp(4)); return lp;
    }

    private void style(View v, boolean focused, boolean selected) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(18));
        g.setColor(selected ? 0xFF143B52 : 0xFF11213A);
        g.setStroke(dp(focused || selected ? 3 : 1), focused ? 0xFFB8EEFF : selected ? 0xFF4FA8CC : 0x55FFFFFF);
        v.setBackground(g);
    }
    private TextView text(int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setTextSize(sp); t.setTextColor(color);
        t.setTypeface(bold ? Fonts.bold(this) : Fonts.outfit(this));
        return t;
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
