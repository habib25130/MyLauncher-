package com.myfamily.launcher;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * مسح لمرة واحدة عند أول تشغيل لهذه النسخة: يحذف مفاتيح API القديمة (الطقس والكرة) وكل ما خُزّن بها
 * (الكاش، العدّادات، الشعارات) حتى لا تظهر بطاقتا الطقس والمباريات إلا بعد إدخال المفتاح من جديد.
 * إعدادات الصلاة والمدينة والخلفية تبقى كما هي. زد VERSION لتكرار المسح في إصدار لاحق.
 */
final class CleanStart {
    static final int VERSION = 1;
    static final String FLAG = "clean_start_v";

    private CleanStart() { }

    static void run(Context c) {
        SharedPreferences s = c.getApplicationContext().getSharedPreferences("launcher", Context.MODE_PRIVATE);
        if (s.getInt(FLAG, 0) >= VERSION) return;
        SharedPreferences.Editor e = s.edit();
        List<String> drop = new ArrayList<>();
        for (String k : s.getAll().keySet()) {
            // الكرة: كل شيء (المفتاح، الكاش، العدّادات، التشكيلات، الأحداث)
            if (k.startsWith("fb_")) drop.add(k);
            // الطقس: المفتاح والمدينة والكاش وحالة الخطأ (يبقى خيار الإظهار وفهرنهايت)
            if (k.equals("weather_key_enc") || k.equals("weather_q") || k.equals("weather_cache")
                    || k.equals("weather_next_try") || k.equals("weather_bad_until") || k.equals("weather_err")) drop.add(k);
        }
        for (String k : drop) e.remove(k);
        e.putInt(FLAG, VERSION).apply();
        File logos = new File(c.getApplicationContext().getFilesDir(), "football-logos");
        File[] fs = logos.listFiles();
        if (fs != null) for (File f : fs) f.delete();
    }
}
