package com.myfamily.launcher;

import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.util.Arrays;

/** خلفية الشاشة الرئيسية: 0 مدمجة (أمواج سوداء/زرقاء)، 1 صورة شخصية، 2 عرض شرائح (يتبدّل كل 1-60 دقيقة). */
public class Background {
    /** الخلفيات المدمجة: 0 أمواج سوداء، 1 أمواج زرقاء. */
    static final int[] PRESETS = {R.drawable.wave_black, R.drawable.wave_blue};

    /** رقم الساعة المحلية منذ 1970 (يتغيّر عند كل رأس ساعة بتوقيت الجهاز). */
    private static long localMs() { long n = System.currentTimeMillis(); return n + java.util.TimeZone.getDefault().getOffset(n); }
    static int intervalMin(Context c) { int m = p(c).getInt("bg_interval_min", 60); return m < 1 || m > 60 ? 60 : m; }
    /** رقم الفترة الحالية (كل N دقيقة، محاذاة لساعة الجهاز). */
    private static int slotIndex(Context c) { return (int) (localMs() / (intervalMin(c) * 60_000L)); }
    private static long msToNextSlot(Context c) { long len = intervalMin(c) * 60_000L; return len - (localMs() % len) + 100L; }

    private final Handler h = new Handler(Looper.getMainLooper());
    private Runnable slide;

    /** تثبيت الصورة الحالية من عرض الشرائح (يوقف التبديل حتى يُفكّ التثبيت). */
    static boolean pinned(Context c) { return !p(c).getString("bg_pin", "").isEmpty(); }
    static boolean canPin(Context c) { return mode(c) == 2 && slides(c).length >= 2; }
    static void togglePin(Context c) {
        if (pinned(c)) { p(c).edit().remove("bg_pin").apply(); return; }
        File[] f = slides(c);
        if (f.length >= 2) p(c).edit().putString("bg_pin", f[slotIndex(c) % f.length].getName()).apply();
    }

    static SharedPreferences p(Context c) { return c.getSharedPreferences("launcher", Context.MODE_PRIVATE); }
    static boolean flag(Context c, String k) { return p(c).getBoolean(k, true); }
    static boolean clean(Context c) { return p(c).getBoolean("bg_clean", false); }
    static int mode(Context c) { int m = p(c).getInt("bg_mode", 0); return m < 0 || m > 2 ? 0 : m; }
    static int preset(Context c) { return Math.max(0, Math.min(PRESETS.length - 1, p(c).getInt("bg_preset", 0))); }
    static File photo(Context c) { return new File(c.getFilesDir(), "wall_photo.jpg"); }
    static File slidesDir(Context c) { return new File(c.getFilesDir(), "slides"); }
    static File[] slides(Context c) {
        File[] f = slidesDir(c).listFiles();
        if (f == null) return new File[0];
        Arrays.sort(f); return f;
    }
    static boolean hasSaved(Context c, int mode) {
        return mode == 1 ? photo(c).exists() : mode == 2 && slides(c).length > 0;
    }
    static ImageView presetImage(Context c, int i, int sample) {
        ImageView iv = new ImageView(c);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        try {
            BitmapFactory.Options o = new BitmapFactory.Options(); o.inSampleSize = sample;
            iv.setImageBitmap(BitmapFactory.decodeResource(c.getResources(), PRESETS[Math.max(0, Math.min(PRESETS.length - 1, i))], o));
        } catch (Throwable ignored) { }
        return iv;
    }

    void apply(Context c, FrameLayout holder) {
        stop(); holder.removeAllViews();
        holder.setBackgroundColor(Color.BLACK);
        int mode = mode(c);
        try {
            if (mode == 1 && photo(c).exists()) holder.addView(image(c, photo(c)), match());
            else if (mode == 2 && slides(c).length > 0) startSlides(c, holder);
            else holder.addView(presetImage(c, preset(c), 1), match());
        } catch (Throwable ignored) { }
        View dim = new View(c);
        dim.setBackgroundColor(Color.argb(p(c).getInt("bg_dim", 0) * 255 / 100, 0, 0, 0));
        holder.addView(dim, match());
    }

    void stop() { if (slide != null) h.removeCallbacks(slide); slide = null; }

    private static FrameLayout.LayoutParams match() { return new FrameLayout.LayoutParams(-1, -1); }

    private static ImageView image(Context c, File f) {
        ImageView iv = new ImageView(c);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setImageBitmap(BitmapFactory.decodeFile(f.getPath()));
        return iv;
    }

    /** عرض الشرائح: صورة جديدة كل N دقيقة (1 إلى 60)، بتلاشٍ ناعم. */
    private void startSlides(Context c, FrameLayout holder) {
        final File[] files = slides(c);
        File first = files[slotIndex(c) % files.length];
        boolean pinnedNow = false;
        String pin = p(c).getString("bg_pin", "");
        if (!pin.isEmpty()) for (File f : files) if (f.getName().equals(pin)) { first = f; pinnedNow = true; }
        final ImageView iv = image(c, first);
        holder.addView(iv, match());
        if (files.length < 2 || pinnedNow) return;
        slide = new Runnable() {
            @Override public void run() {
                iv.animate().alpha(0f).setDuration(600).withEndAction(() -> {
                    iv.setImageBitmap(BitmapFactory.decodeFile(files[slotIndex(c) % files.length].getPath()));
                    iv.animate().alpha(1f).setDuration(600).start();
                }).start();
                h.postDelayed(this, msToNextSlot(c));
            }
        };
        h.postDelayed(slide, msToNextSlot(c));
    }
}
