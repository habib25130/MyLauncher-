package com.myfamily.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * نسخة احتياطية تبقى بعد إلغاء تثبيت اللانشر وتُستعاد تلقائياً عند أول تشغيل بعد إعادة التثبيت.
 *
 * الموضع الأول: Android/media/&lt;الحزمة&gt;/launcher-backup.json — لا يُحذف مع التطبيق، ولا يحتاج أي إذن.
 *   يحوي كل الإعدادات + مفاتيح API كنص عادي (مفاتيح Keystore تضيع مع التثبيت فلا ينفع حفظها مشفّرة).
 * الموضع الثاني: Settings.Secure["mylauncher_keys"] — المفاتيح الثلاثة فقط، ويحتاج WRITE_SECURE_SETTINGS (إذن ADB نفسه).
 *   قراءته لا تحتاج إذناً، فتُستعاد المفاتيح حتى قبل منح الإذن من جديد.
 * تنبيه خصوصية: تطبيقات أخرى قد تقرأ هذين الموضعين. المفاتيح مجانية الفئة، ويمكن إطفاء الميزة من الإعدادات.
 * لا تشمل صور الخلفية (تبقى في مساحة التطبيق وتُحذف مع إلغاء التثبيت).
 */
final class PersistentBackup {
    static final String ENABLED = "persist_backup";
    private static final String FILE = "launcher-backup.json", SECURE_KEY = "mylauncher_keys";
    private static final long MAX_VALUE = 8000;      // القيم الأطول (كاش) تُتجاهل
    private static final Set<String> SKIP = new HashSet<>(Arrays.asList(
            "weather_cache", "weather_next_try", "weather_bad_until", "weather_err", "weather_geo",
            "fb_time", "fb_remaining", "fb_err", "fb_off", "fb_quota_day", "fb_active_key_idx",
            "fb_logo_data_migrated", "fb_logo_upgrade_attempt", "fb_key_bad", "fb_tmr_day", "fb_tmr_time",
            "clean_start_v"));
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler H = new Handler(Looper.getMainLooper());

    private PersistentBackup() { }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("launcher", Context.MODE_PRIVATE);
    }

    static boolean enabled(Context c) { return prefs(c).getBoolean(ENABLED, true); }

    private static boolean skip(String k) {
        return SKIP.contains(k) || k.startsWith("fb_cache") || k.startsWith("fb_cnt_") || k.startsWith("fb_key1_exhausted_")
                || k.equals(WeatherRepository.P_KEY) || k.equals(Football.P_KEY) || k.equals(Football.P_KEY2);
    }

    /** مجلد Android/media الخاص بالتطبيق (يبقى بعد إلغاء التثبيت). */
    @SuppressWarnings("deprecation")
    private static File dir(Context c) {
        try {
            File[] ds = c.getExternalMediaDirs();
            if (ds != null) for (File f : ds) if (f != null && (f.isDirectory() || f.mkdirs())) return f;
        } catch (Throwable ignored) { }
        return null;
    }

    // ------------------------------------------------------------------ الحفظ

    /** حفظ مؤجّل بعد ثانية تقريباً على خيط خلفي (يُستدعى من onPause). */
    static void saveSoon(Context c) {
        final Context app = c.getApplicationContext();
        H.removeCallbacksAndMessages(null);
        H.postDelayed(() -> IO.execute(() -> { try { write(app); } catch (Throwable ignored) { } }), 800);
    }

    /** يكتب النسختين؛ يعيد true إن نجحت إحداهما. إن كانت الميزة مطفأة يمحو ما كُتب سابقاً. */
    static boolean write(Context c) throws Exception {
        Context app = c.getApplicationContext();
        if (!enabled(app)) { clear(app); return false; }
        SharedPreferences sp = prefs(app);
        JSONObject d = new JSONObject();
        for (Map.Entry<String, ?> en : sp.getAll().entrySet()) {
            String k = en.getKey(); Object v = en.getValue();
            if (k == null || v == null || skip(k)) continue;
            try {
                if (v instanceof Boolean) d.put("b:" + k, v);
                else if (v instanceof Integer) d.put("i:" + k, v);
                else if (v instanceof Long) d.put("l:" + k, v);
                else if (v instanceof Float) d.put("f:" + k, (double) (Float) v);
                else if (v instanceof String) { if (((String) v).length() <= MAX_VALUE) d.put("s:" + k, v); }
                else if (v instanceof Set) {
                    JSONArray a = new JSONArray();
                    for (Object o : (Set<?>) v) a.put(String.valueOf(o));
                    if (a.length() <= 500) d.put("t:" + k, a);
                }
            } catch (Exception ignored) { }
        }
        JSONObject keys = new JSONObject();
        plain(keys, "w", sp, WeatherRepository.P_KEY);
        plain(keys, "f1", sp, Football.P_KEY);
        plain(keys, "f2", sp, Football.P_KEY2);
        JSONObject root = new JSONObject().put("v", 2).put("t", System.currentTimeMillis()).put("d", d).put("keys", keys);

        boolean ok = false;
        File dir = dir(app);
        if (dir != null) {
            try {
                File tmp = new File(dir, FILE + ".tmp"), out = new File(dir, FILE);
                try (Writer w = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8)) { w.write(root.toString()); }
                ok = tmp.renameTo(out) || (out.delete() && tmp.renameTo(out));
            } catch (Exception ignored) { }
        }
        try {
            Settings.Secure.putString(app.getContentResolver(), SECURE_KEY, keys.length() == 0 ? "" : keys.toString());
            if (keys.length() > 0) ok = true;
        } catch (Throwable ignored) { }              // الإذن غير ممنوح: نكتفي بالملف
        return ok;
    }

    private static void plain(JSONObject keys, String name, SharedPreferences sp, String prefKey) {
        try {
            String p = SecretStore.decrypt(sp.getString(prefKey, ""));
            if (!p.isEmpty()) keys.put(name, p);
        } catch (Exception ignored) { }
    }

    private static void clear(Context app) {
        try { File d = dir(app); if (d != null) new File(d, FILE).delete(); } catch (Throwable ignored) { }
        try { Settings.Secure.putString(app.getContentResolver(), SECURE_KEY, ""); } catch (Throwable ignored) { }
    }

    // ---------------------------------------------------------------- الاستعادة

    private static JSONObject load(Context app) {
        File d = dir(app);
        if (d != null) {
            File f = new File(d, FILE);
            if (f.isFile() && f.canRead()) {
                try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                    StringBuilder sb = new StringBuilder(); char[] buf = new char[4096]; int n;
                    while ((n = r.read(buf)) != -1) sb.append(buf, 0, n);
                    return new JSONObject(sb.toString());
                } catch (Throwable ignored) { }
            }
        }
        try {
            String s = Settings.Secure.getString(app.getContentResolver(), SECURE_KEY);
            if (s != null && s.startsWith("{")) return new JSONObject().put("keys", new JSONObject(s));
        } catch (Throwable ignored) { }
        return null;
    }

    /** مفتاح محفوظ لكن لا يُفكّ (ضاع مفتاح Keystore بعد إعادة التثبيت أو النسخ التلقائي). */
    private static boolean broken(SharedPreferences sp, String key) {
        String v = sp.getString(key, "");
        return !v.isEmpty() && SecretStore.decrypt(v).isEmpty();
    }

    /**
     * يُستدعى قبل أي شيء عند فتح اللانشر: إن كانت الإعدادات فارغة (تثبيت جديد أو مسح بيانات) تُستعاد كلها،
     * وإن كانت موجودة لكن مفاتيح API غير قابلة للفك تُستعاد المفاتيح فقط.
     */
    static void restoreIfNeeded(Context c) {
        try {
            Context app = c.getApplicationContext();
            SharedPreferences sp = prefs(app);
            boolean empty = sp.getAll().isEmpty();
            boolean wb = broken(sp, WeatherRepository.P_KEY), f1b = broken(sp, Football.P_KEY), f2b = broken(sp, Football.P_KEY2);
            if (!empty && !wb && !f1b && !f2b) return;
            JSONObject b = load(app);
            if (b == null) return;
            SharedPreferences.Editor e = sp.edit();
            if (empty) importAll(e, b.optJSONObject("d"));
            JSONObject k = b.optJSONObject("keys");
            if (k != null) {
                if (empty || wb) putKey(e, WeatherRepository.P_KEY, k.optString("w"));
                if (empty || f1b) putKey(e, Football.P_KEY, k.optString("f1"));
                if (empty || f2b) putKey(e, Football.P_KEY2, k.optString("f2"));
            }
            if (empty) e.putInt(CleanStart.FLAG, CleanStart.VERSION);   // لا تمسح CleanStart المفاتيح المستعادة
            e.apply();
        } catch (Throwable ignored) { }
    }

    /** استعادة يدوية كاملة (تستبدل القيم الحالية). */
    static boolean restoreNow(Context c) {
        try {
            Context app = c.getApplicationContext();
            JSONObject b = load(app);
            if (b == null) return false;
            SharedPreferences.Editor e = prefs(app).edit();
            importAll(e, b.optJSONObject("d"));
            JSONObject k = b.optJSONObject("keys");
            if (k != null) {
                putKey(e, WeatherRepository.P_KEY, k.optString("w"));
                putKey(e, Football.P_KEY, k.optString("f1"));
                putKey(e, Football.P_KEY2, k.optString("f2"));
            }
            e.putInt(CleanStart.FLAG, CleanStart.VERSION).commit();
            WeatherRepository.refresh(app, true, null);
            Football.refresh(app, true, null);
            Adhan.schedule(app);
            return true;
        } catch (Throwable t) { return false; }
    }

    private static void putKey(SharedPreferences.Editor e, String prefKey, String plain) {
        if (plain != null && !plain.trim().isEmpty()) e.putString(prefKey, SecretStore.encrypt(plain.trim()));
    }

    private static void importAll(SharedPreferences.Editor e, JSONObject d) {
        if (d == null) return;
        for (Iterator<String> it = d.keys(); it.hasNext(); ) {
            String k = it.next();
            if (k == null || k.length() < 3 || k.charAt(1) != ':') continue;
            String name = k.substring(2);
            try {
                switch (k.charAt(0)) {
                    case 'b': e.putBoolean(name, d.getBoolean(k)); break;
                    case 'i': e.putInt(name, d.getInt(k)); break;
                    case 'l': e.putLong(name, d.getLong(k)); break;
                    case 'f': e.putFloat(name, (float) d.getDouble(k)); break;
                    case 's': e.putString(name, d.getString(k)); break;
                    case 't': {
                        JSONArray a = d.getJSONArray(k); Set<String> st = new HashSet<>();
                        for (int i = 0; i < a.length(); i++) st.add(a.getString(i));
                        e.putStringSet(name, st); break;
                    }
                    default: break;
                }
            } catch (Exception ignored) { }
        }
    }
}
