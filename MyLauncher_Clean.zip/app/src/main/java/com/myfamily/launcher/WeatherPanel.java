package com.myfamily.launcher;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * بطاقة الطقس: الحالة الحالية (أيقونة + درجة + حالة + مكان + رياح) ثم جدول حتى 3 أيام:
 * لكل يوم الصبيحة / الظهيرة / الليل (أيقونة + درجة + رياح إن وُجدت)، وتحته سطر الحالة (خطأ، موقع افتراضي، آخر تحديث).
 * OK / رجوع / لمس خارجها يغلقها. show(null) = لا بيانات بعد: تعرض سبب الخطأ.
 */
final class WeatherPanel {
    private static final int GOLD = WaveformView.GOLD, GOLD_LIGHT = WaveformView.GOLD_LIGHT, TEXT = 0xFFFFFFFF, DIM = 0xB3FFFFFF, WARN = 0xFFFFB4A8;

    private static final View.OnKeyListener OK_KEY = (v, kc, ev) -> {   // OK / Enter = نقر (ويبتلع DOWN لتفادي نقر مزدوج)
        boolean ok = kc == android.view.KeyEvent.KEYCODE_DPAD_CENTER || kc == android.view.KeyEvent.KEYCODE_ENTER || kc == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER;
        if (ok && ev.getAction() == android.view.KeyEvent.ACTION_UP) v.performClick();
        return ok;
    };

    private final Activity act;
    private final float density;
    private Dialog dialog;
    private static long lastManual;                 // آخر تحديث يدوي (حماية الحصة: مرة كل دقيقة)
    Runnable onUpdate;                              // يُستدعى بعد أي تحديث لتحديث سطر الشاشة الرئيسية

    WeatherPanel(Activity act) { this.act = act; this.density = act.getResources().getDisplayMetrics().density; }

    void dismiss() { if (dialog != null) { try { dialog.dismiss(); } catch (Exception ignored) { } dialog = null; } }

    void show(WeatherData d) {
        dismiss();
        final boolean f = act.getSharedPreferences("launcher", Activity.MODE_PRIVATE).getBoolean(WeatherRepository.P_FAHRENHEIT, false);
        final boolean rtl = "ar".equals(Locale.getDefault().getLanguage());

        Dialog dlg = new Dialog(act, android.R.style.Theme_DeviceDefault_NoActionBar);
        dialog = dlg;
        Window w = dlg.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0x99050A12));
            w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        FrameLayout root = new FrameLayout(act);
        root.setLayoutDirection(rtl ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        root.setOnClickListener(v -> dismiss());

        LinearLayout card = new LinearLayout(act);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(24), dp(20), dp(24), dp(16));
        card.setBackground(cardBg(false));
        card.setFocusable(false); card.setClickable(true);   // التركيز على زر التحديث (الريموت: OK = تحديث، رجوع = إغلاق)
        card.setOnClickListener(v -> dismiss());
        int cardW = Math.min(act.getResources().getDisplayMetrics().widthPixels - dp(40), dp(640));
        root.addView(card, new FrameLayout.LayoutParams(cardW, -2, Gravity.CENTER));

        // ---- الحالية: أيقونة | درجة + حالة + مكان + رياح
        LinearLayout top = new LinearLayout(act);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView ic = new ImageView(act);
        ic.setImageResource(d != null ? d.iconRes() : R.drawable.ic_w_cloud);
        ic.setColorFilter(d != null ? d.tint() : 0xFFB8C7D9);   // لون الحالة
        ic.setScaleType(ImageView.ScaleType.FIT_CENTER);
        if (d != null) ic.setContentDescription(d.text);
        top.addView(ic, new LinearLayout.LayoutParams(dp(80), dp(80)));

        LinearLayout col = new LinearLayout(act); col.setOrientation(LinearLayout.VERTICAL);
        TextView temp = text(52, GOLD_LIGHT, true); temp.setSingleLine(true);
        temp.setText(d != null ? d.temp(f) : "--");
        temp.setTextDirection(View.TEXT_DIRECTION_LTR);
        col.addView(temp);
        TextView cond = text(18, TEXT, false); cond.setSingleLine(true);
        cond.setText(d != null ? d.text : act.getString(R.string.weather_no_data));
        cond.setEllipsize(android.text.TextUtils.TruncateAt.END);
        cond.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        col.addView(cond);
        if (d != null && !d.place.isEmpty()) col.addView(small(d.place, DIM, 14));
        if (d != null && d.windKph >= 1) col.addView(small(act.getString(R.string.weather_wind, Math.round(d.windKph)), DIM, 13));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1f); cl.setMarginStart(dp(14));
        top.addView(col, cl);
        card.addView(top);

        // ---- جدول التوقعات: صف لكل يوم (حتى 3) × الصبيحة / الظهيرة / الليل
        if (d != null && !d.days.isEmpty()) {
            card.addView(goldLine(), lp(-1, dp(1), 0, dp(12), 0, dp(6)));
            LinearLayout head = new LinearLayout(act);
            head.addView(new View(act), new LinearLayout.LayoutParams(0, 1, 0.8f));
            int[] names = {R.string.weather_morning, R.string.weather_noon, R.string.weather_night};
            for (int n : names) {
                TextView h = text(12, GOLD, true); h.setText(n); h.setGravity(Gravity.CENTER); h.setSingleLine(true);
                head.addView(h, new LinearLayout.LayoutParams(0, -2, 1f));
            }
            card.addView(head, new LinearLayout.LayoutParams(-1, -2));
            int n = Math.min(3, d.days.size());
            for (int i = 0; i < n; i++) {
                card.addView(dayRow(d.days.get(i), i == 0, f), lp(-1, -2, 0, dp(6), 0, 0));
            }
        }

        // ---- سطر الحالة: الخطأ ← الموقع الافتراضي ← آخر تحديث
        int err = WeatherRepository.errorText(act);
        if (err != 0) status(card, act.getString(err), WARN);
        if (WeatherRepository.city(act).trim().isEmpty() && DeviceLocation.usingFallback(act))
            status(card, act.getString(R.string.weather_loc_default), DIM);
        if (d != null)
            status(card, act.getString(R.string.weather_updated, DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(d.fetchedAt))), DIM);

        // ---- زر التحديث اليدوي (أسفل البطاقة؛ ↓ من البطاقة ثم OK)
        final TextView btn = text(14, GOLD_LIGHT, true);
        btn.setText(R.string.weather_refresh); btn.setGravity(Gravity.CENTER); btn.setSingleLine(true);
        btn.setPadding(dp(22), dp(8), dp(22), dp(8));
        btn.setFocusable(true); btn.setClickable(true);
        btn.setBackground(btnBg(false));
        btn.setOnFocusChangeListener((v, has) -> v.setBackground(btnBg(has)));
        btn.setOnKeyListener(OK_KEY);
        btn.setOnClickListener(v -> {
            long now = System.currentTimeMillis();
            if (now - lastManual < 60_000L) { btn.setText(R.string.weather_refresh_wait); return; }
            lastManual = now;
            btn.setText(R.string.weather_refreshing); btn.setEnabled(false);
            boolean started = WeatherRepository.refresh(act, true, () -> {
                if (onUpdate != null) onUpdate.run();
                if (dialog != null) show(WeatherRepository.cached(act));       // أعد رسم البطاقة بالنتيجة (أو بسبب الخطأ)
            });
            if (!started) { btn.setText(R.string.weather_refresh); btn.setEnabled(true); }
        });
        // ---- زر ⚙ بجانب التحديث → يفتح إعدادات الطقس
        final TextView gear = text(18, GOLD_LIGHT, true);
        gear.setText("\u2699"); gear.setTypeface(android.graphics.Typeface.DEFAULT); gear.setGravity(Gravity.CENTER); gear.setSingleLine(true);
        gear.setMinWidth(dp(48)); gear.setPadding(dp(16), dp(6), dp(16), dp(6));
        gear.setContentDescription(act.getString(R.string.ls_weather_section));
        gear.setFocusable(true); gear.setClickable(true);
        gear.setBackground(btnBg(false));
        gear.setOnFocusChangeListener((v, has) -> v.setBackground(btnBg(has)));
        gear.setOnKeyListener(OK_KEY);
        gear.setOnClickListener(v -> {
            dismiss();
            try { act.startActivity(new android.content.Intent(act, LauncherSettingsActivity.class)
                    .putExtra("section", "services").putExtra("open_weather", true)); } catch (Exception ignored) { }
        });
        btn.setId(View.generateViewId()); gear.setId(View.generateViewId());
        btn.setNextFocusRightId(gear.getId()); gear.setNextFocusLeftId(btn.getId());      // التنقل بين الزرين
        btn.setNextFocusLeftId(btn.getId());   gear.setNextFocusRightId(gear.getId());    // لا تخرج من البطاقة يمنة/يسرة
        btn.setNextFocusUpId(btn.getId());     gear.setNextFocusUpId(gear.getId());
        btn.setNextFocusDownId(btn.getId());   gear.setNextFocusDownId(gear.getId());
        LinearLayout row = new LinearLayout(act);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);       // الترتيب البصري ثابت: [↻ تحديث] [⚙] فيصح left/right
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(btn, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-2, -2); gl.setMarginStart(dp(12));
        row.addView(gear, gl);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2); bl.gravity = Gravity.CENTER_HORIZONTAL; bl.topMargin = dp(10);
        card.addView(row, bl);

        dlg.setContentView(root);
        dlg.setOnDismissListener(x -> dialog = null);
        dlg.show();
        btn.requestFocus();
    }

    // ===================== عناصر =====================
    private View dayRow(WeatherData.Day day, boolean today, boolean f) {
        LinearLayout r = new LinearLayout(act);
        r.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable rb = new GradientDrawable();              // شكل ملوّن لكل يوم (اليوم بلمسة ذهبية)
        rb.setColor(today ? 0x40E6BE5A : 0x26FFFFFF); rb.setCornerRadius(dp(14));
        rb.setStroke(Math.max(1, dp(1)), today ? 0x88E6BE5A : 0x33FFFFFF);
        r.setBackground(rb);
        r.setPadding(dp(12), dp(7), dp(12), dp(7));
        TextView name = text(14, today ? GOLD : TEXT, true); name.setSingleLine(true);
        name.setText(today ? act.getString(R.string.weather_today) : dayName(day.date));
        r.addView(name, new LinearLayout.LayoutParams(0, -2, 0.8f));
        for (int i = 0; i < 3; i++) r.addView(periodCell(day.periods[i], f), new LinearLayout.LayoutParams(0, -2, 1f));
        return r;
    }

    private View periodCell(WeatherData.Period p, boolean f) {
        LinearLayout c = new LinearLayout(act);
        c.setGravity(Gravity.CENTER);
        if (p == null) {
            TextView t = text(14, DIM, false); t.setText("—"); t.setGravity(Gravity.CENTER);
            c.addView(t, new LinearLayout.LayoutParams(-1, -2));
            return c;
        }
        ImageView ic = new ImageView(act); ic.setImageResource(p.iconRes()); ic.setColorFilter(p.tint());
        c.addView(ic, new LinearLayout.LayoutParams(dp(26), dp(26)));
        LinearLayout col = new LinearLayout(act); col.setOrientation(LinearLayout.VERTICAL);
        TextView t = text(16, TEXT, true); t.setText(p.temp(f)); t.setTextDirection(View.TEXT_DIRECTION_LTR);
        col.addView(t);
        if (p.windKph >= 1) col.addView(small(act.getString(R.string.weather_kmh, Math.round(p.windKph)), DIM, 11));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2); cl.setMarginStart(dp(6));
        c.addView(col, cl);
        return c;
    }

    private TextView small(String s, int color, int sp) {
        TextView t = text(sp, color, false); t.setText(s); t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        return t;
    }

    private String dayName(String yyyyMMdd) {
        try {
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            in.setTimeZone(TimeZone.getTimeZone("UTC"));
            SimpleDateFormat out = new SimpleDateFormat("EEEE", Locale.getDefault());
            out.setTimeZone(TimeZone.getTimeZone("UTC"));
            return out.format(in.parse(yyyyMMdd));
        } catch (Exception e) { return ""; }
    }

    private void status(LinearLayout card, String s, int color) {
        TextView t = text(12, color, false); t.setText(s); t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setPadding(0, dp(8), 0, 0);
        card.addView(t, new LinearLayout.LayoutParams(-1, -2));
    }

    private GradientDrawable btnBg(boolean focused) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(focused ? 0x55E6BE5A : 0x26FFFFFF); g.setCornerRadius(dp(20));
        g.setStroke(Math.max(1, dp(focused ? 3 : 1)), focused ? GOLD_LIGHT : 0x66E6BE5A);
        return g;
    }

    private View goldLine() {
        View v = new View(act);
        v.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0x00E6BE5A, 0xCCE6BE5A, 0x00E6BE5A}));
        return v;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h); p.setMargins(l, t, r, b); return p;
    }

    private GradientDrawable cardBg(boolean focused) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xF22A5CAA, 0xF2172F5E, 0xF2352C78});   // أزرق ملكي → نيلي: يتميّز عن الخلفية
        g.setCornerRadius(dp(28));
        g.setStroke(Math.max(1, dp(focused ? 3 : 1)), focused ? GOLD_LIGHT : 0x77F1D68A);
        return g;
    }

    private TextView text(int sp, int color, boolean bold) {
        TextView t = new TextView(act);
        t.setTextSize(sp); t.setTextColor(color);
        t.setTypeface(bold ? Fonts.bold(act) : Fonts.outfit(act));
        return t;
    }

    private int dp(float v) { return Math.round(v * density); }
}
