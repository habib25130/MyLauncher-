package com.myfamily.launcher;

import java.nio.charset.StandardCharsets;

/** مولّد QR مبسّط (بايت، تصحيح L، الإصدارات 1–6) بلا مكتبات. encode() يرجع مصفوفة وحدات (true = داكن). */
final class QrCode {
    // لكل إصدار (1..6): {إجمالي الكلمات، كلمات التصحيح لكل كتلة، عدد الكتل}
    private static final int[][] V = {{26, 7, 1}, {44, 10, 1}, {70, 15, 1}, {100, 20, 1}, {134, 26, 1}, {172, 18, 2}};
    private static final int[][] ALIGN = {{}, {6, 18}, {6, 22}, {6, 26}, {6, 30}, {6, 34}};

    static boolean[][] encode(String text) {
        byte[] data = text.getBytes(StandardCharsets.UTF_8);
        int ver = -1;
        for (int v = 0; v < V.length; v++) {
            int dataCw = V[v][0] - V[v][1] * V[v][2];
            if (4 + 8 + 8 * data.length <= dataCw * 8) { ver = v; break; }
        }
        if (ver < 0) throw new IllegalArgumentException("too long");
        int total = V[ver][0], ecLen = V[ver][1], blocks = V[ver][2], dataCw = total - ecLen * blocks;
        int size = 17 + 4 * (ver + 1);

        // 1) تدفق البتات
        StringBuilder bits = new StringBuilder();
        append(bits, 4, 4); append(bits, data.length, 8);
        for (byte b : data) append(bits, b & 0xFF, 8);
        int cap = dataCw * 8;
        append(bits, 0, Math.min(4, cap - bits.length()));
        while (bits.length() % 8 != 0) bits.append('0');
        for (int pad = 0xEC; bits.length() < cap; pad ^= 0xEC ^ 0x11) append(bits, pad, 8);
        byte[] cw = new byte[dataCw];
        for (int i = 0; i < dataCw; i++) cw[i] = (byte) Integer.parseInt(bits.substring(i * 8, i * 8 + 8), 2);

        // 2) كتل + Reed-Solomon + تداخل
        int per = dataCw / blocks;
        byte[][] db = new byte[blocks][], eb = new byte[blocks][];
        for (int b = 0; b < blocks; b++) {
            db[b] = java.util.Arrays.copyOfRange(cw, b * per, (b + 1) * per);
            eb[b] = rs(db[b], ecLen);
        }
        byte[] all = new byte[total]; int k = 0;
        for (int i = 0; i < per; i++) for (int b = 0; b < blocks; b++) all[k++] = db[b][i];
        for (int i = 0; i < ecLen; i++) for (int b = 0; b < blocks; b++) all[k++] = eb[b][i];

        // 3) الأنماط الوظيفية
        boolean[][] m = new boolean[size][size], fn = new boolean[size][size];
        finder(m, fn, 0, 0); finder(m, fn, size - 7, 0); finder(m, fn, 0, size - 7);
        for (int i = 8; i < size - 8; i++) { set(m, fn, 6, i, i % 2 == 0); set(m, fn, i, 6, i % 2 == 0); }
        int[] ap = ALIGN[ver];
        for (int r : ap) for (int c : ap) {
            if ((r == 6 && c == 6) || (r == 6 && c == ap[ap.length - 1]) || (r == ap[ap.length - 1] && c == 6)) continue;
            for (int dy = -2; dy <= 2; dy++) for (int dx = -2; dx <= 2; dx++)
                set(m, fn, r + dy, c + dx, Math.max(Math.abs(dx), Math.abs(dy)) != 1);
        }
        set(m, fn, size - 8, 8, true);                       // الوحدة الداكنة الثابتة
        for (int i = 0; i < 9; i++) { reserve(fn, 8, i); reserve(fn, i, 8); }
        for (int i = 0; i < 8; i++) { reserve(fn, 8, size - 1 - i); reserve(fn, size - 1 - i, 8); }

        // 4) وضع البيانات (زجزاج)
        int bi = 0;
        for (int right = size - 1; right >= 1; right -= 2) {
            if (right == 6) right = 5;
            for (int v = 0; v < size; v++) for (int j = 0; j < 2; j++) {
                int x = right - j; boolean up = ((right + 1) & 2) == 0;
                int y = up ? size - 1 - v : v;
                if (fn[y][x]) continue;
                m[y][x] = bi < total * 8 && ((all[bi >> 3] >> (7 - (bi & 7))) & 1) != 0; bi++;
            }
        }

        // 5) أفضل قناع
        int best = 0, bestPen = Integer.MAX_VALUE; boolean[][] bestM = null;
        for (int mask = 0; mask < 8; mask++) {
            boolean[][] t = new boolean[size][];
            for (int y = 0; y < size; y++) t[y] = m[y].clone();
            for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) if (!fn[y][x] && masked(mask, x, y)) t[y][x] = !t[y][x];
            drawFormat(t, size, mask);
            int pen = penalty(t, size);
            if (pen < bestPen) { bestPen = pen; best = mask; bestM = t; }
        }
        return bestM;
    }

    private static void append(StringBuilder sb, int v, int n) { for (int i = n - 1; i >= 0; i--) sb.append((v >> i) & 1); }
    private static void set(boolean[][] m, boolean[][] fn, int y, int x, boolean v) { if (y >= 0 && x >= 0 && y < m.length && x < m.length) { m[y][x] = v; fn[y][x] = true; } }
    private static void reserve(boolean[][] fn, int y, int x) { fn[y][x] = true; }
    private static void finder(boolean[][] m, boolean[][] fn, int top, int left) {
        for (int dy = -1; dy <= 7; dy++) for (int dx = -1; dx <= 7; dx++) {
            int y = top + dy, x = left + dx;
            boolean in = dy >= 0 && dy <= 6 && dx >= 0 && dx <= 6;
            boolean dark = in && (dy == 0 || dy == 6 || dx == 0 || dx == 6 || (dy >= 2 && dy <= 4 && dx >= 2 && dx <= 4));
            set(m, fn, y, x, dark);
        }
    }
    private static boolean masked(int mask, int x, int y) {
        switch (mask) {
            case 0: return (x + y) % 2 == 0;
            case 1: return y % 2 == 0;
            case 2: return x % 3 == 0;
            case 3: return (x + y) % 3 == 0;
            case 4: return (x / 3 + y / 2) % 2 == 0;
            case 5: return x * y % 2 + x * y % 3 == 0;
            case 6: return (x * y % 2 + x * y % 3) % 2 == 0;
            default: return ((x + y) % 2 + x * y % 3) % 2 == 0;
        }
    }
    private static void drawFormat(boolean[][] m, int size, int mask) {
        int data = (1 << 3) | mask;                           // مستوى L = 01
        int rem = data;
        for (int i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >> 9) * 0x537);
        int bits = ((data << 10) | rem) ^ 0x5412;
        for (int i = 0; i <= 5; i++) m[i][8] = bit(bits, i);
        m[7][8] = bit(bits, 6); m[8][8] = bit(bits, 7); m[8][7] = bit(bits, 8);
        for (int i = 9; i < 15; i++) m[8][14 - i] = bit(bits, i);
        for (int i = 0; i < 8; i++) m[8][size - 1 - i] = bit(bits, i);
        for (int i = 8; i < 15; i++) m[size - 15 + i][8] = bit(bits, i);
        m[size - 8][8] = true;
    }
    private static boolean bit(int v, int i) { return ((v >> i) & 1) != 0; }

    private static int penalty(boolean[][] m, int n) {
        int pen = 0;
        for (int pass = 0; pass < 2; pass++) {
            for (int a = 0; a < n; a++) {
                int run = 1;
                for (int b = 1; b < n; b++) {
                    boolean cur = pass == 0 ? m[a][b] : m[b][a], prev = pass == 0 ? m[a][b - 1] : m[b - 1][a];
                    if (cur == prev) { run++; if (run == 5) pen += 3; else if (run > 5) pen++; } else run = 1;
                }
            }
        }
        for (int y = 0; y < n - 1; y++) for (int x = 0; x < n - 1; x++)
            if (m[y][x] == m[y][x + 1] && m[y][x] == m[y + 1][x] && m[y][x] == m[y + 1][x + 1]) pen += 3;
        int dark = 0; for (boolean[] r : m) for (boolean v : r) if (v) dark++;
        pen += Math.abs(dark * 20 - n * n * 10) / (n * n) * 10;
        return pen;
    }

    // Reed-Solomon على GF(256) بكثير الحدود 0x11D
    private static byte[] rs(byte[] data, int ecLen) {
        int[] exp = new int[512], log = new int[256];
        int x = 1;
        for (int i = 0; i < 255; i++) { exp[i] = x; log[x] = i; x <<= 1; if (x >= 256) x ^= 0x11D; }
        for (int i = 255; i < 512; i++) exp[i] = exp[i - 255];
        int[] gen = {1};
        for (int i = 0; i < ecLen; i++) {
            int[] ng = new int[gen.length + 1];
            for (int j = 0; j < gen.length; j++) {
                ng[j] ^= gen[j];
                ng[j + 1] ^= gen[j] == 0 ? 0 : exp[log[gen[j]] + i];
            }
            gen = ng;
        }
        int[] res = new int[ecLen];
        for (byte d : data) {
            int f = (d & 0xFF) ^ res[0];
            System.arraycopy(res, 1, res, 0, ecLen - 1); res[ecLen - 1] = 0;
            if (f != 0) for (int j = 0; j < ecLen; j++) res[j] ^= gen[j + 1] == 0 ? 0 : exp[log[f] + log[gen[j + 1]]];
        }
        byte[] out = new byte[ecLen];
        for (int i = 0; i < ecLen; i++) out[i] = (byte) res[i];
        return out;
    }
}
