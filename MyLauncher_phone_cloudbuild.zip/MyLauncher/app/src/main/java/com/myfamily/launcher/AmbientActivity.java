package com.myfamily.launcher;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * شاشة الاستماع: موجة/نغمات/سواد أثناء تشغيل الراديو. أي زر يُظهر شريط الأدوات
 * (الشكل · اللون · السطوع · مؤقت النوم) لثوانٍ، وزر الرجوع يغلقه ثم يخرج.
 * تُغلق نفسها عند توقف الراديو (مثلاً عند انتهاء مؤقت النوم).
 */
public class AmbientActivity extends Activity implements RadioPlayer.Listener {
    private static final int[] SLEEP = {0, 15, 30, 60, 90};
    private static final int ACCENT = 0xFFB8EEFF;

    private SharedPreferences p;
    private RadioPlayer rp;
    private AmbientView scene;
    private LinearLayout strip;
    private final TextView[] pills = new TextView[4];
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean stripOn, dead;
    private int sleepIdx;

    private final Runnable hide = this::hideStrip;
    private final Runnable exit = this::finish;
    private final Runnable refresh = new Runnable() {
        @Override public void run() { updatePills(); h.postDelayed(this, 20_000L); }
    };

    @Override protected void attachBaseContext(Context base) { super.attachBaseContext(LocaleHelper.wrap(base)); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = getSharedPreferences("launcher", MODE_PRIVATE);
        rp = RadioPlayer.get(this);
        if (rp.state() == RadioPlayer.State.STOPPED || rp.state() == RadioPlayer.State.ERROR) { dead = true; finish(); return; }

        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        w.setBackgroundDrawable(new ColorDrawable(Color.BLACK));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        scene = new AmbientView(this);
        scene.setStyle(p.getInt("amb_style", 0));
        scene.setPalette(p.getInt("amb_palette", 0));
        scene.setBrightness(p.getInt("amb_bright", 1));
        root.addView(scene, new FrameLayout.LayoutParams(-1, -1));

        strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.VERTICAL);
        strip.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView hint = new TextView(this);
        hint.setText(R.string.amb_hint); hint.setTextSize(14); hint.setTextColor(0xAAFFFFFF);
        hint.setTypeface(Fonts.outfit(this)); hint.setPadding(0, 0, 0, dp(10));
        strip.addView(hint);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setTextSize(18); t.setTextColor(Color.WHITE); t.setTypeface(Fonts.outfit(this));
            t.setPadding(dp(20), dp(14), dp(20), dp(14));
            t.setFocusable(true); t.setClickable(true);
            t.setBackground(pillBg(false));
            t.setOnFocusChangeListener((v, f) -> v.setBackground(pillBg(f)));
            t.setOnClickListener(v -> onPill(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMargins(dp(6), 0, dp(6), 0);
            row.addView(t, lp);
            pills[i] = t;
        }
        strip.addView(row);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        sp.bottomMargin = dp(48);
        root.addView(strip, sp);
        strip.setVisibility(View.INVISIBLE); strip.setAlpha(0f);
        setContentView(root);

        int left = rp.sleepMinutesLeft();
        for (int i = 0; i < SLEEP.length; i++) if (left > 0 && SLEEP[i] >= left && sleepIdx == 0) sleepIdx = i;
        applyWindowBrightness();
        immersive();
        updatePills();
    }

    // ===================== دورة الحياة =====================
    @Override protected void onStart() {
        super.onStart();
        if (dead) return;
        rp.addListener(this);
        onRadioState(rp.state(), rp.current(), rp.errorRes());
        h.removeCallbacks(refresh); h.postDelayed(refresh, 20_000L);
    }

    @Override protected void onStop() {
        if (!dead) rp.removeListener(this);
        h.removeCallbacksAndMessages(null);
        super.onStop();
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) immersive(); }

    @SuppressWarnings("deprecation")
    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    // ===================== حالة الراديو =====================
    @Override public void onRadioState(RadioPlayer.State s, RadioStation st, int err) {
        if (dead || scene == null) return;
        h.removeCallbacks(exit);
        scene.setTarget(s == RadioPlayer.State.PLAYING ? 1f : s == RadioPlayer.State.LOADING ? 0.3f : 0f);
        scene.setLabel(st != null ? st.name : "");
        if (s == RadioPlayer.State.STOPPED) { finish(); return; }          // توقف (مؤقت النوم أو غيره): نعود للشاشة الرئيسية
        if (s == RadioPlayer.State.ERROR) {
            scene.setLabel(getString(err != 0 ? err : R.string.radio_err_generic));
            h.postDelayed(exit, 4000L);
        }
        updatePills();
    }

    // ===================== شريط الأدوات =====================
    private void onPill(int i) {
        switch (i) {
            case 0: { int n = (p.getInt("amb_style", 0) + 1) % 3; p.edit().putInt("amb_style", n).apply(); scene.setStyle(n); break; }
            case 1: { int n = (p.getInt("amb_palette", 0) + 1) % 3; p.edit().putInt("amb_palette", n).apply(); scene.setPalette(n); break; }
            case 2: { int n = (p.getInt("amb_bright", 1) + 1) % 3; p.edit().putInt("amb_bright", n).apply(); scene.setBrightness(n); applyWindowBrightness(); break; }
            default: { sleepIdx = (sleepIdx + 1) % SLEEP.length; rp.setSleepTimer(SLEEP[sleepIdx]); break; }
        }
        updatePills();
        h.removeCallbacks(hide); h.postDelayed(hide, 6000L);
    }

    private void updatePills() {
        if (pills[0] == null) return;
        String[] st = {getString(R.string.amb_s_ribbon), getString(R.string.amb_s_notes), getString(R.string.amb_s_black)};
        String[] pa = {getString(R.string.amb_p_spectrum), getString(R.string.amb_p_amber), getString(R.string.amb_p_gold)};
        String[] br = {getString(R.string.amb_b_low), getString(R.string.amb_b_mid), getString(R.string.amb_b_high)};
        pills[0].setText(getString(R.string.amb_style_fmt, st[clamp(p.getInt("amb_style", 0))]));
        pills[1].setText(getString(R.string.amb_palette_fmt, pa[clamp(p.getInt("amb_palette", 0))]));
        pills[2].setText(getString(R.string.amb_bright_fmt, br[clamp(p.getInt("amb_bright", 1))]));
        int left = rp.sleepMinutesLeft();
        pills[3].setText(getString(R.string.amb_sleep_fmt, left > 0 ? getString(R.string.amb_min_fmt, left) : getString(R.string.amb_sleep_off)));
    }

    private void showStrip() {
        updatePills();
        stripOn = true;
        strip.setVisibility(View.VISIBLE);
        strip.animate().alpha(1f).setDuration(160).start();
        pills[0].requestFocus();
        h.removeCallbacks(hide); h.postDelayed(hide, 6000L);
    }

    private void hideStrip() {
        stripOn = false;
        h.removeCallbacks(hide);
        strip.animate().alpha(0f).setDuration(200).withEndAction(() -> { if (!stripOn) strip.setVisibility(View.INVISIBLE); }).start();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        if (k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN || k == KeyEvent.KEYCODE_VOLUME_MUTE
                || k == KeyEvent.KEYCODE_POWER || k == KeyEvent.KEYCODE_HEADSETHOOK
                || (k >= KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE && k <= KeyEvent.KEYCODE_MEDIA_FAST_FORWARD)) {
            return super.dispatchKeyEvent(e);                         // مفاتيح النظام تمرّ كما هي
        }
        if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_ESCAPE) {
            if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) { if (stripOn) hideStrip(); else finish(); }
            return true;
        }
        if (e.getAction() == KeyEvent.ACTION_DOWN && !stripOn) { showStrip(); return true; }   // أول ضغطة تُظهر الأدوات فقط
        if (!stripOn) return true;
        if (e.getAction() == KeyEvent.ACTION_DOWN) { h.removeCallbacks(hide); h.postDelayed(hide, 6000L); }
        return super.dispatchKeyEvent(e);
    }

    // ===================== أدوات =====================
    private void applyWindowBrightness() {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        int b = p.getInt("amb_bright", 1);
        lp.screenBrightness = b == 0 ? 0.2f : b == 1 ? 0.5f : WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
        getWindow().setAttributes(lp);                                // بعض التلفازات تتجاهل هذا الطلب
    }

    private GradientDrawable pillBg(boolean focused) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(26));
        g.setColor(focused ? 0xE61B2A3E : 0xCC10151F);
        g.setStroke(dp(focused ? 3 : 1), focused ? ACCENT : 0x55FFFFFF);
        return g;
    }

    private static int clamp(int v) { return Math.max(0, Math.min(2, v)); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
