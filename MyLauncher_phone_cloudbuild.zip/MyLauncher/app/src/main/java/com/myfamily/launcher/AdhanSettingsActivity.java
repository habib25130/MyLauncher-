package com.myfamily.launcher;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

public class AdhanSettingsActivity extends Activity {
    static final int TEXT = Color.WHITE, DIM = 0xCCFFFFFF, ACCENT = 0xFF6FD8FF;
    private SharedPreferences p;
    private LinearLayout nav, content;
    private ScrollView scroll;
    private int sel = 0, focusSub = -1;
    private boolean building = false;   // يمنع إعادة البناء المتداخلة (كانت تكرّر المحتوى)
    private String[] SECTIONS;

    @Override protected void attachBaseContext(Context base) { super.attachBaseContext(LocaleHelper.wrap(base)); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = Adhan.p(this);
        Adhan.load(this);
        SECTIONS = new String[]{getString(R.string.sec_overview), getString(R.string.sec_modes), getString(R.string.sec_audio),
                getString(R.string.sec_volume), getString(R.string.sec_auto), getString(R.string.sec_banner)};
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(40), dp(24), dp(40), dp(16));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF08111F, 0xFF12384F}));
        TextView title = text(28, TEXT, true); title.setText(R.string.adhan_settings);
        TextView hint = text(15, DIM, false); hint.setText(R.string.adhan_hint);
        hint.setPadding(0, dp(4), 0, dp(14));
        LinearLayout body = new LinearLayout(this);
        nav = new LinearLayout(this); nav.setOrientation(LinearLayout.VERTICAL);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(24), 0, dp(8), dp(24));
        scroll = new ScrollView(this); scroll.addView(content);
        for (int i = 0; i < SECTIONS.length; i++) {
            final int idx = i;
            TextView t = text(18, TEXT, false); t.setText(SECTIONS[i]);
            t.setPadding(dp(18), dp(14), dp(18), dp(14));
            t.setFocusable(true); t.setClickable(true);
            style(t, false);
            t.setOnFocusChangeListener((v, f) -> { style(v, f); if (f && !building) { sel = idx; show(-1); } });
            t.setOnClickListener(v -> { sel = idx; show(0); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(8);
            nav.addView(t, lp);
        }
        body.addView(nav, new LinearLayout.LayoutParams(dp(250), -2));
        body.addView(scroll, new LinearLayout.LayoutParams(0, -1, 1));
        root.addView(title); root.addView(hint); root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        show(-1);
        nav.getChildAt(0).requestFocus();
    }

    @Override protected void onPause() { super.onPause(); Adhan.schedule(this); }

    /** يعيد بناء اللوحة اليمنى. focusIdx ≥ 0 يعيد التركيز على الصف نفسه بعد التغيير. */
    private void show(int focusIdx) {
        if (building) return;
        building = true;
        content.removeAllViews();
        TextView h = text(26, ACCENT, true); h.setText(SECTIONS[sel]); h.setPadding(0, 0, 0, dp(12));
        content.addView(h);
        switch (sel) {
            case 0:
                toggle(getString(R.string.enable_adhan), "adhan_on", false);
                note(getString(R.string.enable_adhan_note));
                row(getString(R.string.iqama_delay, iqamaLabel()), () -> {
                    int[] opts = {0, 5, 10, 15, 20, 25, 30};
                    int cur = p.getInt("iqama_min", 10), nx = opts[0];
                    for (int i = 0; i < opts.length; i++) if (opts[i] == cur) nx = opts[(i + 1) % opts.length];
                    p.edit().putInt("iqama_min", nx).apply();
                });
                note(getString(R.string.prayer_city_line, p.getString("city", getString(R.string.default_city))));
                note(getString(R.string.timezone_line, p.getString("tz", "Africa/Algiers")));
                int m = p.getInt("method", 19);
                String mn = ""; for (int i = 0; i < PrayerTimes.TABLE.length; i++) if ((int) PrayerTimes.TABLE[i][0] == m) mn = getResources().getStringArray(R.array.method_names)[i];
                note(getString(R.string.method_line, String.valueOf(m), mn));
                row(getString(R.string.city_and_method), () -> startActivity(new Intent(this, MainActivity.class).putExtra("dlg", "city")));
                row(getString(R.string.test_adhan), () -> Adhan.play(this, 1));
                row(getString(R.string.stop_sound), () -> Adhan.stop(this));
                break;
            case 1:
                for (int k = 0; k < 5; k++) modeRow(k);
                break;
            case 2:
                String[] src = {getString(R.string.audio_file), getString(R.string.audio_system)};
                for (int s = 0; s < 2; s++) {
                    final int ss = s;
                    row((Adhan.source(this) == s ? "◉  " : "○  ") + src[s], () -> p.edit().putInt("adhan_src", ss).apply());
                }
                note(getString(R.string.audio_note));
                break;
            case 3:
                for (int v = 20; v <= 100; v += 20) {
                    final int vv = v;
                    row((Adhan.volume(this) == v ? "◉  " : "○  ") + v + "%", () -> p.edit().putInt("adhan_vol", vv).apply());
                }
                row(getString(R.string.test_sound), () -> Adhan.play(this, 1));
                break;
            case 4:
                toggle(getString(R.string.auto_adhan), "adhan_auto", true);
                note(getString(R.string.auto_note));
                break;
            case 5: {
                toggle(getString(R.string.pb_enable), "adhan_banner", true);
                note(getString(R.string.pb_enable_note));
                String[] bnPos = {getString(R.string.pb_pos_bottom), getString(R.string.pb_pos_top)};
                row(getString(R.string.pb_pos_fmt, bnPos[Math.max(0, Math.min(1, p.getInt("adhan_bn_pos", 0)))]),
                        () -> p.edit().putInt("adhan_bn_pos", (p.getInt("adhan_bn_pos", 0) + 1) % 2).apply());
                String[] bnType = {getString(R.string.pb_type_thick), getString(R.string.pb_type_thin), getString(R.string.pb_type_none)};
                row(getString(R.string.pb_type_fmt, bnType[Math.max(0, Math.min(2, p.getInt("adhan_bn_type", 0)))]),
                        () -> p.edit().putInt("adhan_bn_type", (p.getInt("adhan_bn_type", 0) + 1) % 3).apply());
                note(getString(R.string.pb_type_note));
                String[] bnColor = {getString(R.string.pb_c0), getString(R.string.pb_c1), getString(R.string.pb_c2), getString(R.string.pb_c3)};
                row(getString(R.string.pb_color_fmt, bnColor[Math.max(0, Math.min(3, p.getInt("adhan_bn_color", 0)))]),
                        () -> p.edit().putInt("adhan_bn_color", (p.getInt("adhan_bn_color", 0) + 1) % 4).apply());
                final String[] bnFonts = PrayerBanner.fontNames(this);
                int bnF = p.getInt("adhan_bn_font", 0);
                row(getString(R.string.pb_font_fmt, bnFonts[bnF >= 0 && bnF < bnFonts.length ? bnF : 0]),
                        () -> p.edit().putInt("adhan_bn_font", (p.getInt("adhan_bn_font", 0) + 1) % bnFonts.length).apply());
                note(getString(R.string.pb_font_note));
                String[] bnSize = {getString(R.string.pb_size0), getString(R.string.pb_size1), getString(R.string.pb_size2)};
                row(getString(R.string.pb_size_fmt, bnSize[Math.max(0, Math.min(2, p.getInt("adhan_bn_size", 1)))]),
                        () -> p.edit().putInt("adhan_bn_size", (p.getInt("adhan_bn_size", 1) + 1) % 3).apply());
                toggle(getString(R.string.pb_glow), "adhan_bn_glow", false);
                toggle(getString(R.string.pb_reminder), "adhan_reminder", true);
                note(getString(R.string.pb_reminder_note));
                toggle(getString(R.string.pb_pause), "adhan_pause", true);
                note(getString(R.string.pb_pause_note));
                row(getString(R.string.pb_preview), () -> {
                    if (PrayerBanner.get().canShow(this)) PrayerBanner.get().preview(this);
                    else { PrayerBanner.get().previewInActivity(this); Toast.makeText(this, R.string.pb_inapp, Toast.LENGTH_LONG).show(); }
                });
                row(getString(R.string.pb_test_full), () -> {
                    if (!PrayerBanner.get().canShow(this)) PrayerBanner.get().previewInActivity(this);
                    Adhan.play(this, 1);                       // الشريط الحقيقي (إن أمكن) + الأذان؛ OK أو رجوع يوقفه
                });
                row(getString(R.string.stop_sound), () -> Adhan.stop(this));
                if (!PrayerBanner.get().canShow(this)) {
                    note(getString(R.string.pb_need_perm));
                    row(getString(R.string.pb_enable_service), () -> {
                        if (HomeKeyService.enableViaSecureSettings(this)) Toast.makeText(this, R.string.home_enabled, Toast.LENGTH_LONG).show();
                        else try { startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
                        catch (Exception ex) { Toast.makeText(this, R.string.pb_cant, Toast.LENGTH_LONG).show(); }
                    });
                }
                break;
            }
        }
        building = false;
        if (focusTag != null) {
            View tv = content.findViewWithTag(focusTag);
            focusTag = null; focusSub = -1;
            if (tv != null) { tv.requestFocus(); return; }
        }
        if (focusIdx >= 0 && focusIdx < content.getChildCount()) {
            View c = content.getChildAt(focusIdx);
            if (focusSub >= 0 && c instanceof LinearLayout) c = ((LinearLayout) c).getChildAt(1 + focusSub);
            c.requestFocus();
        }
        focusSub = -1;
    }

    private String iqamaLabel() {
        int v = p.getInt("iqama_min", 10);
        return v == 0 ? getString(R.string.off) : getString(R.string.iq_value, v);
    }

    private static final int[] TIME_IDX = {0, 2, 3, 4, 5};   // ترتيب الصلوات في الإعدادات ← فهرسها في PrayerTimes
    private String focusTag;

    /** بطاقة صلاة: الاسم + وقتها اليوم (بعد التعديل) + قائمة منسدلة لتعديل الدقائق، وتحتها أزرار الوضع (معطّل / أذان كامل / تنبيه قصير). */
    private void modeRow(final int k) {
        final int idx = content.getChildCount();
        final int ti = TIME_IDX[k];
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable cg = new GradientDrawable(); cg.setCornerRadius(dp(18)); cg.setColor(0x22FFFFFF); cg.setStroke(dp(1), 0x33FFFFFF);
        card.setBackground(cg); card.setPadding(dp(14), dp(10), dp(14), dp(12));

        // السطر الأول: الاسم · وقت اليوم · قائمة تعديل الدقائق
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(20, TEXT, true); name.setText(Adhan.prayers(this)[k]);
        top.addView(name, new LinearLayout.LayoutParams(dp(110), -2));
        int adj = PrayerTimes.ADJ[ti];
        double[] today = PrayerTimes.compute(java.util.Calendar.getInstance(PrayerTimes.TZ));
        TextView time = text(20, ACCENT, true);
        time.setText(PrayerTimes.fmt(today[ti]) + (adj != 0 ? "  (" + (adj > 0 ? "+" : "") + adj + ")" : ""));
        top.addView(time, new LinearLayout.LayoutParams(dp(150), -2));
        final TextView dd = text(18, TEXT, false);
        dd.setText(getString(R.string.adjust_minutes) + ":  " + signed(adj) + "  ▾");
        dd.setGravity(Gravity.CENTER); dd.setPadding(dp(12), dp(12), dp(12), dp(12));
        dd.setFocusable(true); dd.setClickable(true); dd.setTag("a" + k);
        styleOpt(dd, false, false);
        dd.setOnFocusChangeListener((v, f) -> styleOpt(v, f, false));
        dd.setOnClickListener(v -> showAdjustMenu(dd, k, ti, idx));
        top.addView(dd, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(top);

        // السطر الثاني: أزرار الوضع
        LinearLayout modeRow = new LinearLayout(this); modeRow.setGravity(Gravity.CENTER_VERTICAL);
        modeRow.setPadding(0, dp(8), 0, 0);
        TextView lab = text(14, DIM, false); lab.setText(R.string.prayer_mode_label);
        modeRow.addView(lab, new LinearLayout.LayoutParams(dp(110), -2));
        String[] modes = Adhan.modes(this);
        int cur = Adhan.mode(this, k);
        for (int m = 0; m < modes.length; m++) {
            final int mm = m;
            TextView c = text(16, TEXT, false);
            c.setText(modes[m]);
            c.setGravity(Gravity.CENTER); c.setPadding(dp(6), dp(10), dp(6), dp(10));
            c.setFocusable(true); c.setClickable(true); c.setTag("m" + k + "_" + m);
            styleOpt(c, false, cur == m);
            c.setOnFocusChangeListener((view, f) -> styleOpt(view, f, Adhan.mode(this, k) == mm));
            c.setOnClickListener(view -> {
                p.edit().putInt("adhan_mode" + k, mm).apply();
                focusTag = "m" + k + "_" + mm;
                show(idx);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.setMargins(dp(3), 0, dp(3), 0);
            modeRow.addView(c, lp);
        }
        card.addView(modeRow);
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2); rl.bottomMargin = dp(10);
        content.addView(card, rl);
    }

    private static String signed(int v) { return v > 0 ? "+" + v : String.valueOf(v); }

    /** القائمة المنسدلة لتعديل الدقائق (−4 … +4). */
    private void showAdjustMenu(View anchor, final int k, final int ti, final int idx) {
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(0xFF0B1626); bg.setCornerRadius(dp(16)); bg.setStroke(dp(1), 0x66FFFFFF);
        ScrollView sv = new ScrollView(this); sv.addView(list); sv.setBackground(bg);
        final PopupWindow pw = new PopupWindow(sv, Math.max(anchor.getWidth(), dp(220)), dp(380), true);
        pw.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        int cur = PrayerTimes.ADJ[ti];
        View focus = null;
        for (int v = -4; v <= 4; v++) {
            final int val = v;
            TextView t = text(18, TEXT, false);
            t.setText((cur == v ? "✓  " : "") + signed(v));
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(16), dp(12), dp(16), dp(12));
            t.setFocusable(true); t.setClickable(true);
            styleOpt(t, false, cur == v);
            t.setOnFocusChangeListener((view, f) -> styleOpt(view, f, PrayerTimes.ADJ[ti] == val));
            t.setOnClickListener(view -> {
                p.edit().putInt("padj" + ti, val).apply();
                PrayerTimes.ADJ[ti] = val;                    // يُطبَّق فورًا على الوقت المعروض والأذان القادم
                Adhan.schedule(this);
                pw.dismiss();
                focusTag = "a" + k;
                show(idx);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(4);
            list.addView(t, lp);
            if (v == cur) focus = t;
        }
        pw.showAsDropDown(anchor, 0, dp(4));
        if (focus != null) focus.requestFocus();
    }

    private void styleOpt(View v, boolean focused, boolean selected) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(16));
        g.setColor(selected ? 0xFF143B52 : 0xFF11213A);
        g.setStroke(dp(focused || selected ? 3 : 1), focused ? 0xFFB8EEFF : selected ? 0xFF4FA8CC : 0x55FFFFFF);
        v.setBackground(g);
    }

    private void toggle(String label, String key, boolean def) {
        row(label + " · " + getString(p.getBoolean(key, def) ? R.string.on : R.string.off), () -> p.edit().putBoolean(key, !p.getBoolean(key, def)).apply());
    }

    private void row(String label, Runnable r) {
        final int idx = content.getChildCount();
        TextView t = text(19, TEXT, false); t.setText(label);
        t.setPadding(dp(20), dp(16), dp(20), dp(16));
        t.setFocusable(true); t.setClickable(true);
        style(t, false);
        t.setOnFocusChangeListener((v, f) -> style(v, f));
        t.setOnClickListener(v -> { r.run(); show(idx); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(8);
        content.addView(t, lp);
    }

    private void note(String s) {
        TextView t = text(15, DIM, false); t.setText(s); t.setPadding(dp(4), dp(4), dp(4), dp(10));
        content.addView(t);
    }

    private void style(View v, boolean focused) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(16)); g.setColor(focused ? 0xFF1B4560 : 0xFF11213A);
        g.setStroke(dp(focused ? 3 : 1), focused ? ACCENT : 0x55FFFFFF);
        v.setBackground(g);
    }
    private TextView text(int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
