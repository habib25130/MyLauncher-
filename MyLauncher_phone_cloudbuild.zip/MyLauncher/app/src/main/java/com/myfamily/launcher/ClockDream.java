package com.myfamily.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.service.dreams.DreamService;
import android.view.*;
import android.widget.*;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * شاشة التوقف: ساعة (رقمية أو بعقارب 24 ساعة أو الاثنتان، من إعدادات اللانشر) + التاريخ الميلادي والهجري + الصلاة القادمة،
 * فوق خلفية اللانشر، وتتحرك ببطء لحماية الشاشة. صيغة الساعة (12/24) تتبع إعداد اللانشر نفسه.
 */
public class ClockDream extends DreamService {
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Background bg = new Background();
    private LinearLayout box;
    private DigitalClock digital;
    private AnalogClock analog;
    private TextView date, hijri, pName, pSub, pCity;
    private SharedPreferences prefs;
    private int step = 0;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            Calendar now = Calendar.getInstance();
            int cf = prefs.getInt("clock_fmt", 0);                       // 0 = النظام، 1 = 12 ساعة، 2 = 24 ساعة (مثل الشاشة الرئيسية)
            boolean h24 = cf == 2 || (cf == 0 && android.text.format.DateFormat.is24HourFormat(ClockDream.this));
            if (digital != null) {
                String t = new SimpleDateFormat(h24 ? "HH:mm" : "h:mm", Locale.US).format(now.getTime());
                String suffix = h24 ? "" : new DateFormatSymbols(Locale.getDefault()).getAmPmStrings()[now.get(Calendar.AM_PM)];
                digital.setTime(t, suffix);
            }
            if (analog != null) analog.setTime(now, h24);
            date.setText(LocaleHelper.westernDigits(new SimpleDateFormat("EEEE d MMMM yyyy", Locale.getDefault()).format(now.getTime())));
            hijri.setText(Hijri.format(ClockDream.this));
            try {
                String[] p = PrayerInfo.next(ClockDream.this);
                pName.setText(p[0]); pSub.setText(p[1]); pCity.setText(p[2]);
            } catch (Throwable ignored) { }
            h.postDelayed(this, 60000 - (System.currentTimeMillis() % 60000) + 100);   // عند بداية كل دقيقة بالضبط
        }
    };

    private boolean is24() {
        int cf = prefs.getInt("clock_fmt", 0);
        return cf == 2 || (cf == 0 && android.text.format.DateFormat.is24HourFormat(this));
    }

    /** عقرب الثواني: تحديث كل ثانية للساعة ذات العقارب فقط. */
    private final Runnable tickSec = new Runnable() {
        @Override public void run() {
            if (analog != null) analog.setTime(Calendar.getInstance(), is24());
            h.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000) + 5);
        }
    };

    private final Runnable drift = new Runnable() {
        @Override public void run() {
            float[][] pos = {{-0.12f, -0.10f}, {0.12f, -0.06f}, {0.10f, 0.12f}, {-0.10f, 0.08f}};
            step = (step + 1) % pos.length;
            View p = (View) box.getParent();
            box.animate().translationX(pos[step][0] * p.getWidth()).translationY(pos[step][1] * p.getHeight()).setDuration(4000).start();
            h.postDelayed(this, 60000);
        }
    };

    @Override protected void attachBaseContext(Context base) { super.attachBaseContext(LocaleHelper.wrap(base)); }

    @Override public void onAttachedToWindow() {
        super.onAttachedToWindow();
        setInteractive(false); setFullscreen(true);
        prefs = getSharedPreferences("launcher", MODE_PRIVATE);
        int style = prefs.getInt("dream_clock", 0);                      // 0 رقمية، 1 بعقارب، 2 الاثنتان
        boolean wantDigital = style != 1, wantAnalog = style != 0;
        int screenH = getResources().getDisplayMetrics().heightPixels;

        FrameLayout root = new FrameLayout(this);
        root.setClipChildren(false);
        FrameLayout holder = new FrameLayout(this);
        bg.apply(this, holder);
        root.addView(holder, new FrameLayout.LayoutParams(-1, -1));
        View dim = new View(this); dim.setBackgroundColor(0x77000000);
        root.addView(dim, new FrameLayout.LayoutParams(-1, -1));

        box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setClipChildren(false); box.setClipToPadding(false);

        LinearLayout clocks = new LinearLayout(this); clocks.setGravity(Gravity.CENTER_VERTICAL); clocks.setClipChildren(false);
        if (wantAnalog) {
            int d = Math.round(screenH * (wantDigital ? 0.34f : 0.48f));
            int dial = prefs.getInt("dream_dial", prefs.getBoolean("dream_dial_light", false) ? 1 : 0);   // 0 أسود 24س، 1 أبيض 24س، 2 مرجاني
            analog = new AnalogClock(this, dial, !wantDigital);
            clocks.addView(analog, new LinearLayout.LayoutParams(d, d));
        }
        if (wantDigital) {
            digital = new DigitalClock(this, Fonts.bold(this), screenH * (wantAnalog ? 0.15f : 0.21f));
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-2, -2);
            if (wantAnalog) dl.setMarginStart(dp(28));
            clocks.addView(digital, dl);
        }
        box.addView(clocks, new LinearLayout.LayoutParams(-2, -2));

        date = text(26, 0xFFFFFFFF, false); hijri = text(24, 0xFFE9C46A, false);
        LinearLayout.LayoutParams datel = new LinearLayout.LayoutParams(-2, -2); datel.topMargin = dp(8);
        box.addView(date, datel); box.addView(hijri);

        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(32), dp(16), dp(32), dp(16));
        GradientDrawable g = new GradientDrawable(); g.setColor(0x44FFFFFF); g.setCornerRadius(dp(24)); g.setStroke(dp(1), 0x66FFFFFF);
        card.setBackground(g);
        pCity = text(15, 0xCCFFFFFF, false); pName = text(34, Color.WHITE, true); pSub = text(18, 0xFFFFFFFF, false);
        card.addView(pCity); card.addView(pName); card.addView(pSub);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2); cl.topMargin = dp(24);
        box.addView(card, cl);

        root.addView(box, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        setContentView(root);
    }

    @Override public void onDreamingStarted() {
        super.onDreamingStarted();
        h.post(tick); h.post(tickSec); h.postDelayed(drift, 60000);
    }

    @Override public void onDreamingStopped() { h.removeCallbacksAndMessages(null); bg.stop(); super.onDreamingStopped(); }
    @Override public void onDetachedFromWindow() { h.removeCallbacksAndMessages(null); bg.stop(); super.onDetachedFromWindow(); }

    private TextView text(int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        t.setTypeface(bold ? Fonts.bold(this) : Fonts.outfit(this));
        t.setShadowLayer(8, 0, 2, 0x99000000);
        return t;
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    /**
     * ساعة رقمية تُرسم مباشرة بـ Canvas: العرض يُقاس من أعرض رقم في الخط نفسه (×4 + النقطتان + ص/م) مع هامش أمان،
     * فلا يُقص أي رقم (كان يظهر «10:3» بدل «10:31») ولا تهتز الساعة عند تغيّر الأرقام.
     */
    private static class DigitalClock extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), sp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private String time = "00:00", suffix = "";
        private final float pad;

        DigitalClock(Context c, Typeface tf, float sizePx) {
            super(c);
            p.setTypeface(tf); p.setTextSize(sizePx); p.setColor(Color.WHITE); p.setShadowLayer(8, 0, 2, 0x99000000);
            sp.setTypeface(tf); sp.setTextSize(sizePx * 0.30f); sp.setColor(0xFFFFFFFF); sp.setShadowLayer(6, 0, 2, 0x99000000);
            pad = sizePx * 0.10f;
        }

        void setTime(String t, String s) {
            boolean relayout = !s.equals(suffix);
            time = t; suffix = s;
            if (relayout) requestLayout();
            invalidate();
        }

        private float widest() {
            float digit = 0;
            for (char ch = '0'; ch <= '9'; ch++) digit = Math.max(digit, p.measureText(String.valueOf(ch)));
            float w = digit * 4 + p.measureText(":");
            if (!suffix.isEmpty()) {
                float m = 0;
                for (String a : new DateFormatSymbols(Locale.getDefault()).getAmPmStrings()) m = Math.max(m, sp.measureText(a));
                w += p.getTextSize() * 0.12f + m;
            }
            return w;
        }

        @Override protected void onMeasure(int wSpec, int hSpec) {
            Paint.FontMetrics fm = p.getFontMetrics();
            setMeasuredDimension(Math.round(widest() * 1.04f + pad * 2), Math.round(fm.descent - fm.ascent + pad));
        }

        @Override protected void onDraw(Canvas c) {
            Paint.FontMetrics fm = p.getFontMetrics();
            float timeW = p.measureText(time);
            float gap = suffix.isEmpty() ? 0 : p.getTextSize() * 0.12f;
            float sufW = suffix.isEmpty() ? 0 : sp.measureText(suffix);
            float x = (getWidth() - (timeW + gap + sufW)) / 2f;
            float base = pad / 2f - fm.ascent;
            c.drawText(time, x, base, p);
            if (!suffix.isEmpty()) c.drawText(suffix, x + timeW + gap, base, sp);
        }
    }

    /**
     * ساعة بعقارب بنظام 24 ساعة (Style Seven): إطار رمادي، أرقام الساعات 1–24 (الزوجية أكبر) على حلقة داخلية،
     * ودقائق 5–55 صغيرة على الحلقة الخارجية، وعقرب ساعات يدور دورة كاملة كل 24 ساعة، وعقرب ثوانٍ، ومربّعا اليوم والتاريخ.
     * بلا مربع البطارية. light = وجه أبيض بخط Serif، وإلا وجه أسود.
     */
    private static class AnalogClock extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final boolean light, showTime;
        private final int style;
        private final Typeface numFont, boxFont;
        private Calendar now = Calendar.getInstance();
        private boolean h24;
        private int cachedDay = -1;
        private String dayTxt = "", monTxt = "", dateTxt = "";
        private Shader bezel;

        AnalogClock(Context c, int style, boolean showTime) {
            super(c);
            this.style = style; this.light = style == 1; this.showTime = showTime;
            numFont = light ? Typeface.create(Typeface.SERIF, Typeface.BOLD) : Typeface.create("sans-serif", Typeface.NORMAL);
            boxFont = light ? numFont : Typeface.create("sans-serif-condensed", Typeface.NORMAL);
        }

        void setTime(Calendar n, boolean h24) {
            now = n; this.h24 = h24;
            int key = n.get(Calendar.YEAR) * 400 + n.get(Calendar.DAY_OF_YEAR);
            if (key != cachedDay) {
                cachedDay = key;
                Locale loc = Locale.getDefault();
                Date d = n.getTime();
                dayTxt = clean(new SimpleDateFormat("EEE", loc).format(d), loc);
                monTxt = clean(new SimpleDateFormat("MMM", loc).format(d), loc);
                dateTxt = LocaleHelper.westernDigits(String.format(Locale.ROOT, "%02d", n.get(Calendar.DAY_OF_MONTH)));
            }
            invalidate();
        }

        private static String clean(String t, Locale loc) { return LocaleHelper.westernDigits(t.replace(".", "").trim()).toUpperCase(loc); }

        @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
            float cx = w / 2f, cy = h / 2f, ro = Math.min(cx, cy) * 0.97f;
            bezel = new LinearGradient(cx - ro, cy - ro, cx + ro, cy + ro, 0xFF909090, 0xFF383838, Shader.TileMode.CLAMP);
        }

        private void label(Canvas c, String s, float cx, float cy, float deg, float rad, float size) {
            double a = Math.toRadians(deg - 90);
            p.setTextSize(size);
            Paint.FontMetrics fm = p.getFontMetrics();
            c.drawText(s, cx + (float) Math.cos(a) * rad, cy + (float) Math.sin(a) * rad - (fm.ascent + fm.descent) / 2f, p);
        }

        /** نص داخل خلية: يُصغَّر حتى يتسع، ويتوسّط عمودياً. */
        private void cellText(Canvas c, String s, float x0, float x1, float cy, float size) {
            p.setTypeface(boxFont); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(size);
            while (p.measureText(s) > (x1 - x0) * 0.90f && size > 6) { size *= 0.93f; p.setTextSize(size); }
            Paint.FontMetrics fm = p.getFontMetrics();
            c.drawText(s, (x0 + x1) / 2f, cy - (fm.ascent + fm.descent) / 2f, p);
        }

        private void hand(Canvas c, float cx, float cy, float deg, float len, float tail, float width, int color) {
            c.save(); c.rotate(deg, cx, cy);
            p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(width); p.setColor(color);
            p.setShadowLayer(width * 0.6f, 0, width * 0.25f, 0x88000000);
            c.drawLine(cx, cy + tail, cx, cy - len, p);
            p.clearShadowLayer();
            c.restore();
        }

        // ---------- النمط الثالث: وجه أسود بلون مرجاني، إطار مجزّأ، عقارب بلونين (12 ساعة) ----------
        private static final int CORAL = 0xFFF2655F, CORAL_HI = 0xFFFF9A94, GRAY = 0xFF3F3F3F;

        private void tileText(Canvas c, String s, float cx, float cy, float deg, float rad, float size) {
            p.setTextSize(size);
            Paint.FontMetrics fm = p.getFontMetrics();
            double a = Math.toRadians(deg - 90);
            float x = cx + (float) Math.cos(a) * rad, y = cy + (float) Math.sin(a) * rad;
            c.save(); c.rotate((deg > 90 && deg < 270) ? deg + 180f : deg, x, y);
            c.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, p);
            c.restore();
        }

        /** عقرب بشكل رمح: قاعدة مرجانية وطرف رمادي، مع ذيل قصير. */
        private void spear(Canvas c, float cx, float cy, float deg, float len, float w, float tail, float shoulder, float tipStart) {
            Path pa = new Path();
            pa.moveTo(cx, cy - len);
            pa.lineTo(cx + w / 2f, cy - len * shoulder); pa.lineTo(cx + w * 0.32f, cy);
            pa.lineTo(cx + w * 0.45f, cy + tail); pa.lineTo(cx - w * 0.45f, cy + tail);
            pa.lineTo(cx - w * 0.32f, cy); pa.lineTo(cx - w / 2f, cy - len * shoulder);
            pa.close();
            c.save(); c.rotate(deg, cx, cy);
            p.setStyle(Paint.Style.FILL); p.setShadowLayer(w * 0.35f, 0, w * 0.15f, 0xAA000000); p.setColor(CORAL); c.drawPath(pa, p); p.clearShadowLayer();
            c.save(); c.clipRect(cx - w, cy - len - 2, cx + w, cy - tipStart); p.setColor(GRAY); c.drawPath(pa, p); c.restore();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w * 0.05f); p.setColor(CORAL_HI); c.save(); c.clipRect(cx - w, cy - tipStart, cx + w, cy + tail + 2); c.drawPath(pa, p); c.restore();
            c.restore();
        }

        private void drawCoral(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, ro = Math.min(cx, cy) * 0.97f;
            p.clearShadowLayer(); p.setShader(null); p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF1B1B1B); c.drawCircle(cx, cy, ro, p);

            // حلقة من 60 بلاطة؛ كل خامسة مرجانية برقم مائل
            for (int i = 0; i < 60; i++) {
                boolean five = i % 5 == 0;
                float w = ro * (five ? 0.098f : 0.076f), r1 = ro * 0.985f, r2 = ro * 0.885f;
                c.save(); c.rotate(i * 6f, cx, cy);
                p.setStyle(Paint.Style.FILL); p.setColor(five ? CORAL : GRAY);
                c.drawRoundRect(cx - w / 2f, cy - r1, cx + w / 2f, cy - r2, ro * 0.01f, ro * 0.01f, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(ro * 0.006f); p.setColor(0xFF202020);
                c.drawRoundRect(cx - w / 2f, cy - r1, cx + w / 2f, cy - r2, ro * 0.01f, ro * 0.01f, p);
                c.restore();
            }
            p.setStyle(Paint.Style.FILL); p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); p.setTextAlign(Paint.Align.CENTER); p.setColor(0xFF3A2626);
            for (int m = 5; m <= 60; m += 5) tileText(c, String.format(Locale.ROOT, "%02d", m), cx, cy, (m % 60) * 6f, ro * 0.935f, ro * 0.055f);

            // الوجه الأسود
            p.setColor(0xFF000000); c.drawCircle(cx, cy, ro * 0.875f, p);

            // علامات: شرطات الدقائق المرجانية، قضبان الساعات الرمادية، ومربعات صغيرة عند 12/3/6/9
            for (int i = 0; i < 60; i++) {
                c.save(); c.rotate(i * 6f, cx, cy);
                if (i % 15 == 0) {
                    p.setStyle(Paint.Style.FILL); p.setColor(GRAY); float q = ro * 0.02f; c.drawRect(cx - q, cy - ro * 0.85f - q, cx + q, cy - ro * 0.85f + q, p);
                } else if (i % 5 == 0) {
                    p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.BUTT); p.setStrokeWidth(ro * 0.032f); p.setColor(GRAY);
                    c.drawLine(cx, cy - ro * 0.85f, cx, cy - ro * 0.66f, p);
                } else {
                    p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.BUTT); p.setStrokeWidth(ro * 0.014f); p.setColor(CORAL);
                    c.drawLine(cx, cy - ro * 0.835f, cx, cy - ro * 0.795f, p);
                }
                c.restore();
            }
            // الأرقام الكبيرة 12 · 3 · 6 · 9
            p.setStyle(Paint.Style.FILL); p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); p.setTextAlign(Paint.Align.CENTER); p.setColor(CORAL);
            String[] big = {"12", "3", "6", "9"};
            for (int k = 0; k < 4; k++) label(c, big[k], cx, cy, k * 90f, ro * (k % 2 == 0 ? 0.70f : 0.725f), ro * 0.29f);

            // مربعات: الشهر واليوم (يسار)، التاريخ (يمين) — بلا البطارية
            float bh = ro * 0.20f;
            float[][] boxes = {{cx - ro * 0.64f, cx - ro * 0.36f, cy - ro * 0.22f}, {cx - ro * 0.64f, cx - ro * 0.36f, cy + ro * 0.01f}, {cx + ro * 0.35f, cx + ro * 0.63f, cy - ro * 0.22f}};
            String[] txt = {monTxt, dayTxt, dateTxt};
            for (int k = 0; k < 3; k++) {
                float x0 = boxes[k][0], x1 = boxes[k][1], t = boxes[k][2];
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF050505); c.drawRoundRect(x0, t, x1, t + bh, ro * 0.03f, ro * 0.03f, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(ro * 0.012f); p.setColor(0xFF303030); c.drawRoundRect(x0, t, x1, t + bh, ro * 0.03f, ro * 0.03f, p);
                p.setStyle(Paint.Style.FILL); p.setColor(CORAL);
                cellText(c, txt[k], x0, x1, t + bh / 2f, ro * 0.13f);
            }

            // العقارب (12 ساعة) + عقرب الثواني
            int m = now.get(Calendar.MINUTE), sec = now.get(Calendar.SECOND);
            float hourA = ((now.get(Calendar.HOUR_OF_DAY) % 12) + m / 60f + sec / 3600f) * 30f, minA = (m + sec / 60f) * 6f, secA = sec * 6f;
            spear(c, cx, cy, hourA, ro * 0.57f, ro * 0.10f, ro * 0.13f, 0.5f, ro * 0.33f);
            spear(c, cx, cy, minA, ro * 0.86f, ro * 0.06f, ro * 0.09f, 0.4f, ro * 0.48f);
            hand(c, cx, cy, secA, ro * 0.84f, 0f, ro * 0.014f, CORAL_HI);
            hand(c, cx, cy, secA + 180f, ro * 0.22f, 0f, ro * 0.028f, CORAL_HI);
            p.setStyle(Paint.Style.FILL); p.setColor(CORAL); c.drawCircle(cx, cy, ro * 0.052f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(ro * 0.012f); p.setColor(CORAL_HI); c.drawCircle(cx, cy, ro * 0.052f, p);
        }

        @Override protected void onDraw(Canvas c) {
            if (style == 2) { drawCoral(c); return; }
            float cx = getWidth() / 2f, cy = getHeight() / 2f, ro = Math.min(cx, cy) * 0.97f;
            int face = light ? 0xFFFFFFFF : 0xFF000000, ink = light ? 0xFF111111 : 0xFFFFFFFF;
            p.clearShadowLayer(); p.setShader(null);

            // الإطار الرمادي ثم الوجه
            p.setStyle(Paint.Style.FILL); p.setShader(bezel); c.drawCircle(cx, cy, ro, p); p.setShader(null);
            p.setColor(face); c.drawCircle(cx, cy, ro * 0.915f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(ro * 0.008f); p.setColor(light ? 0x44000000 : 0x55FFFFFF); c.drawCircle(cx, cy, ro * 0.915f, p);

            // 60 علامة دقيقة (الخماسية أطول وأسمك)
            p.setStrokeCap(Paint.Cap.BUTT);
            for (int i = 0; i < 60; i++) {
                boolean big = i % 5 == 0;
                float r1 = ro * 0.905f, r2 = r1 - ro * (big ? 0.05f : 0.026f);
                p.setStrokeWidth(ro * (big ? 0.013f : 0.006f)); p.setColor(big ? ink : (light ? 0xCC111111 : 0xCCFFFFFF));
                c.save(); c.rotate(i * 6f, cx, cy); c.drawLine(cx, cy - r1, cx, cy - r2, p); c.restore();
            }
            // مثلث صغير عند الأعلى
            Path tri = new Path(); float tw = ro * 0.024f;
            tri.moveTo(cx - tw, cy - ro * 0.868f); tri.lineTo(cx + tw, cy - ro * 0.868f); tri.lineTo(cx, cy - ro * 0.82f); tri.close();
            p.setStyle(Paint.Style.FILL); p.setColor(ink); c.drawPath(tri, p);

            // أرقام الساعات 1–24 (الزوجية أكبر) وأرقام الدقائق الصغيرة
            p.setStyle(Paint.Style.FILL); p.setTypeface(numFont); p.setTextAlign(Paint.Align.CENTER); p.setColor(ink);
            for (int hr = 1; hr <= 24; hr++) {
                boolean even = hr % 2 == 0;
                label(c, (hr == 24 && light) ? "0" : String.valueOf(hr), cx, cy, hr * 15f, ro * (even ? 0.72f : 0.775f), ro * (even ? 0.15f : 0.105f));
            }
            for (int m = 5; m < 60; m += 5) label(c, String.valueOf(m), cx, cy, m * 6f, ro * 0.835f, ro * 0.057f);

            // مربعا اليوم (يسار) والشهر/التاريخ (يمين) — بلا البطارية
            float bh = ro * 0.17f, top = cy - bh / 2f, bot = cy + bh / 2f;
            float lx0 = cx - ro * 0.63f, lx1 = cx - ro * 0.19f, rx0 = cx + ro * 0.19f, rx1 = cx + ro * 0.63f, rm = (rx0 + rx1) / 2f;
            int fill = light ? 0xFFF6F6F6 : 0xFF161616, line = light ? 0xFF8A8A8A : 0xFFA6A6A6;
            for (float[] bx : new float[][]{{lx0, lx1}, {rx0, rx1}}) {
                p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawRect(bx[0], top, bx[1], bot, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(ro * 0.007f); p.setColor(line); c.drawRect(bx[0], top, bx[1], bot, p);
            }
            c.drawLine(rm, top, rm, bot, p);
            p.setStyle(Paint.Style.FILL); p.setColor(ink);
            float ts = ro * 0.135f;
            cellText(c, dayTxt, lx0, lx1, cy, ts);
            cellText(c, monTxt, rx0, rm, cy, ts);
            cellText(c, dateTxt, rm, rx1, cy, ts);

            // الوقت الرقمي الصغير تحت المركز (يظهر فقط حين تكون الساعة ذات العقارب وحدها)
            if (showTime) {
                int hh = now.get(Calendar.HOUR_OF_DAY);
                String t = h24 ? String.format(Locale.ROOT, "%02d:%02d", hh, now.get(Calendar.MINUTE))
                        : String.format(Locale.ROOT, "%02d:%02d", hh % 12 == 0 ? 12 : hh % 12, now.get(Calendar.MINUTE));
                String suf = h24 ? "" : new DateFormatSymbols(Locale.getDefault()).getAmPmStrings()[now.get(Calendar.AM_PM)];
                p.setTypeface(numFont); p.setTextAlign(Paint.Align.LEFT);
                p.setTextSize(ro * 0.10f); float tw1 = p.measureText(t);
                p.setTextSize(ro * 0.055f); float sw = suf.isEmpty() ? 0 : p.measureText(suf) + ro * 0.015f;
                float x = cx - (tw1 + sw) / 2f, y = cy + ro * 0.43f;
                p.setTextSize(ro * 0.10f); c.drawText(t, x, y, p);
                if (!suf.isEmpty()) { p.setTextSize(ro * 0.055f); c.drawText(suf, x + tw1 + ro * 0.015f, y - ro * 0.04f, p); }
            }

            // العقارب: ساعات 24 (دورة كاملة كل 24 ساعة)، دقائق، ثوانٍ
            int m = now.get(Calendar.MINUTE), sec = now.get(Calendar.SECOND);
            float hourA = (now.get(Calendar.HOUR_OF_DAY) + m / 60f + sec / 3600f) * 15f, minA = (m + sec / 60f) * 6f, secA = sec * 6f;
            int handC = light ? 0xFF262626 : 0xFFD6D6D6, secC = light ? 0xFF0A7BFF : 0xFFFF1A1A;
            hand(c, cx, cy, hourA, ro * 0.54f, ro * 0.03f, ro * 0.062f, handC);
            hand(c, cx, cy, minA, ro * 0.78f, ro * 0.03f, ro * 0.052f, handC);
            hand(c, cx, cy, secA, ro * 0.84f, 0f, ro * 0.012f, secC);
            hand(c, cx, cy, secA + 180f, ro * 0.22f, 0f, ro * 0.026f, secC);
            p.setStyle(Paint.Style.FILL); p.setColor(secC); c.drawCircle(cx, cy, ro * 0.048f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(ro * 0.012f); p.setColor(light ? 0xFF111111 : 0xFFFFFFFF); c.drawCircle(cx, cy, ro * 0.048f, p);
        }
    }
}
