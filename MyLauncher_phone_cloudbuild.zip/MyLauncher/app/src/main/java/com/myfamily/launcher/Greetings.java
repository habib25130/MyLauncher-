package com.myfamily.launcher;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * رسائل الترحيب: أربع رسائل افتراضية مترجمة (صباح/مساء/ليل/جمعة) + رسائل خاصة يضيفها المستخدم.
 * لكل رسالة خاصة وقت (كل الأوقات/صباحًا/مساءً/ليلاً/الجمعة) ووسم لغة اختياري («كل اللغات» افتراضيًا):
 * تظهر الرسالة فقط عندما يوافق وقتُها الوقتَ الحالي ولغتُها لغةَ الواجهة، فلا تُفرض عليك لغة عند الكتابة.
 */
final class Greetings {
    static final int MAX = 30, MAX_LEN = 80;
    static final String KEY = "greet_custom", KEY_DEF = "greet_defaults";

    static final class Msg {
        String text; int period; String lang;      // period: 0 كل الأوقات · 1 صباحًا · 2 مساءً · 3 ليلاً · 4 الجمعة — lang: "" = كل اللغات
        Msg(String t, int p, String l) { text = t; period = p; lang = l == null ? "" : l; }
    }

    static synchronized List<Msg> load(SharedPreferences p) {
        List<Msg> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p.getString(KEY, "[]"));
            for (int i = 0; i < a.length() && out.size() < MAX; i++) {
                JSONObject o = a.getJSONObject(i);
                String t = clean(o.optString("t", ""));
                if (t != null) out.add(new Msg(t, Math.max(0, Math.min(4, o.optInt("p", 0))), o.optString("l", "")));
            }
        } catch (Exception ignored) { }
        return out;
    }

    static synchronized void save(SharedPreferences p, List<Msg> l) {
        try {
            JSONArray a = new JSONArray();
            for (Msg m : l) a.put(new JSONObject().put("t", m.text).put("p", m.period).put("l", m.lang));
            p.edit().putString(KEY, a.toString()).apply();
        } catch (Exception ignored) { }
    }

    static synchronized boolean add(SharedPreferences p, Msg m) {
        List<Msg> l = load(p);
        if (l.size() >= MAX) return false;
        l.add(m);
        save(p, l);
        return true;
    }

    /** ينظّف النص (بلا أسطر ولا فواصل |) ويقصّه إلى 80 حرفًا؛ null إن كان فارغًا. */
    static String clean(String s) {
        if (s == null) return null;
        s = s.replaceAll("[\\p{Cntrl}|]+", " ").trim();
        if (s.length() > MAX_LEN) {
            int end = MAX_LEN;
            if (Character.isHighSurrogate(s.charAt(end - 1))) end--;      // لا نقطع رمزًا تعبيريًا في منتصفه
            s = s.substring(0, end).trim();
        }
        return s.isEmpty() ? null : s;
    }

    /** 1 صباحًا (5–12) · 2 مساءً (12–21) · 3 ليلاً (21–5). */
    static int periodAt(int hour) { return hour >= 5 && hour < 12 ? 1 : hour >= 12 && hour < 21 ? 2 : 3; }

    /** الرسائل الافتراضية المترجمة لهذا الوقت (من مصفوفات الموارد): عدة رسائل بإيموجي، وللجمعة تحايا خاصة. */
    static String[] defaultsFor(Context c, int period) {
        int id;
        switch (period) {
            case 1: id = R.array.greetings_morning; break;
            case 2: id = R.array.greetings_evening; break;
            case 4: id = R.array.greetings_friday; break;
            default: id = R.array.greetings_night; break;
        }
        return c.getResources().getStringArray(id);
    }

    @SuppressWarnings("deprecation")
    static String uiLang(Context c) {
        try { return c.getResources().getConfiguration().locale.getLanguage(); } catch (Exception e) { return ""; }
    }

    /** الرسالة الحالية: تدور بين المناسب للوقت واللغة (تتغير كل نصف ساعة)، ويوم الجمعة تحلّ رسائل الجمعة محل الباقي. */
    static String pick(Context c, SharedPreferences p, Calendar now) {
        int hour = now.get(Calendar.HOUR_OF_DAY);
        boolean fri = PrayerInfo.isFriday();
        int per = fri ? 4 : periodAt(hour);
        String lang = uiLang(c);
        List<String> pool = new ArrayList<>();
        if (p.getBoolean(KEY_DEF, true)) pool.addAll(java.util.Arrays.asList(defaultsFor(c, per)));
        for (Msg m : load(p)) {
            boolean perOk = m.period == per || (m.period == 0 && !fri);
            boolean langOk = m.lang.isEmpty() || m.lang.equals(lang);
            if (perOk && langOk) pool.add(m.text);
        }
        if (pool.isEmpty()) pool.addAll(java.util.Arrays.asList(defaultsFor(c, per)));   // لا نترك الترحيب فارغًا أبدًا
        int slot = hour * 2 + now.get(Calendar.MINUTE) / 30;                              // تتبدّل الرسالة كل نصف ساعة
        return pool.get(Math.floorMod(now.get(Calendar.DAY_OF_YEAR) * 48 + slot, pool.size()));
    }
}
