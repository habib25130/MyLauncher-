package com.myfamily.launcher;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** لوحة مواقيت بأسلوب شاشات المساجد: الصلوات الخمس يسارًا، والتاريخ والعدّ التنازلي للصلاة القادمة والساعة الرقمية يمينًا، داخل إطار ذهبي. */
public class MosqueBoardActivity extends Activity {
    private static final int GOLD = 0xFFD9C46A, GOLD_TXT = 0xFFF1E3A0, GOLD_HI = 0xFFFFD84A, GREEN = 0xFF3BE63B, YELLOW = 0xFFF2E24A;
    // لكل صف: فهرسه في PrayerTimes.compute (0 فجر، 1 شروق، 2 ظهر، 3 عصر، 4 مغرب، 5 عشاء)
    private static final int[] PRAYERS = {0, 2, 3, 4, 5};

    private final Handler h = new Handler(Looper.getMainLooper());
    private TextView dayLine, hijriLine, gregLine, label, countdown, clockTv;
    private final TextView[] times = new TextView[6], rowNames = new TextView[6];
    private final View[] rows = new View[6];
    private float H;
    private int lastDay = -1;

    @Override protected void attachBaseContext(Context base) { super.attachBaseContext(LocaleHelper.wrap(base)); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Adhan.load(this);
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        final float W = dm.widthPixels; H = dm.heightPixels;
        Typeface bold = Fonts.bold(this), reg = Fonts.outfit(this);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF1A0E08);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        // الخلفية الحمراء (بلا زخرفة) + إطار ذهبي رفيع
        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.board_bg2); bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View frame = new View(this); frame.setBackground(box(0x00000000, GOLD, 2f, 6));
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(-1, -1);
        fp.setMargins(dp(10), dp(10), dp(10), dp(10));
        root.addView(frame, fp);

        // اليسار: الصلوات الخمس، في كل صف مربع الوقت ثم مربع الاسم
        String[] names = {getString(R.string.fajr), getString(R.string.sunrise), PrayerInfo.dhuhrName(this), getString(R.string.asr),
                getString(R.string.maghrib), getString(R.string.isha)};
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams lsp = new FrameLayout.LayoutParams(Math.round(W * 0.47f), Math.round(H * 0.84f), Gravity.TOP | Gravity.START);
        lsp.topMargin = Math.round(H * 0.08f); lsp.leftMargin = Math.round(W * 0.04f);
        for (int i : PRAYERS) {
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView t = tv(bold, H * 0.082f, GOLD_TXT); t.setText("--:--"); t.setIncludeFontPadding(false); t.setSingleLine(true);
            t.setBackground(box(0xCC120A05, GOLD, 1.5f, 10));
            TextView n = tv(reg, H * 0.052f, Color.WHITE); n.setText(names[i]); n.setSingleLine(true);
            n.setBackground(box(0x99120A05, 0x99B8923A, 1f, 10));
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -1, 1.1f); tl.setMarginEnd(Math.round(W * 0.012f));
            row.addView(t, tl);
            row.addView(n, new LinearLayout.LayoutParams(0, -1, 1f));
            times[i] = t; rowNames[i] = n; rows[i] = row;
            LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, 0, 1f); rl.setMargins(0, Math.round(H * 0.011f), 0, Math.round(H * 0.011f));
            list.addView(row, rl);
        }
        root.addView(list, lsp);

        // اليمين: اليوم والتاريخان، ثم «الصلاة القادمة» والعدّ التنازلي، ثم الساعة الرقمية
        LinearLayout right = new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL); right.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(Math.round(W * 0.41f), Math.round(H * 0.84f), Gravity.TOP | Gravity.END);
        rp.topMargin = Math.round(H * 0.08f); rp.rightMargin = Math.round(W * 0.04f);
        dayLine = tv(bold, H * 0.058f, Color.WHITE); hijriLine = tv(reg, H * 0.042f, GOLD_TXT); gregLine = tv(reg, H * 0.042f, GOLD_TXT);
        right.addView(dayLine); right.addView(hijriLine); right.addView(gregLine);

        label = tv(bold, H * 0.044f, YELLOW); label.setSingleLine(true);
        LinearLayout.LayoutParams lbp = new LinearLayout.LayoutParams(-2, -2); lbp.topMargin = Math.round(H * 0.07f);
        right.addView(label, lbp);

        countdown = tv(bold, H * 0.16f, GREEN);
        countdown.setBackground(box(0xFF050506, 0xFF6B5A2A, 1.5f, 12));
        countdown.setSingleLine(true); countdown.setIncludeFontPadding(false);
        LinearLayout.LayoutParams cdp = new LinearLayout.LayoutParams(-1, Math.round(H * 0.27f)); cdp.topMargin = Math.round(H * 0.015f);
        right.addView(countdown, cdp);

        clockTv = tv(bold, H * 0.10f, Color.WHITE); clockTv.setSingleLine(true); clockTv.setIncludeFontPadding(false);
        LinearLayout.LayoutParams ckp = new LinearLayout.LayoutParams(-2, -2); ckp.topMargin = Math.round(H * 0.04f);
        right.addView(clockTv, ckp);
        root.addView(right, rp);

        // الإعدادات (أعلى اليمين)
        ImageView gear = new ImageView(this);
        gear.setImageResource(R.drawable.ic_gear); gear.setColorFilter(GOLD);
        gear.setPadding(dp(8), dp(8), dp(8), dp(8)); gear.setFocusable(true); gear.setClickable(true);
        gear.setContentDescription(getString(R.string.adhan_settings_title));
        gear.setOnFocusChangeListener((v, f) -> { v.setBackground(f ? box(0x55000000, GOLD_HI, 2f, 40) : null); v.animate().scaleX(f ? 1.15f : 1f).scaleY(f ? 1.15f : 1f).setDuration(150).start(); });
        gear.setOnClickListener(v -> startActivity(new Intent(this, AdhanSettingsActivity.class)));
        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP | Gravity.END);
        gp.setMargins(0, dp(10), dp(14), 0);
        root.addView(gear, gp);

        setContentView(root);
        gear.requestFocus();
    }

    @Override protected void onResume() { super.onResume(); Adhan.load(this); lastDay = -1; h.removeCallbacks(tick); tick.run(); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tick); }

    private final Runnable tick = new Runnable() {
        @Override public void run() { update(); h.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000)); }
    };

    private void update() {
        Calendar now = Calendar.getInstance(PrayerTimes.TZ);
        Locale loc = Locale.getDefault();
        int nowSec = now.get(Calendar.HOUR_OF_DAY) * 3600 + now.get(Calendar.MINUTE) * 60 + now.get(Calendar.SECOND);
        int day = now.get(Calendar.DAY_OF_YEAR);
        double[] tt = PrayerTimes.compute(now);
        clockTv.setText(String.format(Locale.ROOT, "%02d:%02d:%02d", now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), now.get(Calendar.SECOND)));

        if (day != lastDay) {
            lastDay = day;
            Date d = now.getTime();
            SimpleDateFormat df = new SimpleDateFormat("EEEE", loc); df.setTimeZone(PrayerTimes.TZ);
            String dn = LocaleHelper.westernDigits(df.format(d));
            dayLine.setText(dn.isEmpty() ? dn : dn.substring(0, 1).toUpperCase(loc) + dn.substring(1));
            SimpleDateFormat gf = new SimpleDateFormat("d MMMM yyyy", loc); gf.setTimeZone(PrayerTimes.TZ);
            gregLine.setText(LocaleHelper.westernDigits(gf.format(d)));
            hijriLine.setText(LocaleHelper.westernDigits(Hijri.formatHeader(this)));
            for (int i : PRAYERS) times[i].setText(PrayerTimes.fmt(tt[i]));
        }

        int cur = -1, remain = 0;
        for (int i : PRAYERS) {
            int sec = (int) Math.round(tt[i] * 3600);
            if (sec > nowSec) { cur = i; remain = sec - nowSec; break; }
        }
        if (cur < 0) {                                       // بعد العشاء: فجر الغد
            Calendar tm = (Calendar) now.clone(); tm.add(Calendar.DAY_OF_MONTH, 1);
            cur = 0; remain = (int) Math.round(PrayerTimes.compute(tm)[0] * 3600) + 86400 - nowSec;
        }
        label.setText(getString(R.string.board_next, rowNames[cur].getText()));
        int hh = remain / 3600, mm = (remain % 3600) / 60, ss = remain % 60;
        countdown.setText(String.format(Locale.ROOT, "%02d:%02d:%02d", hh, mm, ss));
        for (int i : PRAYERS) {
            boolean hi = i == cur;
            times[i].setBackground(hi ? box(0xDD7A5A12, GOLD_HI, 3f, 10) : box(0xCC120A05, GOLD, 1.5f, 10));
            times[i].setTextColor(hi ? Color.WHITE : GOLD_TXT);
        }
    }

    private TextView tv(Typeface f, float px, int color) {
        TextView t = new TextView(this);
        t.setTypeface(f); t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setShadowLayer(5, 0, 1, 0x99000000);
        return t;
    }

    private GradientDrawable box(int fill, int stroke, float strokeDp, int radiusDp) {
        GradientDrawable g = new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(radiusDp));
        g.setStroke(Math.max(1, Math.round(strokeDp * getResources().getDisplayMetrics().density)), stroke);
        return g;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
