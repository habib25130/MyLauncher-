package com.myfamily.launcher;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * واجهة الراديو الزجاجية (Glassmorphism + لمسات ذهبية): بحث فوري، فلاتر سريعة،
 * قائمة محطات، شريط حالة مع موجات صوتية. تدعم اللمس والريموت (D-Pad) واتجاه RTL للعربية.
 *
 * لا تشغّل أي صوت عند الفتح أو عند تحميل القائمة؛ التشغيل فقط بعد ضغط المستخدم على محطة.
 */
final class RadioPanel implements RadioPlayer.Listener {
    private static final int GOLD = WaveformView.GOLD, GOLD_LIGHT = WaveformView.GOLD_LIGHT;
    private static final int TEXT = 0xFFFFFFFF, DIM = 0xB3FFFFFF, ERR = 0xFFFF9C8F, INK = 0xFF2A1D05;

    private final Activity act;
    private final RadioPlayer player;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final float density;

    private Dialog dialog;
    private EditText search;
    private ListView list;
    private StationAdapter adapter;
    private TextView status, nowName, nowState;
    private WaveformView wave;
    private ImageView nowStop;
    private TextView ambBtn;
    private List<RadioStation> base = new ArrayList<>();
    private int token, searchToken;

    RadioPanel(Activity act) {
        this.act = act;
        this.player = RadioPlayer.get(act);
        this.density = act.getResources().getDisplayMetrics().density;
    }

    boolean isShowing() { return dialog != null && dialog.isShowing(); }

    void dismiss() { if (dialog != null) { try { dialog.dismiss(); } catch (Exception ignored) { } } }

    // ===================== فتح الواجهة =====================
    void show() {
        RadioRepository.warmUp();
        if (isShowing()) return;
        boolean rtl = "ar".equals(Locale.getDefault().getLanguage());

        Dialog d = new Dialog(act, android.R.style.Theme_DeviceDefault_NoActionBar);
        dialog = d;
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0xA6050A12));
            w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                    | WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            if (Build.VERSION.SDK_INT >= 31) {           // ضبابية حقيقية خلف النافذة حيث يدعمها الجهاز
                try {
                    WindowManager.LayoutParams lp = w.getAttributes();
                    lp.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
                    lp.setBlurBehindRadius(dp(28));
                    w.setAttributes(lp);
                } catch (Throwable ignored) { }
            }
        }
        d.setContentView(buildUi(rtl));
        d.setOnDismissListener(x -> onDismissed());

        player.addListener(this);
        onRadioState(player.state(), player.current(), player.errorRes());
        d.setOnShowListener(di -> {
            if (list != null) {
                list.post(() -> {
                    if (list != null) {
                        list.requestFocus();
                        if (adapter != null && adapter.getCount() > 0) {
                            list.setSelection(0);
                        }
                    }
                });
            }
        });
        d.show();

        // قائمة فورية (المدمجة) ثم تحديث من الشبكة — دون أي تشغيل صوتي
        reload(false);
    }

    private void onDismissed() {
        player.removeListener(this);      // الصوت يستمر إن كان يعمل؛ الواجهة فقط أُغلقت
        h.removeCallbacksAndMessages(null);
        token++; searchToken++;
        hideIme();
        dialog = null; search = null; list = null; adapter = null;
        status = null; nowName = null; nowState = null; wave = null; nowStop = null; ambBtn = null;
    }

    // ===================== بناء الواجهة =====================
    private View buildUi(boolean rtl) {
        DisplayMetrics dm = act.getResources().getDisplayMetrics();
        FrameLayout root = new FrameLayout(act);
        root.setLayoutDirection(rtl ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        root.setClickable(true);
        root.setOnClickListener(v -> dismiss());               // لمس خارج البطاقة يغلق

        int cardW = Math.min(dm.widthPixels - dp(40), dp(860));
        int cardH = Math.min(dm.heightPixels - dp(40), dp(680));
        LinearLayout card = new LinearLayout(act);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(24), dp(20), dp(24), dp(16));
        card.setClickable(true);
        card.setBackground(cardBg());
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(12));
        root.addView(card, new FrameLayout.LayoutParams(cardW, cardH, Gravity.CENTER));

        // ---- رأس: أيقونة + عنوان + إغلاق
        LinearLayout head = new LinearLayout(act);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView ic = new ImageView(act); ic.setImageResource(R.drawable.ic_radio); ic.setColorFilter(GOLD);
        head.addView(ic, new LinearLayout.LayoutParams(dp(28), dp(28)));
        TextView title = text(26, GOLD_LIGHT, true); title.setText(R.string.radio_title);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f); tl.setMarginStart(dp(12));
        head.addView(title, tl);
        ImageView close = roundButton(R.drawable.ic_close, false);
        close.setContentDescription(act.getString(R.string.radio_close));
        close.setOnClickListener(v -> dismiss());
        head.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));
        card.addView(head, new LinearLayout.LayoutParams(-1, -2));

        card.addView(goldLine(), lpMargin(-1, dp(1), 0, dp(10), 0, dp(12)));

        // ---- شريط التشغيل الحالي: موجات + اسم + حالة + إيقاف
        LinearLayout now = new LinearLayout(act);
        now.setGravity(Gravity.CENTER_VERTICAL);
        now.setPadding(dp(12), dp(10), dp(12), dp(10));
        now.setBackground(shape(0x24FFFFFF, 0x40FFFFFF, 1, 22));
        wave = new WaveformView(act, 22, true);
        now.addView(wave, new LinearLayout.LayoutParams(dp(150), dp(54)));
        LinearLayout col = new LinearLayout(act); col.setOrientation(LinearLayout.VERTICAL);
        nowName = text(17, TEXT, true); nowName.setSingleLine(true); nowName.setEllipsize(TextUtils.TruncateAt.END);
        nowName.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        nowState = text(13, DIM, false); nowState.setSingleLine(true); nowState.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(nowName); col.addView(nowState);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1f);
        cl.setMarginStart(dp(14)); cl.setMarginEnd(dp(10));
        now.addView(col, cl);
        ambBtn = text(14, GOLD_LIGHT, true); ambBtn.setText(R.string.amb_open);
        ambBtn.setGravity(Gravity.CENTER); ambBtn.setPadding(dp(16), 0, dp(16), 0);
        ambBtn.setFocusable(true); ambBtn.setClickable(true);
        ambBtn.setBackground(shape(0x2AFFFFFF, 0x66E6BE5A, 1, 23));
        ambBtn.setOnFocusChangeListener((v, f) -> v.setBackground(f ? shape(0x55FFE9A8, GOLD_LIGHT, 3, 23) : shape(0x2AFFFFFF, 0x66E6BE5A, 1, 23)));
        ambBtn.setOnClickListener(v -> { dismiss(); act.startActivity(new android.content.Intent(act, AmbientActivity.class)); });
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-2, dp(46)); ap.setMarginEnd(dp(10));
        now.addView(ambBtn, ap);
        nowStop = roundButton(R.drawable.ic_stop, false);
        nowStop.setContentDescription(act.getString(R.string.radio_stop));
        nowStop.setOnClickListener(v -> player.stop());
        now.addView(nowStop, new LinearLayout.LayoutParams(dp(46), dp(46)));
        card.addView(now, new LinearLayout.LayoutParams(-1, -2));

        // ---- بحث فوري
        LinearLayout sbox = new LinearLayout(act);
        sbox.setGravity(Gravity.CENTER_VERTICAL);
        sbox.setPadding(dp(18), 0, dp(18), 0);
        sbox.setBackground(searchBg(false));
        ImageView si = new ImageView(act); si.setImageResource(R.drawable.ic_search); si.setColorFilter(GOLD);
        sbox.addView(si, new LinearLayout.LayoutParams(dp(22), dp(22)));
        search = new EditText(act);
        search.setBackground(null);
        search.setHint(R.string.radio_search_hint); search.setHintTextColor(0x88FFFFFF);
        search.setTextColor(TEXT); search.setTextSize(17);
        search.setTypeface(Fonts.outfit(act));
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        search.setHighlightColor(0x66E6BE5A);
        LinearLayout.LayoutParams el = new LinearLayout.LayoutParams(0, -1, 1f); el.setMarginStart(dp(12));
        sbox.addView(search, el);
        search.setOnFocusChangeListener((v, f) -> sbox.setBackground(searchBg(f)));
        search.setOnEditorActionListener((v, a, e) -> { hideIme(); if (list != null) list.requestFocus(); return true; });
        search.setOnKeyListener((v, kc, ev) -> {
            if (ev.getAction() == KeyEvent.ACTION_DOWN && kc == KeyEvent.KEYCODE_DPAD_DOWN) {
                if (list != null) {
                    list.requestFocus();
                    if (adapter != null && adapter.getCount() > 0 && list.getSelectedItemPosition() < 0) list.setSelection(0);
                    return true;
                }
            }
            return false;
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { onQueryChanged(); }
        });
        card.addView(sbox, lpMargin(-1, dp(52), 0, dp(12), 0, 0));

        // ---- سطر الحالة (تحديث / بلا اتصال / بلا نتائج)
        status = text(13, DIM, false);
        status.setPadding(dp(4), dp(6), dp(4), dp(6));
        status.setSingleLine(true); status.setEllipsize(TextUtils.TruncateAt.END);
        status.setVisibility(View.GONE);
        card.addView(status, new LinearLayout.LayoutParams(-1, -2));

        // ---- قائمة المحطات
        list = new ListView(act);
        list.setDivider(new ColorDrawable(0));
        list.setDividerHeight(dp(8));
        list.setVerticalScrollBarEnabled(false);
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        list.setFocusable(true);
        list.setFocusableInTouchMode(true);
        list.setItemsCanFocus(false);
        list.setSelector(shape(0x1AFFE9A8, GOLD_LIGHT, 3, 18));  // حلقة ذهبية عند التركيز بالريموت
        list.setDrawSelectorOnTop(true);
        list.setClipToPadding(false);
        list.setPadding(dp(2), dp(4), dp(2), dp(4));
        adapter = new StationAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> {
            if (adapter != null && pos >= 0 && pos < adapter.getCount()) player.toggle(adapter.getItem(pos));  // ← الضغطة الفعلية
        });
        list.setOnKeyListener((v, kc, ev) -> {
            if (ev.getAction() == KeyEvent.ACTION_DOWN && kc == KeyEvent.KEYCODE_DPAD_UP) {
                if (list.getSelectedItemPosition() <= 0 && search != null) {
                    search.requestFocus();
                    return true;
                }
            }
            return false;
        });
        card.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));
        return root;
    }

    // ===================== البحث =====================
    private void reload(final boolean force) {
        if (dialog == null) return;
        final int my = ++token;
        base = RadioRepository.builtIn();        // فوري
        applyQuery();
        setStatus(act.getString(R.string.radio_updating));
        RadioRepository.load(force, (res, net) -> {
            if (dialog == null || my != token) return;
            base = res;
            applyQuery();
            setStatus(net ? "" : act.getString(R.string.radio_offline_list));
            if (queryText().length() >= 2) scheduleRemoteSearch(0);
        });
    }

    private String queryText() { return search == null ? "" : search.getText().toString().trim(); }

    private void applyQuery() {
        if (adapter == null) return;
        adapter.set(RadioRepository.filterLocal(base, queryText()));
        if (list != null && adapter.getCount() > 0 && (list.hasFocus() || list.getSelectedItemPosition() < 0)) {
            list.setSelection(0);
        }
    }

    private void onQueryChanged() {
        searchToken++;
        h.removeCallbacks(remoteSearch);
        applyQuery();
        String q = queryText();
        if (q.length() >= 2) { setStatus(act.getString(R.string.radio_searching)); scheduleRemoteSearch(450); }
        else setStatus(adapter != null && adapter.getCount() == 0 ? act.getString(R.string.radio_no_results) : "");
    }

    private void scheduleRemoteSearch(long delay) {
        h.removeCallbacks(remoteSearch);
        h.postDelayed(remoteSearch, delay);
    }

    private final Runnable remoteSearch = new Runnable() {
        @Override public void run() {
            if (dialog == null) return;
            final String q = queryText();
            if (q.length() < 2) return;
            final int st = searchToken, tk = token;
            RadioRepository.search(q, (res, ok) -> {
                if (dialog == null || st != searchToken || tk != token || adapter == null) return;
                adapter.set(RadioRepository.merge(RadioRepository.filterLocal(base, q), res));
                if (adapter.getCount() == 0) setStatus(act.getString(ok ? R.string.radio_no_results : R.string.radio_offline_list));
                else setStatus("");
            });
        }
    };

    private void setStatus(CharSequence s) {
        if (status == null) return;
        status.setText(s);
        status.setVisibility(TextUtils.isEmpty(s) ? View.GONE : View.VISIBLE);
    }

    // ===================== حالة المشغّل =====================
    @Override public void onRadioState(RadioPlayer.State s, RadioStation st, int errRes) {
        if (nowName == null) return;
        nowName.setText(st != null ? st.name : act.getString(R.string.radio_no_station));
        switch (s) {
            case LOADING:  nowState.setText(R.string.radio_state_loading); nowState.setTextColor(GOLD); break;
            case PLAYING:  nowState.setText(R.string.radio_state_playing); nowState.setTextColor(GOLD_LIGHT); break;
            case ERROR:    nowState.setText(errRes != 0 ? errRes : R.string.radio_err_generic); nowState.setTextColor(ERR); break;
            default:       nowState.setText(R.string.radio_state_stopped); nowState.setTextColor(DIM); break;
        }
        wave.setPlaying(s == RadioPlayer.State.PLAYING);       // تتحرك فقط عند التشغيل الفعلي
        nowStop.setVisibility(s == RadioPlayer.State.LOADING || s == RadioPlayer.State.PLAYING ? View.VISIBLE : View.GONE);
        if (ambBtn != null) ambBtn.setVisibility(s == RadioPlayer.State.LOADING || s == RadioPlayer.State.PLAYING ? View.VISIBLE : View.GONE);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    // ===================== قائمة المحطات =====================
    private final class StationAdapter extends BaseAdapter {
        private List<RadioStation> data = new ArrayList<>();

        void set(List<RadioStation> d) { data = d; notifyDataSetChanged(); }
        @Override public int getCount() { return data.size(); }
        @Override public RadioStation getItem(int i) { return data.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override public View getView(int pos, View v, ViewGroup parent) {
            Row r;
            if (v == null) { r = new Row(act); v = r.root; v.setTag(r); } else r = (Row) v.getTag();
            RadioStation s = data.get(pos);
            boolean active = player.isActive(s);
            boolean loading = active && player.state() == RadioPlayer.State.LOADING;
            r.name.setText(s.name);
            r.name.setTextColor(active ? GOLD_LIGHT : TEXT);
            String meta = s.meta();
            if (active) meta = act.getString(loading ? R.string.radio_state_loading : R.string.radio_state_playing)
                    + (meta.isEmpty() ? "" : "  ·  " + meta);
            r.meta.setText(meta);
            r.meta.setTextColor(active ? GOLD : DIM);
            r.meta.setVisibility(meta.isEmpty() ? View.GONE : View.VISIBLE);
            r.root.setBackground(shape(active ? 0x30E6BE5A : 0x16FFFFFF, active ? 0x88E6BE5A : 0x26FFFFFF, 1, 18));
            r.btn.setImageResource(active ? R.drawable.ic_stop : R.drawable.ic_play);
            r.btn.setColorFilter(active ? INK : GOLD_LIGHT);
            r.btn.setBackground(circle(active ? GOLD : 0x2AFFFFFF, active ? GOLD_LIGHT : 0x66E6BE5A, 1));
            r.btn.setContentDescription(act.getString(active ? R.string.radio_stop : R.string.radio_play));
            return v;
        }
    }

    private final class Row {
        final LinearLayout root; final ImageView btn; final TextView name, meta;
        Row(Context c) {
            root = new LinearLayout(c);
            root.setGravity(Gravity.CENTER_VERTICAL);
            root.setPadding(dp(14), dp(10), dp(14), dp(10));
            btn = new ImageView(c);
            btn.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            btn.setPadding(dp(11), dp(11), dp(11), dp(11));
            btn.setFocusable(false); btn.setClickable(false);           // الصف كله هو عنصر التركيز
            root.addView(btn, new LinearLayout.LayoutParams(dp(46), dp(46)));
            LinearLayout col = new LinearLayout(c); col.setOrientation(LinearLayout.VERTICAL);
            name = text(17, TEXT, true); name.setSingleLine(true); name.setEllipsize(TextUtils.TruncateAt.END);
            name.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
            meta = text(13, DIM, false); meta.setSingleLine(true); meta.setEllipsize(TextUtils.TruncateAt.END);
            meta.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
            col.addView(name); col.addView(meta);
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1f);
            cl.setMarginStart(dp(14));
            root.addView(col, cl);
            root.setLayoutParams(new ViewGroup.LayoutParams(-1, -2));
        }
    }

    // ===================== أدوات الرسم =====================
    private TextView text(int sp, int color, boolean bold) {
        TextView t = new TextView(act);
        t.setTextSize(sp); t.setTextColor(color);
        t.setTypeface(bold ? Fonts.bold(act) : Fonts.outfit(act));
        return t;
    }

    private ImageView roundButton(int icon, boolean unused) {
        final ImageView b = new ImageView(act);
        b.setImageResource(icon); b.setColorFilter(GOLD_LIGHT);
        b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        b.setPadding(dp(11), dp(11), dp(11), dp(11));
        b.setFocusable(true); b.setClickable(true);
        b.setBackground(circle(0x2AFFFFFF, 0x66E6BE5A, 1));
        b.setOnFocusChangeListener((v, f) -> v.setBackground(f ? circle(0x55FFE9A8, GOLD_LIGHT, 3) : circle(0x2AFFFFFF, 0x66E6BE5A, 1)));
        return b;
    }

    private GradientDrawable searchBg(boolean focused) {
        return shape(focused ? 0x3AFFFFFF : 0x24FFFFFF, focused ? GOLD_LIGHT : 0x55FFFFFF, focused ? 3 : 1, 26);
    }

    private LayerDrawable cardBg() {
        GradientDrawable dark = new GradientDrawable();
        dark.setColor(0x80081018); dark.setCornerRadius(dp(30));
        GradientDrawable frost = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0x40FFFFFF, 0x14FFFFFF, 0x24FFFFFF});
        frost.setCornerRadius(dp(30));
        frost.setStroke(Math.max(1, dp(1)), 0x77F1D68A);          // حد رفيع ذهبي شفاف
        return new LayerDrawable(new android.graphics.drawable.Drawable[]{dark, frost});
    }

    private View goldLine() {
        View v = new View(act);
        v.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0x00E6BE5A, 0xCCE6BE5A, 0x00E6BE5A}));
        return v;
    }

    private GradientDrawable shape(int fill, int stroke, float strokeDp, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(radiusDp));
        g.setStroke(Math.max(1, Math.round(strokeDp * density)), stroke);
        return g;
    }

    private GradientDrawable circle(int fill, int stroke, float strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL); g.setColor(fill);
        g.setStroke(Math.max(1, Math.round(strokeDp * density)), stroke);
        return g;
    }

    private LinearLayout.LayoutParams lpMargin(int w, int hgt, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, hgt);
        p.setMargins(l, t, r, b);
        return p;
    }

    private void hideIme() {
        try {
            InputMethodManager im = (InputMethodManager) act.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (im != null && search != null) im.hideSoftInputFromWindow(search.getWindowToken(), 0);
        } catch (Exception ignored) { }
    }

    private int dp(float v) { return Math.round(v * density); }
}
