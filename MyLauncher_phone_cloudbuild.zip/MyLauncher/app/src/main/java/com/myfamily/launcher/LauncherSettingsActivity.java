package com.myfamily.launcher;

import android.app.Activity;
import android.app.Dialog;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

/** إعدادات اللانشر: صفحة واحدة بتخطيط يشبه لانشرك الأصلي. */
public class LauncherSettingsActivity extends Activity {
    static final int TEXT = Color.WHITE, DIM = 0xB3FFFFFF, GREY = 0xFF8E9AAB, ACCENT = 0xFF6FD8FF;
    private SharedPreferences p;
    private LinearLayout page;
    private ScrollView sv;
    private String pendingFocus, lastTag;

    @Override protected void attachBaseContext(Context base) { super.attachBaseContext(LocaleHelper.wrap(base)); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        CleanStart.run(this);
        p = getSharedPreferences("launcher", MODE_PRIVATE);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(40), dp(28), dp(40), dp(40));
        sv = new ScrollView(this);
        sv.addView(page);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF08111F, 0xFF12384F}));
        setContentView(sv);
        render();
    }

    @Override protected void onResume() { super.onResume(); render(); }

    private void render() {
        page.removeAllViews();
        TextView title = text(34, TEXT, true); title.setText(R.string.menu_launcher_settings);
        title.setPadding(0, 0, 0, dp(12));
        page.addView(title);

        note(getString(R.string.ls_apps_moved));

        // ----- الخلفية -----
        heading(getString(R.string.sec_wallpaper));
        action(getString(R.string.wallpaper_studio), "ws", () -> startActivity(new Intent(this, WallpaperStudioActivity.class)));
        note(getString(R.string.wallpaper_note));
        toggle(getString(R.string.ls_contrast), "contrast", false);
        note(getString(R.string.ls_contrast_note));

        // ----- عناصر الشاشة الرئيسية (ما يظهر وما يُخفى) -----
        heading(getString(R.string.visibility_title));
        toggle(getString(R.string.clean_bg), "bg_clean", false);
        note(getString(R.string.clean_note));
        toggle(getString(R.string.vis_clock), "vis_clock", true);
        note(getString(R.string.note_vis_clock));
        toggle(getString(R.string.vis_prayer), "vis_prayer", true);
        note(getString(R.string.note_vis_prayer));
        toggle(getString(R.string.ls_weather_show), WeatherRepository.P_SHOW, true);
        note(getString(R.string.note_vis_weather));
        toggle(getString(R.string.vis_matches), "vis_matches", true);
        note(getString(R.string.note_vis_matches));
        toggle(getString(R.string.vis_net), "vis_net", true);
        note(getString(R.string.note_vis_net));
        toggle(getString(R.string.vis_title), "vis_title", true);
        note(getString(R.string.note_vis_title));
        toggle(getString(R.string.vis_onphotos), "vis_onphotos", true);
        note(getString(R.string.vis_onphotos_note));

        // ----- الساعة والتاريخ -----
        heading(getString(R.string.ls_clock_section));
        int cf = p.getInt("clock_fmt", 0);
        String[] fmts = {getString(R.string.fmt_system), getString(R.string.fmt_12), getString(R.string.fmt_24)};
        action(getString(R.string.ls_time_format, fmts[cf]), "cf", () -> p.edit().putInt("clock_fmt", (p.getInt("clock_fmt", 0) + 1) % 3).apply());
        toggle(getString(R.string.ls_show_date), "show_date", true);
        toggle(getString(R.string.ls_show_greeting), "show_greeting", true);

        // ----- الصلاة والأذان -----
        heading(getString(R.string.sec_prayer));
        action(getString(R.string.prayer_city_line, p.getString("city", getString(R.string.default_city))), "city",
                () -> startActivity(new Intent(this, MainActivity.class).putExtra("dlg", "city")));
        action(getString(R.string.timezone_line, p.getString("tz", "Africa/Algiers")), "tz",
                () -> startActivity(new Intent(this, MainActivity.class).putExtra("dlg", "city")));
        int m = p.getInt("method", 19);
        String mn = "";
        for (int i = 0; i < PrayerTimes.TABLE.length; i++)
            if ((int) PrayerTimes.TABLE[i][0] == m) mn = getResources().getStringArray(R.array.method_names)[i];
        action(getString(R.string.method_line, String.valueOf(m), mn), "method",
                () -> startActivity(new Intent(this, MainActivity.class).putExtra("dlg", "method")));
        note(getString(R.string.method_note));
        action(getString(R.string.adhan_channel), "adhan", () -> startActivity(new Intent(this, AdhanSettingsActivity.class)));
        action(getString(R.string.prayer_style, getString(p.getInt("prayer_style", 1) == 1 ? R.string.style_board : R.string.style_panel)), "pst",
                () -> p.edit().putInt("prayer_style", p.getInt("prayer_style", 1) == 1 ? 0 : 1).apply());
        note(getString(R.string.prayer_style_note));
        label(getString(R.string.hijri_adjust, String.valueOf(p.getInt("hijri_adj", 0))));
        options("ha", "hijri_adj", new int[]{-2, -1, 0, 1, 2}, 0);
        note(getString(R.string.hijri_note));

        // ----- الطقس -----
        heading(getString(R.string.ls_weather_section));
        toggle(getString(R.string.ls_weather_f), WeatherRepository.P_FAHRENHEIT, false);
        String ks = WeatherRepository.keyRejected(this) ? getString(R.string.ls_weather_key_bad)
                : WeatherRepository.hasKey(this) ? getString(R.string.ls_weather_key_ok) : getString(R.string.ls_weather_key_none);
        action(getString(R.string.ls_weather_key) + " · " + ks, "wkey", this::showWeatherDialog);
        note(getString(R.string.ls_weather_note));

        // ----- كرة القدم -----
        heading(getString(R.string.ls_fb_section));
        String fs = Football.keyRejected(this) ? getString(R.string.ls_weather_key_bad)
                : Football.hasKey(this) ? getString(R.string.ls_fb_key_ok) : getString(R.string.ls_fb_key_none);
        action(getString(R.string.ls_fb_key) + " · " + fs, "fkey", this::showFootballDialog);
        note(getString(R.string.ls_fb_note));

        // ----- شاشة التوقف -----
        heading(getString(R.string.sec_screensaver));
        String[] dcs = {getString(R.string.dream_clock_digital), getString(R.string.dream_clock_analog), getString(R.string.dream_clock_both)};
        action(getString(R.string.ls_dream_clock, dcs[Math.max(0, Math.min(2, p.getInt("dream_clock", 0)))]), "dc",
                () -> p.edit().putInt("dream_clock", (p.getInt("dream_clock", 0) + 1) % 3).apply());
        String[] dls = {getString(R.string.dial_black), getString(R.string.dial_white), getString(R.string.dial_coral)};
        int curDial = Math.max(0, Math.min(2, p.getInt("dream_dial", p.getBoolean("dream_dial_light", false) ? 1 : 0)));
        action(getString(R.string.ls_dream_dial, dls[curDial]), "dd",
                () -> p.edit().putInt("dream_dial", (curDial + 1) % 3).remove("dream_dial_light").apply());
        note(getString(R.string.dream_note));
        action(getString(R.string.screensaver_set), "ss", () -> {
            if (!launch(new Intent(Settings.ACTION_DREAM_SETTINGS),
                    comp("com.android.tv.settings", "com.android.tv.settings.device.display.daydream.DaydreamActivity"),
                    comp("com.android.tv.settings", "com.android.tv.settings.device.display.daydream.DaydreamActivity$DaydreamActivity"),
                    comp("com.android.settings", "com.android.settings.Settings$DreamSettingsActivity"))) {
                Toast.makeText(this, R.string.dream_path_help, Toast.LENGTH_LONG).show();
                launch(new Intent(Settings.ACTION_DISPLAY_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
            }
        });
        note(getString(R.string.screensaver_note));

        // ----- الراديو وشاشة الاستماع -----
        heading(getString(R.string.sec_ambient));
        String[] ambS = {getString(R.string.amb_s_ribbon), getString(R.string.amb_s_notes), getString(R.string.amb_s_black)};
        action(getString(R.string.amb_style_fmt, ambS[Math.max(0, Math.min(2, p.getInt("amb_style", 0)))]), "amb_style",
                () -> p.edit().putInt("amb_style", (p.getInt("amb_style", 0) + 1) % 3).apply());
        String[] ambP = {getString(R.string.amb_p_spectrum), getString(R.string.amb_p_amber), getString(R.string.amb_p_gold)};
        action(getString(R.string.amb_palette_fmt, ambP[Math.max(0, Math.min(2, p.getInt("amb_palette", 0)))]), "amb_palette",
                () -> p.edit().putInt("amb_palette", (p.getInt("amb_palette", 0) + 1) % 3).apply());
        String[] ambB = {getString(R.string.amb_b_low), getString(R.string.amb_b_mid), getString(R.string.amb_b_high)};
        action(getString(R.string.amb_bright_fmt, ambB[Math.max(0, Math.min(2, p.getInt("amb_bright", 1)))]), "amb_bright",
                () -> p.edit().putInt("amb_bright", (p.getInt("amb_bright", 1) + 1) % 3).apply());
        final int[] ambAutos = {0, 1, 5, 15};
        int ambAu = p.getInt("amb_auto", 0);
        action(getString(R.string.amb_auto_fmt, ambAu == 0 ? getString(R.string.amb_auto_never) : getString(R.string.amb_auto_after, ambAu)), "amb_auto", () -> {
            int cur = p.getInt("amb_auto", 0), nx = 0;
            for (int q = 0; q < ambAutos.length; q++) if (ambAutos[q] == cur) nx = (q + 1) % ambAutos.length;
            p.edit().putInt("amb_auto", ambAutos[nx]).apply();
        });
        note(getString(R.string.amb_settings_note));

        // ----- الحركات والمؤثرات -----
        heading(getString(R.string.sec_motion));
        String[] mls = {getString(R.string.motion_full), getString(R.string.motion_light), getString(R.string.motion_off)};
        action(getString(R.string.ls_motion, mls[motionLevel()]), "motion", () -> {
            int n = (motionLevel() + 1) % 3;                       // كاملة ← خفيفة ← متوقفة
            p.edit().putBoolean("anim", n != 2).putBoolean("effects", n == 0).apply();
        });
        note(getString(R.string.ls_motion_note));
        action(getString(R.string.ls_reset_appearance), "reset", () -> {
            p.edit().remove("apps_per_row").remove("extra_rows").remove("contrast").remove("clock_fmt").remove("dream_clock").remove("dream_dial_light").remove("dream_dial")
                    .remove("show_date").remove("show_greeting").remove("anim").remove("effects").apply();
            Toast.makeText(this, R.string.ls_reset_done, Toast.LENGTH_SHORT).show();
        });
        note(getString(R.string.ls_reset_note));

        // ----- النظام -----
        heading(getString(R.string.sec_system));
        action(getString(R.string.home_key, onOff(HomeKeyService.isEnabled(this))), "hk", this::setupHomeKey);
        note(getString(R.string.home_key_note));
        action(getString(R.string.ls_default_home), "home", () -> {
            try { startActivity(new Intent(Settings.ACTION_HOME_SETTINGS)); }
            catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        });
        note(getString(R.string.ls_default_home_note));
        action(getString(R.string.tv_settings), "tv", () -> startActivity(new Intent(Settings.ACTION_SETTINGS)));

        String tg = pendingFocus != null ? pendingFocus : lastTag;     // يبقى التركيز على الصف الذي ضغطته (حتى بعد العودة من شاشة أخرى)
        pendingFocus = null;
        View v = tg != null ? sv.findViewWithTag(tg) : null;
        if (v == null && sv.findFocus() == null) v = sv.findViewWithTag("apr5");
        if (v != null) v.requestFocus();
        lastTag = tg;
    }

    // ---------- عناصر ----------
    private void options(String tagPrefix, String key, int[] values, int def) {
        LinearLayout row = new LinearLayout(this);
        int cur = p.getInt(key, def);
        for (int v : values) {
            final int vv = v;
            TextView t = text(20, TEXT, false); t.setText(String.valueOf(v)); t.setGravity(Gravity.CENTER);
            t.setPadding(dp(8), dp(18), dp(8), dp(18));
            t.setFocusable(true); t.setClickable(true); t.setTag(tagPrefix + v);
            style(t, false, cur == v);
            t.setOnFocusChangeListener((x, f) -> style(x, f, p.getInt(key, def) == vv));
            t.setOnClickListener(x -> { p.edit().putInt(key, vv).apply(); pendingFocus = tagPrefix + vv; render(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.setMargins(0, dp(4), dp(10), dp(4));
            row.addView(t, lp);
        }
        page.addView(row);
    }

    private Intent comp(String pkg, String cls) { return new Intent().setComponent(new ComponentName(pkg, cls)); }

    /** يجرّب الأهداف بالترتيب، ولا يبدأ إلا ما يوجد فعلًا على الجهاز (بعض التلفازات تعرض رسالة خطأ بدل رفع استثناء). */
    private boolean launch(Intent... list) {
        for (Intent i : list) {
            try {
                if (i.resolveActivity(getPackageManager()) != null) { startActivity(i); return true; }
            } catch (Exception ignored) { }
        }
        return false;
    }

    /** تفعيل خدمة زر Home: مباشرة إن مُنح الإذن عبر ADB، وإلا شاشة إمكانية الوصول، وإلا شرح الأوامر. */
    private void setupHomeKey() {
        if (HomeKeyService.isEnabled(this)) { Toast.makeText(this, R.string.home_enabled, Toast.LENGTH_SHORT).show(); return; }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED) {
            try {
                String me = new ComponentName(this, HomeKeyService.class).flattenToString();
                String cur = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
                String all = (cur == null || cur.isEmpty()) ? me : (cur.contains(me) ? cur : cur + ":" + me);
                Settings.Secure.putString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, all);
                Settings.Secure.putInt(getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 1);
                Toast.makeText(this, R.string.home_enabled, Toast.LENGTH_LONG).show();
                return;
            } catch (Exception ignored) { }
        }
        if (launch(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
                comp("com.android.tv.settings", "com.android.tv.settings.accessibility.AccessibilityActivity"),
                comp("com.android.settings", "com.android.settings.Settings$AccessibilitySettingsActivity"))) return;
        new android.app.AlertDialog.Builder(this).setMessage(getString(R.string.home_adb_help, getPackageName())).setPositiveButton(android.R.string.ok, null).show();
    }

    /** إدخال مفتاح WeatherAPI (يُحفظ مشفّراً) والمدينة الاختيارية. لا يُعرض المفتاح الحالي أبداً. */
    private void showWeatherDialog() {
        final int pad = dp(20);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, dp(8), pad, 0);
        TextView help = new TextView(this); help.setText(R.string.weather_help); help.setTextSize(15); help.setPadding(0, 0, 0, dp(10));
        box.addView(help);
        final android.widget.EditText key = new android.widget.EditText(this);
        key.setHint(R.string.weather_key_hint); key.setSingleLine(true);
        key.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        final android.widget.EditText city = new android.widget.EditText(this);
        city.setHint(R.string.weather_city_hint); city.setSingleLine(true);
        city.setText(WeatherRepository.city(this));
        final Button wqr = new Button(this); wqr.setText(R.string.fb_qr_btn);
        key.setId(View.generateViewId()); wqr.setId(View.generateViewId()); city.setId(View.generateViewId());
        key.setNextFocusDownId(wqr.getId()); wqr.setNextFocusUpId(key.getId());
        wqr.setNextFocusDownId(city.getId()); city.setNextFocusUpId(wqr.getId());
        box.addView(key); box.addView(wqr); box.addView(city);
        final android.app.AlertDialog wdlg = new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.weather_dlg_title).setView(box)
                .setPositiveButton(android.R.string.ok, (d, w) -> {
                    String k = key.getText().toString().trim();
                    if (!k.isEmpty()) WeatherRepository.saveKey(this, k);
                    WeatherRepository.saveCity(this, city.getText().toString());
                    WeatherRepository.refresh(this, true, null);
                })
                .setNeutralButton(R.string.weather_remove_key, (d, w) -> WeatherRepository.saveKey(this, ""))
                .setNegativeButton(android.R.string.cancel, null)
                .setOnDismissListener(d -> render())
                .create();
        wqr.setOnClickListener(v -> { wdlg.dismiss(); showWeatherQr(); });
        wdlg.show();
    }

    /** مفتاح API-Football: إدخال يدوي أو عبر QR من الهاتف. لا يُعرض المفتاح الحالي أبداً. */
    private void showFootballDialog() {
        final int pad = dp(20);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, dp(8), pad, 0);
        TextView help = new TextView(this); help.setText(R.string.fb_help); help.setTextSize(15); help.setPadding(0, 0, 0, dp(10));
        final android.widget.EditText key = new android.widget.EditText(this);
        key.setHint(R.string.fb_key_hint); key.setSingleLine(true);
        key.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        final Button qr = new Button(this); qr.setText(R.string.fb_qr_btn);
        key.setId(View.generateViewId()); qr.setId(View.generateViewId());
        key.setNextFocusDownId(qr.getId()); qr.setNextFocusUpId(key.getId());   // الريموت: من الحقل إلى زر QR مباشرة
        box.addView(help); box.addView(key); box.addView(qr);
        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.fb_dlg_title).setView(box)
                .setPositiveButton(android.R.string.ok, (d, w) -> {
                    String k = key.getText().toString().trim();
                    if (k.isEmpty()) return;
                    if (!Football.validKey(k)) { Toast.makeText(this, R.string.fb_key_invalid, Toast.LENGTH_LONG).show(); return; }
                    Football.saveKey(this, k);
                    Football.refresh(this, true, null);
                })
                .setNeutralButton(R.string.weather_remove_key, (d, w) -> Football.saveKey(this, ""))
                .setNegativeButton(android.R.string.cancel, null)
                .setOnDismissListener(d -> render())
                .create();
        qr.setOnClickListener(v -> { dlg.dismiss(); showFootballQr(); });
        dlg.show();
    }

    private interface KeySaver { void save(String k); }

    private void showFootballQr() {
        showKeyQr("API-Football", k -> { Football.saveKey(this, k); Football.refresh(this, true, null); });
    }

    private void showWeatherQr() {
        showKeyQr("WeatherAPI", k -> { WeatherRepository.saveKey(this, k); WeatherRepository.refresh(this, true, null); });
    }

    /** نافذة QR عامة: يرسل الهاتف مفتاحاً نصياً، فيُتحقق منه ويُحفظ عبر saver. */
    private void showKeyQr(String pageTitle, final KeySaver saver) {
        String ip = UploadServer.localIp();
        if (ip == null) { Toast.makeText(this, R.string.up_noip, Toast.LENGTH_LONG).show(); return; }
        final Dialog[] holder = new Dialog[1];
        final UploadServer srv;
        try {
            srv = new UploadServer(new java.io.File(getCacheDir(), "up"), tmp -> {
                String k;
                try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader(tmp))) { k = String.valueOf(r.readLine()).trim(); }
                catch (Exception e) { return false; }
                if (!Football.validKey(k)) return false;
                saver.save(k);
                runOnUiThread(() -> { Toast.makeText(this, R.string.fb_key_saved, Toast.LENGTH_LONG).show(); if (holder[0] != null) holder[0].dismiss(); });
                return true;
            }, true);
        } catch (java.io.IOException e) { Toast.makeText(this, R.string.save_failed, Toast.LENGTH_SHORT).show(); return; }
        srv.setKeyTitle(pageTitle);
        srv.start();
        String url = "http://" + ip + ":" + srv.port() + "/" + srv.code;
        boolean[][] m = QrCode.encode(url);
        int n = m.length, q = 4, sc = Math.max(4, dp(300) / (n + 2 * q));
        Bitmap bm = Bitmap.createBitmap((n + 2 * q) * sc, (n + 2 * q) * sc, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bm); cv.drawColor(Color.WHITE);
        Paint pt = new Paint(); pt.setColor(Color.BLACK);
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
            if (m[y][x]) cv.drawRect((x + q) * sc, (y + q) * sc, (x + q + 1) * sc, (y + q + 1) * sc, pt);
        ImageView iv = new ImageView(this); iv.setImageBitmap(bm);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(28), dp(20), dp(28), dp(20));
        box.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF08111F, 0xFF12384F}));
        TextView title = text(24, TEXT, true); title.setText(R.string.fb_qr_title); title.setGravity(Gravity.CENTER);
        TextView link = text(16, ACCENT, false); link.setText(url); link.setPadding(0, dp(10), 0, dp(4));
        TextView note = text(14, DIM, false); note.setText(R.string.up_note); note.setGravity(Gravity.CENTER);
        box.addView(title); box.addView(iv); box.addView(link); box.addView(note);
        Dialog d = new Dialog(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        holder[0] = d;
        d.setContentView(box);
        d.setOnDismissListener(x -> { srv.stop(); render(); });
        d.show();
    }

    private String sortLabel() {
        int[] ids = {R.string.sort_az, R.string.sort_most, R.string.sort_recent, R.string.sort_new};
        return getString(ids[Math.max(0, Math.min(3, p.getInt("apps_sort", 0)))]);
    }

    private String onOff(boolean b) { return getString(b ? R.string.on : R.string.off); }

    private void toggle(String label, String key, boolean def) { toggle(label, key, def, false); }

    /** labelHasState: النص يحوي الحالة أصلًا (مثل «Animations : Activé»). */
    private void toggle(String label, String key, boolean def, boolean labelHasState) {
        boolean on = p.getBoolean(key, def);
        TextView t = text(20, TEXT, false);
        t.setText(labelHasState ? label : label + " · " + onOff(on));
        t.setPadding(dp(20), dp(18), dp(20), dp(18));
        t.setFocusable(true); t.setClickable(true); t.setTag("t_" + key);
        style(t, false, on);
        t.setOnFocusChangeListener((x, f) -> style(x, f, p.getBoolean(key, def)));
        t.setOnClickListener(x -> { p.edit().putBoolean(key, !p.getBoolean(key, def)).apply(); pendingFocus = "t_" + key; render(); });
        page.addView(t, rowLp());
    }

    private void action(String label, String tag, Runnable r) {
        TextView t = text(20, TEXT, false); t.setText(label);
        t.setPadding(dp(20), dp(18), dp(20), dp(18));
        t.setFocusable(true); t.setClickable(true); t.setTag(tag);
        style(t, false, false);
        t.setOnFocusChangeListener((x, f) -> style(x, f, false));
        t.setOnClickListener(x -> { r.run(); pendingFocus = tag; render(); });
        page.addView(t, rowLp());
    }

    /** عنوان قسم: لون مميّز + خط فاصل رفيع تحته. */
    private void heading(String s) {
        TextView t = text(22, ACCENT, true); t.setText(s); t.setPadding(0, dp(22), 0, dp(6));
        page.addView(t);
        View line = new View(this); line.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Math.max(1, dp(1))); lp.bottomMargin = dp(4);
        page.addView(line, lp);
    }
    /** عنوان فرعي داخل قسم. */
    private void label(String s) {
        TextView t = text(18, TEXT, true); t.setText(s); t.setPadding(dp(2), dp(10), 0, dp(2));
        page.addView(t);
    }
    /** شرح صغير رمادي تحت الخانة. */
    private void note(String s) {
        TextView t = text(13, GREY, false); t.setText(s); t.setPadding(dp(6), dp(1), dp(6), dp(8));
        page.addView(t);
    }
    /** 0 كاملة (حركة + تكبير) · 1 خفيفة (حركة بلا تكبير) · 2 متوقفة. */
    private int motionLevel() {
        boolean a = p.getBoolean("anim", true), e = p.getBoolean("effects", true);
        return !a ? 2 : (e ? 0 : 1);
    }
    private void spacer() { page.addView(new View(this), new LinearLayout.LayoutParams(-1, dp(14))); }

    private LinearLayout.LayoutParams rowLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(4), 0, dp(4)); return lp;
    }

    private void style(View v, boolean focused, boolean selected) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(18));
        g.setColor(selected ? 0xFF143B52 : 0xFF11213A);
        g.setStroke(dp(focused || selected ? 3 : 1), focused ? 0xFFB8EEFF : selected ? 0xFF4FA8CC : 0x55FFFFFF);
        v.setBackground(g);
    }
    private TextView text(int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setTextSize(sp); t.setTextColor(color);
        t.setTypeface(bold ? Fonts.bold(this) : Fonts.outfit(this));
        return t;
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
