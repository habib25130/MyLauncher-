package com.myfamily.launcher;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * موقع الجهاز عبر LocationManager (من النظام نفسه، بلا أي مكتبة إضافية ولا حاجة لخدمات Google Play).
 * الترتيب: آخر موقع معروف ← طلب تحديث واحد (شبكة ثم GPS) بمهلة 10 ث.
 * عند رفض الإذن أو تعذّر الموقع: آخر موقع محفوظ (≤ 7 أيام) ثم إحداثيات المدينة المحفوظة ثم الافتراضية.
 * لا يلمس lat/lng الخاصة بمواقيت الصلاة.
 */
final class DeviceLocation {
    private static final String P_LAT = "dev_lat", P_LON = "dev_lon", P_AT = "dev_loc_at";
    private static final long FRESH_MS = 30 * 60_000L, RETRY_MS = 10 * 60_000L, MAX_AGE_MS = 7 * 24 * 3600_000L, TIMEOUT_MS = 10_000L;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static boolean busy;
    private static long lastTry;

    private DeviceLocation() { }

    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences("launcher", Context.MODE_PRIVATE); }

    static boolean hasPermission(Context c) {
        return Build.VERSION.SDK_INT < 23
                || c.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || c.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    /** true إذا لا يوجد موقع جهاز صالح (≤ 7 أيام) ونعتمد الموقع الافتراضي/المحفوظ. */
    static boolean usingFallback(Context c) {
        SharedPreferences p = prefs(c);
        long at = p.getLong(P_AT, 0);
        return !(at > 0 && System.currentTimeMillis() - at < MAX_AGE_MS && p.contains(P_LAT) && p.contains(P_LON));
    }

    /** "lat,lon": موقع الجهاز المحفوظ وإلا إحداثيات المدينة المحفوظة وإلا الافتراضية (33.80,2.88). */
    static String queryOrDefault(Context c) {
        SharedPreferences p = prefs(c);
        if (!usingFallback(c)) return p.getString(P_LAT, "") + "," + p.getString(P_LON, "");
        return p.getString("lat", "33.80") + "," + p.getString("lng", "2.88");
    }

    /** يحدّث موقع الجهاز في الخلفية عند الحاجة (كل 30 دقيقة كحد أدنى). onUpdated على الخيط الرئيسي عند نجاح موقع جديد. */
    @SuppressLint("MissingPermission")
    @SuppressWarnings("deprecation")
    static void refresh(Context ctx, Runnable onUpdated) {
        final Context app = ctx.getApplicationContext();
        long now = System.currentTimeMillis();
        if (busy || !hasPermission(app) || !WeatherRepository.hasKey(app)) return;
        if (now - prefs(app).getLong(P_AT, 0) < FRESH_MS || now - lastTry < RETRY_MS) return;
        final LocationManager lm = (LocationManager) app.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return;
        busy = true; lastTry = now;
        final Req r = new Req(app, lm, onUpdated);
        try {
            Location best = null;
            for (String pv : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(pv);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            if (best != null) { r.finish(best); return; }
            String pv = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) ? LocationManager.NETWORK_PROVIDER
                    : lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ? LocationManager.GPS_PROVIDER : null;
            if (pv == null) { r.finish(null); return; }          // لا مزوّد موقع (حال أغلب صناديق التلفاز) → fallback
            MAIN.postDelayed(r.timeout, TIMEOUT_MS);
            lm.requestSingleUpdate(pv, r, Looper.getMainLooper());
        } catch (Throwable t) { r.finish(null); }
    }

    private static final class Req implements LocationListener {
        final Context app; final LocationManager lm; final Runnable onUpdated;
        final AtomicBoolean once = new AtomicBoolean();
        final Runnable timeout = () -> finish(null);
        Req(Context app, LocationManager lm, Runnable onUpdated) { this.app = app; this.lm = lm; this.onUpdated = onUpdated; }

        @Override public void onLocationChanged(Location l) { finish(l); }
        @Override public void onStatusChanged(String p, int s, Bundle e) { }
        @Override public void onProviderEnabled(String p) { }
        @Override public void onProviderDisabled(String p) { }

        void finish(Location loc) {
            if (!once.compareAndSet(false, true)) return;
            MAIN.removeCallbacks(timeout);
            try { lm.removeUpdates(this); } catch (Throwable ignored) { }
            busy = false;
            if (loc == null) return;                              // الـ fallback يعمل تلقائياً في queryOrDefault
            prefs(app).edit()
                    .putString(P_LAT, String.format(Locale.US, "%.2f", loc.getLatitude()))   // ~1 كم: يكفي للطقس ويثبّت الكاش
                    .putString(P_LON, String.format(Locale.US, "%.2f", loc.getLongitude()))
                    .putLong(P_AT, System.currentTimeMillis()).apply();
            if (onUpdated != null) onUpdated.run();
        }
    }
}
