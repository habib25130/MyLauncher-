package com.myfamily.launcher;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.TextPaint;
import android.widget.TextView;

/** نص بحدّ خارجي أسود رقيق (اختياري) فوق الظل الناعم: يبقى واضحًا فوق أي خلفية. بلا حدّ افتراضيًا. */
final class OutlineText extends TextView {
    private float strokePx;
    private int strokeColor = 0xE6000000;
    private boolean drawing;

    OutlineText(Context c) { super(c); }

    void setOutline(float px, int color) { strokePx = px; strokeColor = color; invalidate(); }

    @Override public void invalidate() { if (!drawing) super.invalidate(); }   // setTextColor داخل onDraw لا يُعيد الرسم

    @Override protected void onDraw(Canvas c) {
        if (strokePx <= 0f) { super.onDraw(c); return; }
        TextPaint tp = getPaint();
        ColorStateList fill = getTextColors();
        Paint.Style oldStyle = tp.getStyle();
        float oldWidth = tp.getStrokeWidth();
        drawing = true;
        tp.setStyle(Paint.Style.STROKE); tp.setStrokeWidth(strokePx); tp.setStrokeJoin(Paint.Join.ROUND);
        setTextColor(strokeColor);
        super.onDraw(c);
        tp.setStyle(oldStyle); tp.setStrokeWidth(oldWidth);
        setTextColor(fill);
        drawing = false;
        super.onDraw(c);
    }
}
