package com.myfamily.launcher;

import android.content.Context;
import android.content.res.Configuration;
import android.util.DisplayMetrics;
import java.util.Locale;

/** لغة التطبيق المختارة من «À propos · Soutien» («» = لغة النظام). */
final class LocaleHelper {
    static Context wrap(Context c) {
        String l = c.getSharedPreferences("launcher", Context.MODE_PRIVATE).getString("lang", "");
        Locale source = l == null || l.isEmpty()
                ? c.getResources().getConfiguration().locale : new Locale(l);
        if (source == null) source = Locale.getDefault();
        Locale loc = new Locale.Builder().setLocale(source)
                .setUnicodeLocaleKeyword("nu", "latn").build();
        Locale.setDefault(loc);
        Configuration cfg = new Configuration(c.getResources().getConfiguration());
        cfg.setLocale(loc);
        // Keep Arabic text localized, but use the same left-to-right UI flow as French.
        cfg.setLayoutDirection(Locale.FRENCH);
        if (BuildConfig.PHONE) {
            // نسخة الهاتف للتجريب: التصميم مبني على شاشة تلفاز (≈1280dp عرضًا) فنصغّر الكثافة ليظهر بنفس النِّسب على الهاتف
            DisplayMetrics dm = c.getResources().getDisplayMetrics();
            float longPx = Math.max(dm.widthPixels, dm.heightPixels);
            int dpi = Math.round(longPx / 1280f * 160f);
            cfg.densityDpi = Math.max(120, Math.min(dpi, cfg.densityDpi > 0 ? cfg.densityDpi : dpi));
        }
        return c.createConfigurationContext(cfg);
    }

    static String westernDigits(String value) {
        if (value == null || value.isEmpty()) return value;
        StringBuilder out = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            if (ch >= '\u0660' && ch <= '\u0669') ch = (char) ('0' + ch - '\u0660');
            else if (ch >= '\u06f0' && ch <= '\u06f9') ch = (char) ('0' + ch - '\u06f0');
            out.append(ch);
        }
        return out.toString();
    }
}
