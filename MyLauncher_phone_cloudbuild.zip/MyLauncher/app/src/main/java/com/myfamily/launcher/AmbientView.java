package com.myfamily.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Paint.Align;
import android.view.View;

import java.util.Date;
import java.util.Random;

/**
 * مشهد «شاشة الاستماع»: خيوط ضوئية انسيابية، أو أشرطة ملونة مع نغمات وبوكيه وانعكاس، أو شاشة سوداء بساعة خافتة.
 * كله رسم برمجي بلا صور وبلا Blur (ذاكرة التلفاز ≈ 1 غيغابايت). الحركة محاكاة جمالية لا تحليل طيف حقيقي،
 * فلا حاجة لأي إذن. عند إيقاف الصوت تهدأ الخطوط إلى خط مستقيم.
 */
final class AmbientView extends View {
    static final int STYLE_RIBBON = 0, STYLE_NOTES = 1, STYLE_BLACK = 2;

    /** لوحات الألوان: طيف · عنبري دافئ (بلا أزرق للنوم) · ذهبي. */
    private static final int[][] PALETTES = {
            {0xFFFFE9A8, 0xFFF4A261, 0xFFE0508B, 0xFF9B5DE5, 0xFF4CC9F0},
            {0xFFFFDDA6, 0xFFFFA45C, 0xFFFF7A59, 0xFFE0614F, 0xFFC4503F},
            {0xFFFFF1C2, 0xFFE6BE5A, 0xFFC99A35, 0xFFE6BE5A, 0xFFFFF1C2}
    };
    private static final float[] BRIGHT = {0.38f, 0.66f, 1f};
    private static final int PTS = 110, LINES = 34, NOTE_LINES = 9, BANDS = 3, BOKEH = 10, NOTES = 14;
    private static final float[][] BAND_U = {{-0.85f, -0.2f}, {-0.45f, 0.45f}, {0.2f, 0.85f}};

    private final float density;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint note = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stem = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fade = new Paint();
    private final Paint textP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint[] bokehP = new Paint[BOKEH];
    private final Path[] lines = new Path[LINES];
    private final Path[] bands = new Path[BANDS];
    private final Path notePath = new Path();
    private final RectF rect = new RectF();

    // عناصر ثابتة عشوائية (نفس الشكل في كل مرة)
    private final float[] bkX = new float[BOKEH], bkY = new float[BOKEH], bkR = new float[BOKEH], bkPh = new float[BOKEH];
    private final int[] bkCol = new int[BOKEH];
    private final float[] nX = new float[NOTES], nOff = new float[NOTES], nSize = new float[NOTES],
            nSpd = new float[NOTES], nPh = new float[NOTES];
    private final int[] nType = new int[NOTES];

    private int style = STYLE_RIBBON, palette, bright = 1;
    private float target, level, time, energy = 1f;
    private String label = "", clockStr = "";
    private long lastClockMs;
    private boolean running;
    private long lastNs;
    private int shaderKey = -1;

    private final Runnable step = this::tick;

    AmbientView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        for (int i = 0; i < LINES; i++) lines[i] = new Path();
        for (int i = 0; i < BANDS; i++) bands[i] = new Path();
        line.setStyle(Paint.Style.STROKE); line.setStrokeJoin(Paint.Join.ROUND);
        glow.setStyle(Paint.Style.STROKE); glow.setStrokeJoin(Paint.Join.ROUND); glow.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        note.setStyle(Paint.Style.FILL);
        stem.setStyle(Paint.Style.STROKE); stem.setStrokeCap(Paint.Cap.ROUND); stem.setStrokeJoin(Paint.Join.ROUND);
        fade.setStyle(Paint.Style.FILL);
        textP.setTextAlign(Align.CENTER); textP.setTypeface(Fonts.outfit(c));
        Random r = new Random(11);
        for (int i = 0; i < BOKEH; i++) {
            bkX[i] = r.nextFloat(); bkY[i] = 0.12f + r.nextFloat() * 0.66f;
            bkR[i] = 0.03f + r.nextFloat() * 0.045f; bkPh[i] = r.nextFloat() * 6.28f; bkCol[i] = r.nextInt(5);
            bokehP[i] = new Paint(Paint.ANTI_ALIAS_FLAG);
        }
        for (int i = 0; i < NOTES; i++) {
            nX[i] = r.nextFloat(); nOff[i] = -0.30f + r.nextFloat() * 0.46f;
            nSize[i] = 0.016f + r.nextFloat() * 0.014f; nSpd[i] = 0.6f + r.nextFloat() * 0.8f;
            nPh[i] = r.nextFloat(); nType[i] = r.nextInt(3);
        }
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    // ===================== واجهة التحكم =====================
    void setStyle(int s) { style = Math.max(0, Math.min(2, s)); restart(); }
    void setPalette(int p) { palette = Math.max(0, Math.min(PALETTES.length - 1, p)); shaderKey = -1; invalidate(); }
    void setBrightness(int b) { bright = Math.max(0, Math.min(2, b)); invalidate(); }
    /** 1 = تشغيل فعلي · 0.3 = تحميل · 0 = متوقف (خط مستقيم). */
    void setTarget(float t) { target = t; }
    void setLabel(String s) { label = s == null ? "" : s; invalidate(); }

    private void restart() { removeCallbacks(step); running = false; kick(0); }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); kick(0); }
    @Override protected void onDetachedFromWindow() { removeCallbacks(step); running = false; lastNs = 0; super.onDetachedFromWindow(); }
    @Override protected void onVisibilityChanged(View v, int vis) {
        super.onVisibilityChanged(v, vis);
        if (vis != VISIBLE) { removeCallbacks(step); running = false; lastNs = 0; }
        else if (isAttachedToWindow()) kick(0);
    }
    @Override protected void onSizeChanged(int w, int h, int ow, int oh) { shaderKey = -1; }

    private void kick(long delay) {
        if (running) return;
        running = true;
        postOnAnimationDelayed(step, delay);
    }

    private void tick() {
        running = false;
        if (!isAttachedToWindow() || getVisibility() != VISIBLE) return;
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.033f : Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        time += dt;
        level += (target - level) * (1f - (float) Math.exp(-dt / (target > level ? 0.35f : 0.6f)));
        energy = 0.82f + 0.18f * (float) Math.sin(time * 0.55f);
        invalidate();
        kick(style == STYLE_BLACK ? 1000 : 33);       // ≈ 30 إطارًا في الثانية؛ والأسود يكتفي بتحديث الساعة
    }

    // ===================== الشكل الموجي =====================
    /** انزياح عمودي في [-1, 1] عند الموضع t∈[0,1] للخط ذي المعامل u. الأطراف مسطّحة والوسط منتفخ. */
    private float shape(float t, float u, float spread) {
        float env = (float) Math.pow(Math.max(0.0, Math.sin(Math.PI * t)), 1.6);
        float a = (float) Math.sin(t * 7.234f * 1.0f + time * 1.10f + u * spread);
        float b = (float) Math.sin(t * 14.47f - time * 1.70f + u * spread * 1.6f + 1.3f) * 0.55f;
        float c = (float) Math.sin(t * 23.25f + time * 2.30f + u * spread * 2.1f + 2.4f) * 0.30f;
        return env * (a + b + c) / 1.85f;
    }

    private void fillLine(Path p, float u, float cy, float amp, float w, float spread) {
        p.reset();
        for (int i = 0; i <= PTS; i++) {
            float t = i / (float) PTS;
            float y = cy - amp * shape(t, u, spread);
            if (i == 0) p.moveTo(0f, y); else p.lineTo(t * w, y);
        }
    }

    private void fillBand(Path p, float uA, float uB, float cy, float amp, float w, float spread) {
        p.reset();
        for (int i = 0; i <= PTS; i++) {
            float t = i / (float) PTS;
            float y = cy - amp * shape(t, uA, spread);
            if (i == 0) p.moveTo(0f, y); else p.lineTo(t * w, y);
        }
        for (int i = PTS; i >= 0; i--) {
            float t = i / (float) PTS;
            p.lineTo(t * w, cy - amp * shape(t, uB, spread));
        }
        p.close();
    }

    // ===================== الألوان =====================
    private void ensureShaders(int w, int h) {
        int key = palette * 1_000_003 + w * 31 + h;
        if (key == shaderKey) return;
        shaderKey = key;
        int[] cols = PALETTES[palette];
        Shader lg = new LinearGradient(0, 0, w, 0, cols, null, Shader.TileMode.CLAMP);
        line.setShader(lg); glow.setShader(lg); fill.setShader(lg);
        float axis = h * 0.70f;
        fade.setShader(new LinearGradient(0, axis, 0, h, new int[]{0x00000000, 0xE6000000, 0xFF000000},
                new float[]{0f, 0.75f, 1f}, Shader.TileMode.CLAMP));
        for (int i = 0; i < BOKEH; i++) {
            int c = cols[bkCol[i]] & 0x00FFFFFF;
            float r = Math.max(4f, bkR[i] * h);
            bokehP[i].setShader(new RadialGradient(0, 0, r, new int[]{c | 0xC0000000, c | 0x40000000, c},
                    new float[]{0f, 0.72f, 1f}, Shader.TileMode.CLAMP));
        }
    }

    private int colorAt(float t) {
        int[] cs = PALETTES[palette];
        float f = Math.max(0f, Math.min(0.9999f, t)) * (cs.length - 1);
        int i = (int) f; float k = f - i;
        int a = cs[i], b = cs[i + 1];
        int r = (int) (((a >> 16) & 255) * (1 - k) + ((b >> 16) & 255) * k);
        int g = (int) (((a >> 8) & 255) * (1 - k) + ((b >> 8) & 255) * k);
        int bl = (int) ((a & 255) * (1 - k) + (b & 255) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // ===================== الرسم =====================
    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawColor(Color.BLACK);
        if (w <= 0 || h <= 0) return;
        float bm = BRIGHT[bright];
        if (style != STYLE_BLACK) {
            ensureShaders(w, h);
            float cy = h * (style == STYLE_NOTES ? 0.46f : 0.50f);
            float amp = h * (style == STYLE_NOTES ? 0.17f : 0.21f) * level * energy;
            float spread = style == STYLE_NOTES ? 0.9f : 1.15f;
            if (style == STYLE_RIBBON) {
                for (int j = 0; j < LINES; j++) fillLine(lines[j], (j / (float) (LINES - 1)) * 2f - 1f, cy, amp, w, spread);
                drawRibbon(c, bm, 1f);
            } else {
                for (int j = 0; j < NOTE_LINES; j++) fillLine(lines[j], (j / (float) (NOTE_LINES - 1)) * 1.7f - 0.85f, cy, amp, w, spread);
                for (int j = 0; j < BANDS; j++) fillBand(bands[j], BAND_U[j][0], BAND_U[j][1], cy, amp, w, spread);
                drawBokeh(c, bm, w, h);
                drawNotesScene(c, bm, 1f, cy, amp, w, h, spread);
                float axis = h * 0.70f;                                  // الانعكاس: نسخة مقلوبة خافتة تتلاشى نحو الأسفل
                c.save();
                c.clipRect(0, axis, w, h);
                c.translate(0, 2 * axis); c.scale(1, -1);
                drawNotesScene(c, bm, 0.34f, cy, amp, w, h, spread);
                c.restore();
                c.drawRect(0, axis, w, h, fade);
            }
        }
        drawTexts(c, w, h, bm);
    }

    private void drawRibbon(Canvas c, float bm, float am) {
        line.setStrokeWidth(Math.max(1f, density * 0.85f));
        line.setAlpha((int) (72 * bm * am));
        for (int j = 0; j < LINES; j++) c.drawPath(lines[j], line);
        glow.setStrokeWidth(density * 6f);
        glow.setAlpha((int) (16 * bm * am));
        for (int j = 0; j < LINES; j += 3) c.drawPath(lines[j], glow);
    }

    private void drawNotesScene(Canvas c, float bm, float am, float cy, float amp, int w, int h, float spread) {
        fill.setAlpha((int) (40 * bm * am));
        for (int j = 0; j < BANDS; j++) c.drawPath(bands[j], fill);
        line.setStrokeWidth(Math.max(1f, density * 1.0f));
        line.setAlpha((int) (105 * bm * am));
        for (int j = 0; j < NOTE_LINES; j++) c.drawPath(lines[j], line);
        glow.setStrokeWidth(density * 7f);
        glow.setAlpha((int) (24 * bm * am));
        for (int j = 0; j < NOTE_LINES; j += 4) c.drawPath(lines[j], glow);
        // النغمات تطفو فوق الموجة وتتلاشى عند الأطراف وبحسب دورة حياتها
        float vis = Math.min(1f, level * 1.4f);
        for (int i = 0; i < NOTES; i++) {
            float x01 = (nX[i] + time * 0.012f * nSpd[i]) % 1f;
            float life = (time * 0.05f * nSpd[i] + nPh[i]) % 1f;
            float a = (float) Math.sin(Math.PI * life) * (float) Math.sqrt(Math.max(0.0, Math.sin(Math.PI * x01))) * vis;
            if (a < 0.03f) continue;
            float yWave = cy - amp * shape(x01, 0f, spread) * 0.9f;
            float bob = (float) Math.sin(time * 0.9f * nSpd[i] + nPh[i] * 6.28f) * h * 0.012f;
            float y = yWave + nOff[i] * h + bob;
            drawNote(c, x01 * w, y, nSize[i] * h, nType[i], colorAt(x01), (int) (235 * a * bm * am));
        }
    }

    private void drawNote(Canvas c, float x, float y, float s, int type, int color, int alpha) {
        note.setColor(color); note.setAlpha(alpha);
        stem.setColor(color); stem.setAlpha(alpha);
        float sw = Math.max(1f, s * 0.17f);
        stem.setStrokeWidth(sw);
        float sx = x + s * 0.52f, top = y - s * 3.1f;
        c.save(); c.rotate(-22f, x, y);
        rect.set(x - s * 0.62f, y - s * 0.44f, x + s * 0.62f, y + s * 0.44f);
        c.drawOval(rect, note);
        c.restore();
        c.drawLine(sx, y - s * 0.15f, sx, top, stem);
        if (type == 0) {                                       // نغمة بذيل
            notePath.reset();
            notePath.moveTo(sx, top);
            notePath.cubicTo(sx + s * 0.2f, top + s * 0.9f, sx + s * 1.25f, top + s * 1.0f, sx + s * 0.8f, top + s * 2.1f);
            c.drawPath(notePath, stem);
        } else if (type == 2) {                                // نغمتان بينهما رباط
            float x2 = x + s * 1.9f, y2 = y - s * 0.35f, sx2 = x2 + s * 0.52f, top2 = y2 - s * 3.1f;
            c.save(); c.rotate(-22f, x2, y2);
            rect.set(x2 - s * 0.62f, y2 - s * 0.44f, x2 + s * 0.62f, y2 + s * 0.44f);
            c.drawOval(rect, note);
            c.restore();
            c.drawLine(sx2, y2 - s * 0.15f, sx2, top2, stem);
            stem.setStrokeWidth(s * 0.5f);
            c.drawLine(sx, top, sx2, top2, stem);
        }
    }

    private void drawBokeh(Canvas c, float bm, int w, int h) {
        for (int i = 0; i < BOKEH; i++) {
            float x = bkX[i] * w + (float) Math.sin(time * 0.10f + bkPh[i]) * w * 0.02f;
            float y = bkY[i] * h + (float) Math.cos(time * 0.08f + bkPh[i]) * h * 0.015f;
            float a = (0.30f + 0.22f * (float) Math.sin(time * 0.30f + bkPh[i])) * bm * Math.min(1f, level * 1.5f + 0.15f);
            bokehP[i].setAlpha(Math.max(0, Math.min(255, (int) (255 * a))));
            c.save(); c.translate(x, y);
            c.drawCircle(0f, 0f, Math.max(4f, bkR[i] * h), bokehP[i]);
            c.restore();
        }
    }

    /** الساعة واسم المحطة: تنجرفان ببطء شديد (خصوصًا في الشاشة السوداء) لتفادي حرق الشاشة. */
    private void drawTexts(Canvas c, int w, int h, float bm) {
        long now = System.currentTimeMillis();
        if (now - lastClockMs > 1000 || clockStr.isEmpty()) {
            lastClockMs = now;
            try { clockStr = android.text.format.DateFormat.getTimeFormat(getContext()).format(new Date(now)); }
            catch (Exception e) { clockStr = ""; }
        }
        boolean black = style == STYLE_BLACK;
        float dx = (black ? w * 0.22f : w * 0.012f) * (float) Math.sin(time * 0.021f);
        float dy = (black ? h * 0.20f : h * 0.006f) * (float) Math.sin(time * 0.017f + 1f);
        int tint = colorAt(0.25f) & 0x00FFFFFF;
        if (black) {
            textP.setColor(tint | 0xFF000000);
            textP.setTextSize(h * 0.12f); textP.setAlpha((int) (210 * bm));
            c.drawText(clockStr, w / 2f + dx, h / 2f + dy, textP);
            textP.setTextSize(h * 0.034f); textP.setAlpha((int) (150 * bm));
            c.drawText(label, w / 2f + dx, h / 2f + dy + h * 0.07f, textP);
        } else {
            textP.setColor(tint | 0xFF000000);
            textP.setTextSize(h * 0.05f); textP.setAlpha((int) (130 * bm));
            c.drawText(clockStr, w / 2f + dx, h * 0.10f + dy, textP);
            textP.setTextSize(h * 0.03f); textP.setAlpha((int) (160 * bm));
            c.drawText(label, w / 2f + dx, h * 0.94f + dy, textP);
        }
    }
}
