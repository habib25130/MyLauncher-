package com.myfamily.launcher;

import java.util.Locale;

/** محطة إذاعية واحدة (من Radio Browser أو من القائمة الاحتياطية المدمجة). */
final class RadioStation {
    final String id;        // stationuuid (أو معرّف ثابت للمدمجة)
    final String name;
    final String url;       // url_resolved الصالح للتشغيل المباشر
    final String country;   // اسم الدولة (قد يكون فارغاً)
    final String code;      // رمز الدولة DZ / EG ...
    final String codec;     // MP3 / AAC ...
    final int bitrate;      // kbps (0 = غير معروف)
    final boolean builtIn;

    RadioStation(String id, String name, String url, String country, String code,
                 String codec, int bitrate, boolean builtIn) {
        this.id = id == null ? "" : id;
        this.name = name == null ? "" : name.trim();
        this.url = url == null ? "" : url.trim();
        this.country = country == null ? "" : country.trim();
        this.code = code == null ? "" : code.trim().toUpperCase(Locale.ROOT);
        this.codec = codec == null ? "" : codec.trim().toUpperCase(Locale.ROOT);
        this.bitrate = Math.max(0, bitrate);
        this.builtIn = builtIn;
    }

    /** سطر وصفي: «الجزائر · MP3 · 64k» */
    String meta() {
        StringBuilder b = new StringBuilder();
        String place = !country.isEmpty() ? country : code;
        if (!place.isEmpty()) b.append(place);
        if (!codec.isEmpty()) { if (b.length() > 0) b.append(" · "); b.append(codec); }
        if (bitrate > 0) { if (b.length() > 0) b.append(" · "); b.append(bitrate).append('k'); }
        return b.toString();
    }

    boolean sameAs(RadioStation o) {
        if (o == null) return false;
        if (!id.isEmpty() && id.equals(o.id)) return true;     // نفس المحطة حتى لو تغيّر الرابط بعد الاستبدال
        return url.equalsIgnoreCase(o.url);
    }

    /** هل الرابط http أو https فعلاً؟ */
    boolean hasPlayableUrl() {
        String u = url.toLowerCase(Locale.ROOT);
        return u.startsWith("http://") || u.startsWith("https://");
    }
}
