package com.myfamily.launcher;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * جلب المحطات من Radio Browser + قائمة احتياطية مدمجة.
 * - لا يشغّل أي صوت إطلاقاً (جلب بيانات فقط).
 * - يُبقي المحطات الفعالة فقط: lastcheckok == 1 و url_resolved غير فارغ وبروتوكول http/https.
 * - كل الاستدعاءات تعيد النتيجة على الخيط الرئيسي.
 */
final class RadioRepository {
    private static final String[] API_HOSTS = {
        "https://de1.api.radio-browser.info/json/",
        "https://all.api.radio-browser.info/json/",
        "https://nl1.api.radio-browser.info/json/",
        "https://at1.api.radio-browser.info/json/"
    };
    private static final String UA = "MyLauncher/1.0 (Android TV launcher)";
    private static final long TTL_MS = 10 * 60 * 1000L;

    interface Callback { void onResult(List<RadioStation> stations, boolean fromNetwork); }

    // ===================== القائمة الاحتياطية المدمجة =====================
    private static final RadioStation[] BUILTIN = {
        new RadioStation("b-dz-quran", "إذاعة القرآن الكريم – الجزائر", "https://coran.ice.infomaniak.ch/coran-64.mp3", "الجزائر", "DZ", "MP3", 64, true),
        new RadioStation("b-dz-bahdja", "إذاعة البهجة – الجزائر", "https://webradio3.tda.dz:8001/ElBahdja_64K.mp3", "الجزائر", "DZ", "MP3", 64, true),
        new RadioStation("b-dz-ch1", "الإذاعة الجزائرية – القناة الأولى", "https://chaine1.ice.infomaniak.ch/chaine1-64.mp3", "الجزائر", "DZ", "MP3", 64, true),
        new RadioStation("b-dz-ch2", "الإذاعة الجزائرية – القناة الثانية (أمازيغية)", "https://chaine2.ice.infomaniak.ch/chaine2-64.mp3", "الجزائر", "DZ", "MP3", 64, true),
        new RadioStation("b-dz-ch3", "الإذاعة الجزائرية – القناة الثالثة (فرنسية)", "https://chaine3.ice.infomaniak.ch/chaine3-64.mp3", "الجزائر", "DZ", "MP3", 64, true),
        new RadioStation("b-dz-jil", "إذاعة جيل اف ام – الجزائر", "https://jilfm.ice.infomaniak.ch/jilfm-64.mp3", "الجزائر", "DZ", "MP3", 64, true),
    };

    // ===================== طبقة مساعدة: الإذاعة الجزائرية =====================
    // تُستعمل فقط بعد ضغط المستخدم على محطة مدمجة فشل رابطها المباشر (لا تعمل عند الفتح أو تحميل القائمة).
    // 1) Radio Browser بحثاً بالاسم (روابط مفحوصة)  2) صفحة المشغّل https://my.radioalgerie.dz/player/<slug>.html
    static final String PORTAL_BASE = "https://my.radioalgerie.dz/player/";
    private static final Map<String, String[]> ALT_QUERY = new HashMap<>();   // id المدمجة -> كلمات بحث لاتينية
    private static final Map<String, String> PORTAL_SLUG = new HashMap<>();   // id المدمجة -> اسم ملف المشغّل
    static {
        ALT_QUERY.put("b-dz-bahdja", new String[]{"bahdja", "bahja"});
        ALT_QUERY.put("b-dz-quran", new String[]{"coran", "quran"});
        ALT_QUERY.put("b-dz-ch1", new String[]{"chaine 1", "chaine1"});
        PORTAL_SLUG.put("b-dz-bahdja", "bahdja");
        PORTAL_SLUG.put("b-dz-quran", "coran");
        PORTAL_SLUG.put("b-dz-ch1", "chaine1");
    }
    // استخراج رابط بث من نص صفحة المشغّل (audio/source/JS): aac|mp3|m3u8 أو مضيف icecast/tda.dz/quran-uni/qurango
    private static final Pattern STREAM_RE = Pattern.compile(
        "https?://[^\\s\"'<>\\\\)]+?\\.(?:aac|mp3|m3u8)(?:\\?[^\\s\"'<>\\\\)]*)?|https?://[^\\s\"'<>\\\\)]*(?:ice\\.infomaniak|icecast|stream\\.radioalgerie|tda\\.dz|quran-uni|qurango)[^\\s\"'<>\\\\)]*",
        Pattern.CASE_INSENSITIVE);

    interface UrlCallback { void onUrl(String urlOrNull); }

    /** يبحث عن رابط بديل لمحطة مدمجة. النتيجة على الخيط الرئيسي؛ null إن لم يوجد. */
    static void resolveAlternative(final RadioStation s, final UrlCallback cb) {
        IO.execute(() -> {
            String found = null;
            if (found == null) try { found = viaPortal(s); } catch (Exception ignored) { }
            if (found == null) try { found = viaApi(s); } catch (Exception ignored) { }
            final String f = found;
            MAIN.post(() -> cb.onUrl(f));
        });
    }

    private static String viaApi(RadioStation s) throws Exception {
        String[] qs = ALT_QUERY.get(s.id);
        if (qs == null) return null;
        for (String q : qs) {
            String cc = "DZ".equalsIgnoreCase(s.code) ? "&countrycode=DZ" : "";
            for (RadioStation c : fetch("stations/search?name=" + enc(q)
                    + cc + "&hidebroken=true&order=clickcount&reverse=true&limit=20")) {
                if (!c.url.equalsIgnoreCase(s.url)) return c.url;     // fetch() أبقى lastcheckok==1 فقط
            }
        }
        return null;
    }

    private static String viaPortal(RadioStation s) throws Exception {
        String slug = PORTAL_SLUG.get(s.id);
        if (slug == null) return null;
        HttpURLConnection c = (HttpURLConnection) new URL(PORTAL_BASE + slug + ".html").openConnection();
        c.setConnectTimeout(6000); c.setReadTimeout(8000);
        c.setRequestProperty("User-Agent", UA);
        try {
            if (c.getResponseCode() != 200) return null;
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                char[] buf = new char[8192]; int n;
                while ((n = r.read(buf)) > 0 && sb.length() < 600_000) sb.append(buf, 0, n);
            }
            Matcher m = STREAM_RE.matcher(sb.toString().replace("\\/", "/"));
            while (m.find()) {
                String u = m.group().trim();
                String l = u.toLowerCase(Locale.ROOT);
                if (l.endsWith(".js") || l.endsWith(".css") || l.endsWith(".html")) continue;
                if (!u.equalsIgnoreCase(s.url)) return u;
            }
            return null;
        } finally { c.disconnect(); }
    }

    /** تسخين DNS فقط (بلا أي صوت) لتسريع أول اتصال بالبث. */
    static void warmUp() {
        IO.execute(() -> {
            for (String h : new String[]{"webradio3.tda.dz", "my.radioalgerie.dz"})
                try { java.net.InetAddress.getByName(h); } catch (Exception ignored) { }
        });
    }

    private static final ExecutorService IO = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static final class Entry { List<RadioStation> list; long at; }
    private static final Entry CACHE = new Entry();

    private RadioRepository() { }

    /** المحطات الجزائرية المدمجة (فوري، بلا شبكة). */
    static List<RadioStation> builtIn() {
        return new ArrayList<>(Arrays.asList(BUILTIN));
    }

    /** الإذاعات الجزائرية فقط: bycountrycodeexact/DZ مع lastcheckok == 1 و url_resolved غير فارغ. */
    static void load(final boolean force, final Callback cb) {
        final Entry e = CACHE;
        if (!force && e.list != null && System.currentTimeMillis() - e.at < TTL_MS) {
            cb.onResult(new ArrayList<>(e.list), true);
            return;
        }
        IO.execute(() -> {
            List<RadioStation> net = null;
            try {
                net = onlyDZ(fetch("stations/bycountrycodeexact/DZ?hidebroken=true&order=clickcount&reverse=true"));
            } catch (Exception ignored) { }
            final List<RadioStation> merged = merge(builtIn(), net);
            final boolean ok = net != null && !net.isEmpty();
            if (ok) { e.list = new ArrayList<>(merged); e.at = System.currentTimeMillis(); }
            MAIN.post(() -> cb.onResult(merged, ok));
        });
    }

    /** بحث بالاسم داخل الإذاعات الجزائرية فقط (يُستدعى بعد تأخير قصير من الكتابة). */
    static void search(final String query, final Callback cb) {
        IO.execute(() -> {
            List<RadioStation> net = null;
            try {
                net = onlyDZ(fetch("stations/search?name=" + enc(query)
                        + "&countrycode=DZ&hidebroken=true&order=clickcount&reverse=true&limit=80"));
            } catch (Exception ignored) { }
            final List<RadioStation> res = net == null ? new ArrayList<RadioStation>() : dedupe(net);
            final boolean ok = net != null;
            MAIN.post(() -> cb.onResult(res, ok));
        });
    }

    /** حماية إضافية: لا يمرّ إلا ما رمزه DZ. */
    private static List<RadioStation> onlyDZ(List<RadioStation> in) {
        List<RadioStation> out = new ArrayList<>(in.size());
        for (RadioStation s : in) if ("DZ".equals(s.code)) out.add(s);
        return out;
    }

    /** تصفية محلية فورية بالاسم/الدولة. */
    static List<RadioStation> filterLocal(List<RadioStation> src, String query) {
        String q = norm(query);
        if (q.isEmpty()) return new ArrayList<>(src);
        List<RadioStation> out = new ArrayList<>();
        for (RadioStation s : src)
            if (norm(s.name).contains(q) || norm(s.country).contains(q)) out.add(s);
        return out;
    }

    /** دمج: المدمجة أولاً ثم نتائج الشبكة، بلا تكرار للرابط. */
    static List<RadioStation> merge(List<RadioStation> first, List<RadioStation> second) {
        List<RadioStation> all = new ArrayList<>(first);
        if (second != null) all.addAll(second);
        return dedupe(all);
    }

    private static List<RadioStation> dedupe(List<RadioStation> in) {
        Set<String> seen = new HashSet<>();
        List<RadioStation> out = new ArrayList<>();
        for (RadioStation s : in) {
            if (seen.add(s.url.toLowerCase(Locale.ROOT))) out.add(s);
        }
        return out;
    }

    // ===================== الشبكة =====================
    private static List<RadioStation> fetch(String path) throws Exception {
        Exception lastErr = null;
        for (String host : API_HOSTS) {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(host + path).openConnection();
                c.setConnectTimeout(5000);
                c.setReadTimeout(7000);
                c.setRequestProperty("User-Agent", UA);
                c.setRequestProperty("Accept", "application/json");
                if (c.getResponseCode() != 200) throw new java.io.IOException("HTTP " + c.getResponseCode());
                InputStream in = c.getInputStream();
                StringBuilder sb = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
                    char[] buf = new char[8192]; int n;
                    while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
                }
                return parse(sb.toString());
            } catch (Exception e) {
                lastErr = e;
            } finally {
                if (c != null) try { c.disconnect(); } catch (Exception ignored) { }
            }
        }
        if (lastErr != null) throw lastErr;
        return new ArrayList<>();
    }

    /** يُبقي فقط: lastcheckok == 1 و url_resolved غير فارغ وبروتوكول http/https. */
    static List<RadioStation> parse(String json) throws Exception {
        JSONArray a = new JSONArray(json);
        List<RadioStation> out = new ArrayList<>(a.length());
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            if (o.optInt("lastcheckok", 0) != 1) continue;
            String url = o.optString("url_resolved", "").trim();
            if (url.isEmpty()) continue;
            String name = o.optString("name", "").trim();
            if (name.isEmpty()) continue;
            RadioStation s = new RadioStation(o.optString("stationuuid", ""), name, url,
                    o.optString("country", ""), o.optString("countrycode", ""),
                    o.optString("codec", ""), o.optInt("bitrate", 0), false);
            if (s.hasPlayableUrl()) out.add(s);
        }
        return out;
    }

    private static String enc(String s) throws Exception { return URLEncoder.encode(s, "UTF-8"); }

    /** توحيد للبحث: أحرف صغيرة + إزالة التشكيل وتوحيد الألف والياء والتاء المربوطة. */
    private static String norm(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '\u064B' && c <= '\u065F') continue;       // التشكيل
            if (c == '\u0640') continue;                        // التطويل
            if (c == '\u0623' || c == '\u0625' || c == '\u0622') c = '\u0627';
            else if (c == '\u0649') c = '\u064A';
            else if (c == '\u0629') c = '\u0647';
            b.append(Character.toLowerCase(c));
        }
        return b.toString().trim();
    }
}
