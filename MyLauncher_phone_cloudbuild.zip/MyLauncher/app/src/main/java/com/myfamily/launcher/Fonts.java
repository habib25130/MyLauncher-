package com.myfamily.launcher;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;

/** خط Outfit (ترخيص OFL). ملف متغيّر الوزن: نحدد الوزن صراحةً وإلا يظهر رفيعًا جدًا. */
final class Fonts {
    private static Typeface regular, bold;

    static Typeface outfit(Context c) { if (regular == null) regular = make(c, 400); return regular; }
    static Typeface bold(Context c) { if (bold == null) bold = make(c, 700); return bold; }

    private static Typeface make(Context c, int weight) {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                Typeface t = new Typeface.Builder(c.getAssets(), "fonts/outfit.ttf")
                        .setFontVariationSettings("'wght' " + weight).build();
                if (t != null) return t;
            }
            Typeface t = Typeface.createFromAsset(c.getAssets(), "fonts/outfit.ttf");
            return weight >= 600 ? Typeface.create(t, Typeface.BOLD) : t;
        } catch (Exception e) {
            return weight >= 600 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT;
        }
    }
}
