package com.myfamily.launcher;

import android.content.*;
import android.os.*;
import android.graphics.BitmapFactory;
import android.widget.ImageView;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.*;

/** جلب المباريات من API-Football مع تخزين مؤقت وسقف يومي للطلبات. */
public class Football {
    public static class M {
        int id, leagueId, homeId, awayId, hg = -1, ag = -1, el = -1;
        String league = "", home = "", away = "", st = "NS", leagueLogo = "", homeLogo = "", awayLogo = "";
        /** league.round من API (للنهائي/الإقصائي). */
        String round = "";
        /** حالة الخوارزمية الذكية (UPCOMING/COUNTDOWN/LIVE/AWAITING_UPDATE/...). مؤقتة: لا تُحفظ. */
        String smart = "";
        long ts;

        JSONObject toJson() throws JSONException {
            return new JSONObject().put("id", id).put("lg", leagueId).put("hi", homeId).put("ai", awayId)
                    .put("hg", hg).put("ag", ag).put("el", el).put("ln", league).put("h", home).put("a", away)
                    .put("st", st).put("ts", ts).put("ll", leagueLogo).put("hl", homeLogo).put("al", awayLogo).put("rd", round);
        }
        static M from(JSONObject o) {
            M m = new M();
            m.id = o.optInt("id"); m.leagueId = o.optInt("lg"); m.homeId = o.optInt("hi"); m.awayId = o.optInt("ai");
            m.hg = o.optInt("hg", -1); m.ag = o.optInt("ag", -1); m.el = o.optInt("el", -1);
            m.league = o.optString("ln"); m.home = o.optString("h"); m.away = o.optString("a");
            m.st = o.optString("st", "NS"); m.ts = o.optLong("ts");
            m.leagueLogo = o.optString("ll", ""); m.homeLogo = o.optString("hl", ""); m.awayLogo = o.optString("al", "");
            m.round = o.optString("rd", "");
            return m;
        }
    }

    private static final Handler UI = new Handler(Looper.getMainLooper());
    private static boolean busy = false;
    private static final Set<String> DETAIL_BUSY = Collections.synchronizedSet(new HashSet<>());
    private static final Set<String> LOGO_BUSY = Collections.synchronizedSet(new HashSet<>());
    private static final int CORE_DAILY = 70;
    private static long lastRequestElapsed = 0;

    interface DetailCallback { void done(String json, String error); }

    static SharedPreferences p(Context c) { return c.getSharedPreferences("launcher", Context.MODE_PRIVATE); }

    static boolean live(String s) { return s.equals("1H") || s.equals("2H") || s.equals("HT") || s.equals("ET") || s.equals("BT") || s.equals("P") || s.equals("LIVE") || s.equals("INT"); }
    static boolean done(String s) { return s.equals("FT") || s.equals("AET") || s.equals("PEN"); }

    private static String fmt(long epochSec, String pattern) {
        SimpleDateFormat f = new SimpleDateFormat(pattern, Locale.US);
        f.setTimeZone(TimeZone.getTimeZone(FootballConfig.TZ));
        return f.format(new Date(epochSec * 1000L));
    }
    static String day(int offset) {
        return fmt(System.currentTimeMillis() / 1000L + offset * 86400L, "yyyy-MM-dd");
    }
    static String time(M m) { return fmt(m.ts, "HH:mm"); }

    /** السطر الصغير تحت العنوان، مثل: الاثنين 2 نوفمبر · 00:30 · PREMIER LEAGUE */
    static String subline(Context c, M m) {
        String sm = smartLabel(c, m);
        if (sm != null) return sm + (m.smart.equals("SUSPENDED") ? "" : " · " + time(m)) + " · " + m.league;
        if (live(m.st)) return liveLabel(c, m) + " · " + m.league;
        if (done(m.st)) return c.getString(R.string.st_finished) + " · " + m.league;
        if (m.st.equals("PST")) return c.getString(R.string.st_postponed) + " · " + m.league;
        String d = fmt(m.ts, "yyyy-MM-dd");
        String lbl;
        if (d.equals(day(0))) lbl = c.getString(R.string.today);
        else if (d.equals(day(1))) lbl = c.getString(R.string.tomorrow);
        else {
            SimpleDateFormat sf = new SimpleDateFormat("EEEE d MMM", Locale.getDefault());
            sf.setTimeZone(TimeZone.getTimeZone(FootballConfig.TZ));
            lbl = sf.format(new Date(m.ts * 1000L));
        }
        return lbl + " · " + time(m) + " · " + m.league;
    }

    /** نص الحالات التي تحددها الخوارزمية بالوقت: العدّ التنازلي، بانتظار التحديث، متوقفة. غير ذلك: null. */
    private static String smartLabel(Context c, M m) {
        switch (m.smart) {
            case "COUNTDOWN": {
                long mins = Math.max(0L, (m.ts * 1000L - System.currentTimeMillis()) / 60000L);
                return c.getString(R.string.st_starts_in, (int) (mins / 60), (int) (mins % 60));
            }
            case "AWAITING_UPDATE": return c.getString(R.string.st_awaiting);
            case "SUSPENDED": return c.getString(R.string.st_suspended);
            default: return null;
        }
    }

    private static String liveLabel(Context c, M m) {
        return m.st.equals("HT") ? c.getString(R.string.st_halftime)
                : c.getString(R.string.st_live) + (m.el >= 0 ? " · " + m.el + "'" : "");
    }

    // ---------- القراءة من الذاكرة المؤقتة ----------
    private static List<M> read(Context c, String key) {
        List<M> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p(c).getString(key, "[]"));
            for (int i = 0; i < a.length(); i++) l.add(M.from(a.getJSONObject(i)));
        } catch (Exception ignored) { }
        return l;
    }

    private static String toJsonArray(List<M> l) throws JSONException {
        JSONArray a = new JSONArray();
        for (M m : l) a.put(m.toJson());
        return a.toString();
    }

    /** قائمة اللوحة: ما جُلب لليوم (أو للغد إن خلا اليوم)، مع مباراة الأمس المباشرة التي عبرت منتصف الليل. */
    static List<M> cached(Context c) {
        List<M> l = read(c, "fb_cache");
        Set<Integer> ids = new HashSet<>();
        for (M m : l) ids.add(m.id);
        for (M m : read(c, "fb_cache_prev")) if (live(m.st) && ids.add(m.id)) l.add(m);
        Collections.sort(l, (x, y) -> {
            int gx = live(x.st) ? 0 : done(x.st) ? 2 : 1, gy = live(y.st) ? 0 : done(y.st) ? 2 : 1;
            if (gx != gy) return gx - gy;
            return gx == 2 ? Long.compare(y.ts, x.ts) : Long.compare(x.ts, y.ts);
        });
        return l;
    }

    /** كل ما هو مخزَّن (اليوم + الغد + مباريات الأمس المباشرة) بلا تكرار — مدخل الخوارزمية. */
    static List<M> cachedAll(Context c) {
        Map<Integer, M> byId = new LinkedHashMap<>();
        for (String key : new String[]{"fb_cache", "fb_cache_tmr", "fb_cache_prev"})
            for (M m : read(c, key)) if (!byId.containsKey(m.id)) byId.put(m.id, m);
        return new ArrayList<>(byId.values());
    }

    private static boolean open(M m) {
        return !done(m.st) && !m.st.equals("PST") && !m.st.equals("CANC") && !m.st.equals("ABD")
                && !m.st.equals("AWD") && !m.st.equals("WO");
    }

    /**
     * للبطاقة: أهم 3 مباريات بحسب SmartMatchAlgorithm (الفئات A/B/C، الفاصل 4 ساعات، المباشرة، اليوم ثم الغد).
     * ما لا يحقق شروط الخوارزمية لا يظهر هنا، حتى لو أعاده الـ API.
     */
    static synchronized List<M> featured(Context c) {
        long now = System.currentTimeMillis();
        // الاختيار يعتمد على الوقت بالدقيقة وعلى آخر تحديث للبيانات فقط: لا نعيد الحساب كل 20 ثانية
        String key = p(c).getLong("fb_time", 0) + "|" + (now / 60000L);
        if (!key.equals(featKey)) { featVal = SmartMatchBridge.select(cachedAll(c), now); featKey = key; }
        return featVal;
    }
    private static String featKey = "";
    private static List<M> featVal = new ArrayList<>();

    static String statusText(Context c, M m) {
        String sm = smartLabel(c, m);
        if (sm != null) return sm;
        if (live(m.st)) return liveLabel(c, m);
        if (m.st.equals("PEN")) return c.getString(R.string.st_finished_pens);
        if (done(m.st)) return c.getString(R.string.st_finished);
        if (m.st.equals("PST")) return c.getString(R.string.st_postponed);
        if (m.st.equals("CANC")) return c.getString(R.string.st_cancelled);
        if (m.st.equals("SUSP") || m.st.equals("ABD")) return c.getString(R.string.st_suspended);
        String d = fmt(m.ts, "yyyy-MM-dd");
        String lbl = d.equals(day(0)) ? c.getString(R.string.today) : d.equals(day(1)) ? c.getString(R.string.tomorrow) : fmt(m.ts, "dd/MM");
        return time(m) + " · " + lbl;
    }

    static String shortStatus(M m) {
        if (live(m.st)) return m.st.equals("HT") ? "HT" : (m.el >= 0 ? m.el + "'" : "LIVE");
        if (done(m.st)) return "FT";
        if (m.st.equals("PST") || m.st.equals("CANC") || m.st.equals("SUSP") || m.st.equals("ABD")) return m.st;
        return time(m);
    }

    // ---------- الجلب ----------
    static void refresh(Context c, boolean force, Runnable done) {
        final Context app = c.getApplicationContext();
        final SharedPreferences s = p(app);
        if (!hasKey(app)) { if (done != null) UI.post(done); return; }
        boolean anyLive = false;
        for (M m : cached(app)) if (live(m.st)) anyLive = true;
        long every = anyLive ? 300000L : 1800000L;
        long now = System.currentTimeMillis();
        boolean logoUpgrade = !s.getBoolean("fb_logo_data_migrated", false) && !cached(app).isEmpty();
        if (!force && logoUpgrade && now - s.getLong("fb_logo_upgrade_attempt", 0) < every) return;
        if (!force && !logoUpgrade && now - s.getLong("fb_time", 0) < every) return;
        if (s.getInt("fb_cnt_" + quotaDay(), 0) >= CORE_DAILY || busy) return;
        if (logoUpgrade) s.edit().putLong("fb_logo_upgrade_attempt", now).apply();
        busy = true;
        new Thread(() -> {
            try {
                long nowMs = System.currentTimeMillis();
                List<M> old = cachedAll(app);
                int off = 0;
                List<M> l = fetchDay(app, 0);
                // مباراة الأمس التي ما زالت مباشرة بعد منتصف الليل (حد 8 ساعات): تحتاج طلبًا واحدًا فقط عند الحاجة
                List<M> prev = needsPrevDay(old, nowMs) && quotaOk(s) ? fetchPrevDay(app, nowMs) : new ArrayList<>();
                List<M> today = new ArrayList<>(l); today.addAll(prev);
                boolean needTomorrow = SmartMatchBridge.selectToday(today, nowMs).isEmpty();
                if (needTomorrow && quotaOk(s)) {
                    if (l.isEmpty()) { l = fetchDay(app, 1); off = 1; }            // اليوم خالٍ تمامًا: نعرض الغد
                    else storeTomorrow(app, s, nowMs);                              // قاعدة 6: لا مناسب اليوم → الغد
                } else if (!needTomorrow) {
                    s.edit().remove("fb_cache_tmr").remove("fb_tmr_day").remove("fb_tmr_time").apply();
                }
                s.edit().putString("fb_cache", toJsonArray(l)).putString("fb_cache_prev", toJsonArray(prev))
                        .putInt("fb_off", off).putString("fb_err", "")
                        .putBoolean("fb_logo_data_migrated", true).apply();
            } catch (Exception e) {
                s.edit().putString("fb_err", String.valueOf(e.getMessage())).apply();
            }
            s.edit().putLong("fb_time", System.currentTimeMillis()).apply();
            busy = false;
            if (done != null) UI.post(done);
        }).start();
    }

    private static List<M> fetchDay(Context c, int off) throws Exception {
        JSONObject o = request(c, "/fixtures?date=" + day(off) + "&timezone=" + URLEncoder.encode(FootballConfig.TZ, "UTF-8"));
        JSONArray r = o.getJSONArray("response");
        List<M> out = new ArrayList<>();
        for (int i = 0; i < r.length(); i++) {
            JSONObject f = r.getJSONObject(i), fx = f.getJSONObject("fixture"), lg = f.getJSONObject("league");
            JSONObject home = f.getJSONObject("teams").getJSONObject("home"), away = f.getJSONObject("teams").getJSONObject("away");
            JSONObject gl = f.getJSONObject("goals"), stt = fx.getJSONObject("status");
            M m = new M();
            m.id = fx.getInt("id"); m.ts = fx.getLong("timestamp");
            m.st = stt.optString("short", "NS"); m.el = stt.isNull("elapsed") ? -1 : stt.optInt("elapsed", -1);
            m.leagueId = lg.getInt("id"); m.league = lg.optString("name"); m.round = lg.optString("round", "");
            m.leagueLogo = lg.optString("logo", "");
            m.homeId = home.optInt("id"); m.home = home.optString("name");
            m.homeLogo = home.optString("logo", "");
            m.awayId = away.optInt("id"); m.away = away.optString("name");
            m.awayLogo = away.optString("logo", "");
            m.hg = gl.isNull("home") ? -1 : gl.optInt("home", -1);
            m.ag = gl.isNull("away") ? -1 : gl.optInt("away", -1);
            if (wanted(m)) out.add(m);
        }
        return out;
    }

    /** نحتفظ بدوريات الإعدادات، والفرق المتابَعة، وأي مباراة تؤهلها الخوارزمية (مثل كلاسيكو في كأس الملك). */
    private static boolean wanted(M m) {
        for (int l : FootballConfig.LEAGUES) if (l == m.leagueId) return true;
        for (int t : FootballConfig.TEAMS) if (t == m.homeId || t == m.awayId) return true;
        return SmartMatchBridge.isSmartCandidate(m);
    }

    private static boolean quotaOk(SharedPreferences s) {
        return s.getInt("fb_cnt_" + quotaDay(), 0) < CORE_DAILY;
    }

    private static final long TOMORROW_TTL_MS = 3 * 60 * 60 * 1000L;   // قائمة الغد قلّما تتغير: نجدّدها كل 3 ساعات

    /** يجلب الغد في ذاكرة منفصلة (لا يختلط بقائمة اليوم في اللوحة). يعيد استعمال النسخة إن كانت حديثة. */
    private static void storeTomorrow(Context c, SharedPreferences s, long nowMs) {
        String want = day(1);
        if (want.equals(s.getString("fb_tmr_day", "")) && nowMs - s.getLong("fb_tmr_time", 0) < TOMORROW_TTL_MS) return;
        try {
            s.edit().putString("fb_cache_tmr", toJsonArray(fetchDay(c, 1))).putString("fb_tmr_day", want)
                    .putLong("fb_tmr_time", nowMs).apply();
        } catch (Exception ignored) { /* فشل الغد لا يُسقط تحديث اليوم */ }
    }

    /** هل في المخزَّن مباراة من تاريخ سابق لا تزال ضمن نافذة الـ8 ساعات ولم تنتهِ؟ */
    private static boolean needsPrevDay(List<M> old, long nowMs) {
        String today = day(0);
        for (M m : old) {
            long start = m.ts * 1000L;
            if (start > nowMs || nowMs - start > SmartMatchBridge.MAX_LIVE_AGE_MS) continue;
            if (open(m) && !fmt(m.ts, "yyyy-MM-dd").equals(today)) return true;
        }
        return false;
    }

    private static List<M> fetchPrevDay(Context c, long nowMs) {
        List<M> out = new ArrayList<>();
        try {
            for (M m : fetchDay(c, -1)) if (nowMs - m.ts * 1000L <= SmartMatchBridge.MAX_LIVE_AGE_MS) out.add(m);
        } catch (Exception ignored) { }
        return out;
    }

    private static String quotaDay() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date());
    }

    private static synchronized void reserveRequest(Context c, boolean detail) throws IOException {
        SharedPreferences s = p(c);
        String key = "fb_cnt_" + quotaDay();
        int used = Math.max(s.getInt(key, 0), s.getInt("fb_cnt_" + day(0), 0));
        int max = detail ? FootballConfig.MAX_DAILY : CORE_DAILY;
        int serverRemaining;
        try { serverRemaining = Integer.parseInt(s.getString("fb_remaining", "-1")); }
        catch (Exception ignored) { serverRemaining = -1; }
        long elapsed = SystemClock.elapsedRealtime();
        long wait = lastRequestElapsed == 0 ? 0 : 6500L - (elapsed - lastRequestElapsed);
        if (wait > 0) {
            try { Thread.sleep(wait); }
            catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); throw new IOException("API request interrupted"); }
            elapsed = SystemClock.elapsedRealtime();
        }
        if (used >= max || used >= FootballConfig.MAX_DAILY || (serverRemaining >= 0 && serverRemaining <= 10))
            throw new IOException("Daily API request budget reached");
        lastRequestElapsed = elapsed;
        s.edit().putInt(key, used + 1).putInt("fb_cnt_" + day(0), used + 1).apply();
    }

    // ===== مفتاح API-SPORTS: ما أدخله المستخدم فقط (مشفّر). لا مفتاح مضمَّن في الكود =====
    static final String P_KEY = "fb_key_enc", P_BAD = "fb_key_bad";
    static String apiKey(Context c) {
        return SecretStore.decrypt(p(c).getString(P_KEY, "")).trim();
    }
    static boolean hasUserKey(Context c) { return !SecretStore.decrypt(p(c).getString(P_KEY, "")).trim().isEmpty(); }
    static boolean hasKey(Context c) { return !apiKey(c).isEmpty(); }
    static boolean keyRejected(Context c) { return p(c).getBoolean(P_BAD, false); }
    /** حفظ المفتاح مشفّراً؛ نص فارغ = حذف. مفتاح جديد = حصة جديدة، فنصفّر العدّاد والأخطاء القديمة. */
    static void saveKey(Context c, String key) {
        String k = key == null ? "" : key.trim();
        SharedPreferences.Editor e = p(c).edit();
        if (k.isEmpty()) e.remove(P_KEY); else e.putString(P_KEY, SecretStore.encrypt(k));
        e.remove(P_BAD).remove("fb_remaining").remove("fb_err").remove("fb_cnt_" + quotaDay()).remove("fb_cnt_" + day(0)).remove("fb_time").apply();
        if (k.isEmpty()) p(c).edit().remove("fb_cache").remove("fb_cache_tmr").remove("fb_cache_prev").remove("fb_tmr_day").remove("fb_tmr_time").remove("fb_off").apply();
    }
    static boolean validKey(String k) { return k != null && k.matches("[A-Za-z0-9]{10,80}"); }

    private static JSONObject request(Context c, String path) throws Exception { return request(c, path, false); }

    private static JSONObject request(Context c, String path, boolean detail) throws Exception {
        final String key = apiKey(c);
        if (key.isEmpty()) throw new IOException("No API key");
        reserveRequest(c, detail);
        SharedPreferences s = p(c);
        HttpURLConnection h = (HttpURLConnection) new URL("https://v3.football.api-sports.io" + path).openConnection();
        h.setRequestProperty("x-apisports-key", key);
        h.setConnectTimeout(10000); h.setReadTimeout(15000);
        InputStream in = h.getResponseCode() >= 400 ? h.getErrorStream() : h.getInputStream();
        String rem = h.getHeaderField("x-ratelimit-requests-remaining");
        if (rem != null) s.edit().putString("fb_remaining", rem).apply();
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            String line; while ((line = r.readLine()) != null) sb.append(line);
        }
        JSONObject o = new JSONObject(sb.toString());
        Object err = o.opt("errors");
        if ((err instanceof JSONObject && ((JSONObject) err).length() > 0) || (err instanceof JSONArray && ((JSONArray) err).length() > 0))
        {
            String es = err.toString().toLowerCase(Locale.US);
            if (es.contains("token") || es.contains("key") || es.contains("access")) s.edit().putBoolean(P_BAD, true).apply();
            throw new IOException(err.toString());
        }
        if (s.getBoolean(P_BAD, false)) s.edit().remove(P_BAD).apply();
        return o;
    }

    /** التشكيلة لا تتغير بعد انطلاق المباراة، فتُخزَّن 6 ساعات (طلب واحد). قبل الانطلاق تُجدَّد كل 15 دقيقة. */
    static void loadLineups(Context c, M m, DetailCallback callback) {
        boolean started = live(m.st) || done(m.st);
        long age = started ? 6 * 60 * 60 * 1000L : 15 * 60 * 1000L;
        long minTime = started ? m.ts * 1000L - 15 * 60 * 1000L : 0L;   // لا نعتمد تشكيلة جُلبت قبل الإعلان الرسمي
        loadDetail(c, m, "lineups", "/fixtures/lineups?fixture=" + m.id, age, minTime, callback);
    }

    /**
     * أحداث المباراة: الأهداف والتبديلات (والبطاقات) في طلب واحد.
     * مباشرة: تُجدَّد كل 3 دقائق عند الطلب. منتهية: تُخزَّن أسبوعًا، بشرط أن تكون جُلبت بعد نهاية المباراة.
     */
    static void loadGoalEvents(Context c, M m, DetailCallback callback) {
        boolean fin = done(m.st);
        long age = fin ? 7 * 24 * 60 * 60 * 1000L : 3 * 60 * 1000L;
        long minTime = fin ? m.ts * 1000L + 150 * 60 * 1000L : 0L;
        loadDetail(c, m, "events", "/fixtures/events?fixture=" + m.id, age, minTime, callback);
    }

    private static void loadDetail(Context c, M m, String type, String path, long maxAge, long minTime, DetailCallback callback) {
        Context app = c.getApplicationContext();
        SharedPreferences s = p(app);
        String key = "fb_" + type + "_" + m.id, timeKey = key + "_time";
        String cached = s.getString(key, "");
        long cachedAt = s.getLong(timeKey, 0), now = System.currentTimeMillis();
        if (!cached.isEmpty() && now - cachedAt < maxAge && cachedAt >= minTime) {
            if (callback != null) callback.done(cached, "");
            return;
        }
        if (!DETAIL_BUSY.add(key)) {   // طلب مماثل جارٍ: لا نترك الواجهة معلّقة
            if (callback != null) { final String old = cached.isEmpty() ? null : cached; UI.post(() -> callback.done(old, "busy")); }
            return;
        }
        new Thread(() -> {
            String result = null, error = "";
            try {
                JSONArray response = request(app, path, true).getJSONArray("response");
                result = response.toString();
                s.edit().putString(key, result).putLong(timeKey, System.currentTimeMillis()).apply();
            } catch (Exception e) {
                error = String.valueOf(e.getMessage());
                if (!cached.isEmpty()) result = cached;
            } finally { DETAIL_BUSY.remove(key); }
            final String data = result, message = error;
            if (callback != null) UI.post(() -> callback.done(data, message));
        }).start();
    }

    static void loadLogo(Context c, String url, ImageView target) {
        if (url == null || url.isEmpty()) return;
        target.setTag(url);
        File file = logoFile(c, url);
        if (file.isFile()) {
            android.graphics.Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            if (bitmap != null) { target.setImageBitmap(bitmap); return; }
        }
        if (!LOGO_BUSY.add(url)) return;
        new Thread(() -> {
            File temp = new File(file.getParentFile(), file.getName() + ".part");
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(7000); conn.setReadTimeout(10000);
                conn.setRequestProperty("User-Agent", "MyLauncher-TV");
                try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(temp)) {
                    byte[] buffer = new byte[8192]; int n; long total = 0;
                    while ((n = in.read(buffer)) != -1) {
                        total += n; if (total > 1024 * 1024) throw new IOException("Logo too large");
                        out.write(buffer, 0, n);
                    }
                }
                if (!temp.renameTo(file)) { try (InputStream in = new FileInputStream(temp); FileOutputStream out = new FileOutputStream(file)) { byte[] b = new byte[8192]; int n; while ((n = in.read(b)) != -1) out.write(b, 0, n); } temp.delete(); }
                android.graphics.Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                if (bitmap != null) UI.post(() -> { if (url.equals(target.getTag())) target.setImageBitmap(bitmap); });
            } catch (Exception ignored) { temp.delete(); }
            finally { LOGO_BUSY.remove(url); }
        }).start();
    }

    private static File logoFile(Context c, String url) {
        String hash = "logo";
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(url.getBytes("UTF-8"));
            StringBuilder b = new StringBuilder(); for (byte v : bytes) b.append(String.format(Locale.US, "%02x", v)); hash = b.toString();
        } catch (Exception ignored) { }
        File dir = new File(c.getFilesDir(), "football-logos");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, hash + ".img");
    }
}
