package com.myfamily.launcher;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.*;
import android.os.Build;
import java.util.*;

/** إعدادات الأذان والجدولة. أرقام الصلوات 0..4 = فجر، ظهر، عصر، مغرب، عشاء. */
public class Adhan {
    static final long MIN_VALID_TIME = 1735689600000L;   // 2025-01-01: أي وقت أقدم منه يعني أن الساعة غير مضبوطة
    static final int[] TIME_INDEX = {0, 2, 3, 4, 5};          // موضعها في PrayerTimes.compute
    static String[] prayers(Context c) {
        return new String[]{c.getString(R.string.fajr), c.getString(R.string.dhuhr), c.getString(R.string.asr),
                c.getString(R.string.maghrib), c.getString(R.string.isha)};
    }
    static String[] modes(Context c) {
        return new String[]{c.getString(R.string.mode_off), c.getString(R.string.mode_full), c.getString(R.string.mode_short)};
    }

    static SharedPreferences p(Context c) { return c.getSharedPreferences("launcher", Context.MODE_PRIVATE); }
    static boolean enabled(Context c) { return p(c).getBoolean("adhan_on", false); }
    static boolean auto(Context c) { return p(c).getBoolean("adhan_auto", true); }
    static int mode(Context c, int k) { return p(c).getInt("adhan_mode" + k, 0); }
    static int source(Context c) { return p(c).getInt("adhan_src", 0); }      // 0 = adhan.mp3 | 1 = نغمة المنبه
    static int volume(Context c) { return p(c).getInt("adhan_vol", 80); }

    /** يحمّل المدينة/الطريقة المحفوظة (يلزم في المستقبِلات لأن المتغيرات الثابتة تُمحى). */
    static void load(Context c) {
        SharedPreferences s = p(c);
        try {
            PrayerTimes.LAT = Double.parseDouble(s.getString("lat", "33.80"));
            PrayerTimes.LNG = Double.parseDouble(s.getString("lng", "2.88"));
            PrayerTimes.TZ = TimeZone.getTimeZone(s.getString("tz", "Africa/Algiers"));
            PrayerTimes.METHOD = s.getInt("method", 19);
            PrayerTimes.loadAdjust(s);
        } catch (Exception ignored) { }
    }

    /** t = وقت الأذان المقرَّر (ms)، x = هل المنبّه دقيق؛ يستعملهما المستقبِل ليرفض الأذان المتأخر. */
    private static PendingIntent pi(Context c, int k, long when, boolean exact) {
        Intent i = new Intent(c, AdhanReceiver.class).putExtra("k", k).putExtra("t", when).putExtra("x", exact);
        return PendingIntent.getBroadcast(c, 100 + k, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** يلغي المنبهات القديمة ويضبط منبّه الصلاة القادمة فقط (يُعاد ضبطه بعد كل أذان). */
    static void schedule(Context c) {
        load(c);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        for (int k = 0; k < 5; k++) am.cancel(pi(c, k, 0L, true));
        if (!enabled(c) || !auto(c)) return;
        long best = Long.MAX_VALUE; int bestK = -1;
        long now = System.currentTimeMillis();
        if (now < MIN_VALID_TIME) return;     // ساعة التلفاز لم تُضبط بعد (إقلاع بلا بطارية ساعة): ننتظر مزامنة الوقت ثم يُعاد الضبط
        for (int d = 0; d <= 1; d++) {
            Calendar day = Calendar.getInstance(PrayerTimes.TZ);
            day.add(Calendar.DAY_OF_MONTH, d);
            double[] t = PrayerTimes.compute(day);
            day.set(Calendar.HOUR_OF_DAY, 0); day.set(Calendar.MINUTE, 0); day.set(Calendar.SECOND, 0); day.set(Calendar.MILLISECOND, 0);
            for (int k = 0; k < 5; k++) {
                if (mode(c, k) == 0) continue;
                long ms = day.getTimeInMillis() + (long) (t[TIME_INDEX[k]] * 3600000L);
                if (ms > now + 1000 && ms < best) { best = ms; bestK = k; }
            }
        }
        if (bestK < 0) return;
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pi(c, bestK, best, true));
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pi(c, bestK, best, false));
    }

    /** تجربة: بلا رقم صلاة (يظهر الشريط كمعاينة ولا يبقى تذكير بعد الأذان). */
    static void play(Context c, int mode) { play(c, mode, -1); }
    static void play(Context c, int mode, int k) {
        Intent i = new Intent(c, AdhanService.class).putExtra("mode", mode).putExtra("k", k);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }
    static void stop(Context c) { c.stopService(new Intent(c, AdhanService.class)); }
}
