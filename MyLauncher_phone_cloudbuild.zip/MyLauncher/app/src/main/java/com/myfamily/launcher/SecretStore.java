package com.myfamily.launcher;

import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * تخزين أسرار صغيرة (مفتاح API) مشفّرة بمفتاح AES-GCM داخل Android Keystore (API 23+).
 * على API 21-22 أو إن تعطّل الـ Keystore على الجهاز يُحفظ النص بترميز Base64 فقط (إخفاء لا تشفير).
 * الصيغة المخزَّنة: "g1:<iv>:<cipher>" أو "p1:<base64>".
 */
final class SecretStore {
    private static final String ALIAS = "launcher_secret_v1";
    private static final String PROVIDER = "AndroidKeyStore";

    private SecretStore() { }

    static String encrypt(String plain) {
        if (plain == null || plain.isEmpty()) return "";
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                c.init(Cipher.ENCRYPT_MODE, key());
                byte[] ct = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
                return "g1:" + b64(c.getIV()) + ":" + b64(ct);
            } catch (Exception ignored) { /* نرجع للترميز البسيط */ }
        }
        return "p1:" + b64(plain.getBytes(StandardCharsets.UTF_8));
    }

    /** يعيد النص الأصلي أو "" إن تعذّر فكّه (مثلاً بعد مسح الـ Keystore). */
    static String decrypt(String stored) {
        if (stored == null || stored.isEmpty()) return "";
        try {
            if (stored.startsWith("p1:"))
                return new String(Base64.decode(stored.substring(3), Base64.NO_WRAP), StandardCharsets.UTF_8);
            if (stored.startsWith("g1:") && Build.VERSION.SDK_INT >= 23) {
                String[] p = stored.split(":", 3);
                Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(p[1], Base64.NO_WRAP)));
                return new String(c.doFinal(Base64.decode(p[2], Base64.NO_WRAP)), StandardCharsets.UTF_8);
            }
        } catch (Exception ignored) { }
        return "";
    }

    private static String b64(byte[] b) { return Base64.encodeToString(b, Base64.NO_WRAP); }

    @android.annotation.TargetApi(23)
    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance(PROVIDER);
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER);
            kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256).build());
            return kg.generateKey();
        }
        return (SecretKey) ks.getKey(ALIAS, null);
    }
}
