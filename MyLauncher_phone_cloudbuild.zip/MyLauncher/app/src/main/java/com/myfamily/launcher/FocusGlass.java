package com.myfamily.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewTreeObserver;

/**
 * إطار زجاجي عائم واحد (بدل زجاج منفصل داخل كل بطاقة).
 * عند تغيّر التركيز لا "يقفز" بل ينزلق من البطاقة القديمة إلى الجديدة،
 * ويلحق بالبطاقة أثناء تمرير الصفوف (فيبدو متأخراً قليلاً خلفها كما في الفيديو).
 * يرسم: هالة لامعة خارجية + لوح زجاج متدرّج + حلقة بيضاء رفيعة.
 * لا يستقبل لمساً ولا تركيزاً.
 */
public class FocusGlass extends View {
    private static final float TAU_MS = 55f;     // سرعة اللحاق: أصغر = أسرع
    private static final float FADE_MS = 140f;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final LinearGradient shader = new LinearGradient(0, 0, 0, 1,
            new int[]{0x78FFFFFF, 0x40FFFFFF, 0x1CFFFFFF}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
    private final Matrix gm = new Matrix();
    private final RectF cur = new RectF(), tgt = new RectF(), tmp = new RectF();
    private final int[] pa = new int[2], pb = new int[2];
    private final float density;

    private View target;
    private boolean wantVisible, animated = true, snapNext, running;
    private int snapFrames;
    private String caption;
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float visible;
    private long lastNs;

    private final Runnable hide = () -> { target = null; wantVisible = false; kick(); };
    private final Runnable step = this::tick;
    private final ViewTreeObserver.OnPreDrawListener pre = () -> {
        if ((target != null || visible > 0f) && !running) kick();   // تتبّع أي حركة للتخطيط (تمرير/تمديد)
        return true;
    };

    public FocusGlass(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        setClickable(false); setFocusable(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        setAlpha(0f);
        txt.setColor(Color.WHITE); txt.setTextAlign(Paint.Align.CENTER);
        txt.setTextSize(density * 13f); txt.setTypeface(Fonts.bold(c));
        txt.setShadowLayer(density * 4f, 0, density, 0xCC000000);
    }

    @Override public boolean hasOverlappingRendering() { return false; }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        getViewTreeObserver().addOnPreDrawListener(pre);
    }

    @Override protected void onDetachedFromWindow() {
        getViewTreeObserver().removeOnPreDrawListener(pre);
        removeCallbacks(hide); removeCallbacks(step);
        running = false; target = null; visible = 0f; setAlpha(0f);
        super.onDetachedFromWindow();
    }

    /** البطاقة t حصلت على التركيز: انزلق إليها. */
    public void focus(View t, boolean animate) { focus(t, animate, null); }

    /** caption: الاسم الكامل يُرسم تحت الإطار ويتحرك معه (null = بلا اسم، كالمفضلة). */
    public void focus(View t, boolean animate, String cap) {
        removeCallbacks(hide);
        caption = (cap == null) ? null
                : TextUtils.ellipsize(cap, new android.text.TextPaint(txt), Math.max(dp(80), t.getWidth() * 1.5f), TextUtils.TruncateAt.END).toString();
        animated = animate;
        if (visible < 0.02f || !animate) snapNext = true;   // الظهور الأول يكون فوق البطاقة مباشرة
        target = t; wantVisible = true;
        kick();
    }

    /** تغيّر التخطيط فجأة (طيّ فوري): الزم البطاقة بلا انزلاق لبضعة إطارات حتى يستقر التخطيط. */
    public void snapNow() { snapFrames = 3; kick(); }

    /** البطاقة t فقدت التركيز: اختفِ إلا إذا جاء تركيز جديد خلال لحظة. */
    public void release(View t) {
        if (target == t) postDelayed(hide, 50);
    }

    private void kick() {
        if (running) return;
        running = true;
        postOnAnimation(step);
    }

    private void measure(RectF out) {
        target.getLocationInWindow(pa);
        getLocationInWindow(pb);
        float l = pa[0] - pb[0], t = pa[1] - pb[1];
        out.set(l, t, l + target.getWidth() * target.getScaleX(), t + target.getHeight() * target.getScaleY());
    }

    private void tick() {
        running = false;
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 16f : Math.min(40f, (now - lastNs) / 1e6f);
        lastNs = now;

        if (target != null && !target.isAttachedToWindow()) { target = null; wantVisible = false; }

        boolean changed = false, moving = false, again = false;
        if (target != null && wantVisible) {
            measure(tgt);
            if (snapNext || !animated || snapFrames > 0) { cur.set(tgt); snapNext = false; if (snapFrames > 0) snapFrames--; changed = true; again = snapFrames > 0; }
            else {
                float k = 1f - (float) Math.exp(-dt / TAU_MS);
                float d = Math.max(Math.max(Math.abs(tgt.left - cur.left), Math.abs(tgt.right - cur.right)),
                        Math.max(Math.abs(tgt.top - cur.top), Math.abs(tgt.bottom - cur.bottom)));
                if (d > 0.4f) {
                    cur.left += (tgt.left - cur.left) * k;     cur.right += (tgt.right - cur.right) * k;
                    cur.top += (tgt.top - cur.top) * k;        cur.bottom += (tgt.bottom - cur.bottom) * k;
                    moving = true; changed = true;
                } else if (!cur.equals(tgt)) { cur.set(tgt); changed = true; }
            }
        }

        float tv = (target != null && wantVisible) ? 1f : 0f;
        boolean fading = false;
        if (visible != tv) {
            float s = dt / FADE_MS;
            visible = visible < tv ? Math.min(tv, visible + s) : Math.max(tv, visible - s);
            setAlpha(visible);
            fading = visible != tv; changed = true;
        }

        if (changed) invalidate();
        if (moving || fading || again) kick(); else lastNs = 0;
    }

    private float dp(float v) { return v * density; }

    @Override protected void onDraw(Canvas c) {
        if (visible <= 0f) return;
        float h = cur.height();
        if (cur.width() < 2f || h < 2f) return;
        float r = Math.min(dp(18), h / 3f);

        // 1) هالة لامعة: ثلاث حلقات متدرجة الشفافية حول الإطار
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(dp(2));
        for (int i = 3; i >= 1; i--) {
            float g = dp(2) * i;
            line.setColor(Color.argb(i == 1 ? 0x38 : i == 2 ? 0x1C : 0x0E, 255, 255, 255));
            tmp.set(cur.left - g, cur.top - g, cur.right + g, cur.bottom + g);
            c.drawRoundRect(tmp, r + g, r + g, line);
        }
        // 2) لوح زجاج: أفتح من الأعلى وأغمق نحو الأسفل
        gm.setScale(1f, h); gm.postTranslate(0f, cur.top);
        shader.setLocalMatrix(gm);
        fill.setShader(shader);
        c.drawRoundRect(cur, r, r, fill);
        // 3) الحلقة البيضاء الرفيعة
        line.setStrokeWidth(dp(2)); line.setColor(0xF2FFFFFF);
        tmp.set(cur); tmp.inset(dp(1), dp(1));
        c.drawRoundRect(tmp, r - dp(1), r - dp(1), line);
        // 4) الاسم الكامل تحت الإطار
        if (caption != null) c.drawText(caption, cur.centerX(), cur.bottom + dp(8) - txt.ascent(), txt);
    }
}
