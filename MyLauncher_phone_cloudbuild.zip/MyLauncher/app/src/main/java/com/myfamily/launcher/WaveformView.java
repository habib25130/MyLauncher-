package com.myfamily.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/**
 * موجات صوتية زجاجية ذهبية.
 * تتحرك بسلاسة فقط عندما setPlaying(true)؛ وعند false تهدأ تدريجياً إلى خطوط ساكنة تماماً
 * وتتوقف حلقة الرسم نهائياً (لا استهلاك للمعالج وهي ساكنة).
 *
 * ملاحظة: الحركة محاكاة جمالية (جيوب متداخلة) وليست تحليل طيف حقيقي للصوت؛
 * التحليل الحقيقي (android.media.audiofx.Visualizer) يتطلب إذن RECORD_AUDIO فتجنبناه عمداً.
 */
final class WaveformView extends View {
    static final int GOLD = 0xFFE6BE5A, GOLD_LIGHT = 0xFFFFE9A8, GOLD_DEEP = 0xFFB98A2C;

    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glass = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final float density;
    private final int bars;
    private final boolean framed;       // true: لوح زجاجي خلف الموجات | false: موجات فقط (للمؤشر الصغير)
    private final float[] phase, speed;

    private boolean playing;
    private float amp;                  // 0..1 مُنعَّمة
    private boolean running;
    private long lastNs;
    private float time;                 // ثوانٍ
    private LinearGradient barShader;

    private final Runnable step = this::tick;

    WaveformView(Context c, int bars, boolean framed) {
        super(c);
        this.density = c.getResources().getDisplayMetrics().density;
        this.bars = bars;
        this.framed = framed;
        phase = new float[bars]; speed = new float[bars];
        java.util.Random r = new java.util.Random(7);       // ثابت: نفس الشكل في كل مرة
        for (int i = 0; i < bars; i++) { phase[i] = r.nextFloat() * 6.28f; speed[i] = 2.2f + r.nextFloat() * 3.4f; }
        glass.setStyle(Paint.Style.FILL);
        rim.setStyle(Paint.Style.STROKE); rim.setStrokeWidth(density); rim.setColor(0x44FFFFFF);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    /** يتحرك فقط عندما يكون البث في حالة تشغيل فعلي. */
    void setPlaying(boolean p) {
        if (playing == p) return;
        playing = p;
        if (isAttachedToWindow()) kick();
        else if (!p) { amp = 0f; }
    }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); if (playing || amp > 0f) kick(); }

    @Override protected void onDetachedFromWindow() {
        removeCallbacks(step); running = false; lastNs = 0;
        super.onDetachedFromWindow();
    }

    @Override protected void onVisibilityChanged(View v, int vis) {
        super.onVisibilityChanged(v, vis);
        if (vis != VISIBLE) { removeCallbacks(step); running = false; lastNs = 0; }
        else if (isAttachedToWindow() && (playing || amp > 0f)) kick();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        barShader = new LinearGradient(0, 0, 0, h,
                new int[]{GOLD_LIGHT, GOLD, GOLD_DEEP}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        glass.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{0x40FFFFFF, 0x16FFFFFF}, null, Shader.TileMode.CLAMP));
    }

    private void kick() {
        if (running) return;
        running = true; lastNs = 0;
        postOnAnimation(step);
    }

    private void tick() {
        running = false;
        if (!isAttachedToWindow() || getVisibility() != VISIBLE) return;
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;

        float target = playing ? 1f : 0f;
        float k = 1f - (float) Math.exp(-dt / (playing ? 0.18f : 0.28f));   // صعود أسرع قليلاً من الهبوط
        amp += (target - amp) * k;
        if (!playing && amp < 0.01f) amp = 0f;
        time += dt;
        invalidate();

        if (playing || amp > 0f) kick();    // عند السكون التام تتوقف الحلقة نهائياً
        else lastNs = 0;
    }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float pad = framed ? density * 10f : 0f;
        if (framed) {
            float r = h / 2f;
            rect.set(0.5f, 0.5f, w - 0.5f, h - 0.5f);
            c.drawRoundRect(rect, r, r, glass);
            c.drawRoundRect(rect, r, r, rim);
        }
        float aw = w - pad * 2f, ah = h - (framed ? density * 12f : 0f);
        float gap = aw / bars * 0.42f;
        float bw = (aw - gap * (bars - 1)) / bars;
        float minH = Math.max(density * 3f, bw);            // نقطة ساكنة
        float cy = h / 2f;
        bar.setShader(barShader);
        bar.setAlpha(255);
        for (int i = 0; i < bars; i++) {
            float pos = bars == 1 ? 0.5f : i / (float) (bars - 1);
            float env = 0.45f + 0.55f * (float) Math.sin(Math.PI * pos);   // الوسط أعلى من الأطراف
            float wave = 0.5f + 0.5f * (float) Math.sin(time * speed[i] + phase[i]);
            float wave2 = 0.5f + 0.5f * (float) Math.sin(time * speed[i] * 0.53f + phase[i] * 1.7f);
            float lvl = (0.18f + 0.82f * (0.65f * wave + 0.35f * wave2)) * env * amp;
            float bh = minH + (ah - minH) * lvl;
            float x = pad + i * (bw + gap);
            rect.set(x, cy - bh / 2f, x + bw, cy + bh / 2f);
            bar.setAlpha(amp == 0f ? 110 : 255);
            c.drawRoundRect(rect, bw / 2f, bw / 2f, bar);
        }
    }
}
