package com.myfamily.launcher;

import android.app.Activity;
import android.app.Dialog;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class WallpaperStudioActivity extends Activity {
    static final int TEXT = Color.WHITE, DIM = 0xCCFFFFFF, GREY = 0xFF8E9AAB, ACCENT = 0xFF6FD8FF, GREEN = 0xFF7FE0C8;
    private String[] NAMES;
    static final String[] ICONS = {"▦", "🖼", "▶"};
    static final int[] INTERVALS = {1, 5, 10, 15, 30, 45, 60};

    private SharedPreferences p;
    private LinearLayout leftCol, right;
    private TextView status;
    private ScrollView sv;
    private int view;
    private String pendingFocus;

    @Override protected void attachBaseContext(Context base) { super.attachBaseContext(LocaleHelper.wrap(base)); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = Background.p(this);
        NAMES = new String[]{getString(R.string.mode_builtin), getString(R.string.mode_photo), getString(R.string.mode_slideshow)};
        view = Background.mode(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(40), dp(24), dp(40), dp(32));
        TextView title = text(30, TEXT, true); title.setText(R.string.wallpaper_studio);
        TextView hint = text(15, DIM, false); hint.setText(R.string.ws_hint);
        hint.setPadding(0, dp(4), 0, dp(6));
        status = text(16, GREEN, false); status.setPadding(0, 0, 0, dp(14));
        LinearLayout cols = new LinearLayout(this);
        leftCol = new LinearLayout(this); leftCol.setOrientation(LinearLayout.VERTICAL);
        right = new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL);
        right.setPadding(dp(20), dp(16), dp(20), dp(12));
        right.setBackground(box(0x33000000, 0x55FFFFFF, 1, 24));
        cols.addView(leftCol, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, -2, 1); rp.setMarginStart(dp(18));
        cols.addView(right, rp);
        page.addView(title); page.addView(hint); page.addView(status); page.addView(cols);
        sv = new ScrollView(this); sv.addView(page);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF08111F, 0xFF12384F}));
        setContentView(sv);
        pendingFocus = "m" + view;
        render();
    }

    // ---------- بناء الصفحة ----------
    private void render() {
        int mode = Background.mode(this);
        status.setText(NAMES[mode] + " · " + getString(R.string.selected));
        leftCol.removeAllViews();
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            LinearLayout card = new LinearLayout(this);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(14), dp(14), dp(14), dp(14));
            card.setFocusable(true); card.setClickable(true); card.setTag("m" + i);
            TextView ic = text(30, TEXT, false); ic.setGravity(Gravity.CENTER);
            ic.setText(ICONS[i]);
            ic.setBackground(box(0xFF1E6FB0, 0, 0, 14));
            card.addView(ic, new LinearLayout.LayoutParams(dp(80), dp(80)));
            LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setPadding(dp(16), 0, 0, 0);
            TextView n = text(20, TEXT, true); n.setText(NAMES[i]); col.addView(n);
            if (i == mode) { TextView s = text(14, GREEN, false); s.setText(R.string.selected); col.addView(s); }
            card.addView(col);
            card.setBackground(box(i == view ? 0xFF143B52 : 0xFF11213A, i == view ? 0xFF4FA8CC : 0x55FFFFFF, 2, 22));
            card.setOnFocusChangeListener((v, f) -> {
                v.setBackground(box(f || idx == view ? 0xFF143B52 : 0xFF11213A, f ? 0xFFB8EEFF : idx == view ? 0xFF4FA8CC : 0x55FFFFFF, f ? 3 : 2, 22));
                if (f && view != idx) { view = idx; renderRight(); }
            });
            card.setOnClickListener(v -> { view = idx; renderRight(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(12);
            leftCol.addView(card, lp);
        }
        renderRight();
        if (pendingFocus != null) {
            View v = sv.findViewWithTag(pendingFocus);
            if (v == null) v = sv.findViewWithTag("pick");          // الزر الذي كان مركَّزًا اختفى (مثل «استخدام المحفوظ»)
            if (v == null) v = sv.findViewWithTag("dim");
            if (v != null) v.requestFocus();
            pendingFocus = null;
        }
    }

    private void renderRight() {
        right.removeAllViews();
        int v = view, active = Background.mode(this);
        TextView t = text(24, TEXT, true); t.setText(getString(R.string.preview_fmt, NAMES[v])); right.addView(t);
        TextView s = text(14, GREEN, false); s.setText(v == active ? R.string.selected : R.string.not_selected); s.setPadding(0, dp(2), 0, dp(8));
        right.addView(s);
        right.addView(preview(v), new LinearLayout.LayoutParams(-1, dp(190)));
        if (v == 0) {
            for (int i = 0; i < Background.PRESETS.length; i++) {
                final int ii = i;
                boolean on = active == 0 && Background.preset(this) == i;
                action((on ? "◉  " : "○  ") + getResources().getStringArray(R.array.preset_names)[i], "r" + i,
                        () -> p.edit().putInt("bg_mode", 0).putInt("bg_preset", ii).apply());
            }
        } else {
            if (v != active && Background.hasSaved(this, v)) {      // يظهر فقط إن وُجد محفوظ ولم يكن مستعملاً الآن
                action(getString(R.string.use_saved), "use", () -> p.edit().putInt("bg_mode", view).apply());
                note(getString(R.string.ws_note_use));
            }
            action(getString(v == 1 ? R.string.pick_photo : R.string.pick_photos), "pick", this::pickFile);
            note(getString(v == 1 ? R.string.ws_note_pick_photo : R.string.ws_note_pick_slides));
            action(getString(R.string.upload_phone), "qr", this::showUpload);
            note(getString(v == 1 ? R.string.ws_note_qr_photo : R.string.ws_note_qr_slides));
            if (v == 2) {
                action(getString(R.string.interval_fmt, Background.intervalMin(this)), "int", () -> {
                    int cur = Background.intervalMin(this), n = 0;
                    for (int i = 0; i < INTERVALS.length; i++) if (INTERVALS[i] == cur) n = (i + 1) % INTERVALS.length;
                    p.edit().putInt("bg_interval_min", INTERVALS[n]).apply();
                });
                note(getString(R.string.ws_note_interval));
            }
        }
        TextView dim = action(dimLabel(), "dim", () -> {
            int d = p.getInt("bg_dim", 0) + 10; if (d > 80) d = 0;
            p.edit().putInt("bg_dim", d).apply();
        });
        dim.setOnKeyListener((vw, kc, ev) -> {
            if (ev.getAction() == KeyEvent.ACTION_DOWN && (kc == KeyEvent.KEYCODE_DPAD_LEFT || kc == KeyEvent.KEYCODE_DPAD_RIGHT)) {
                int d = Math.max(0, Math.min(80, p.getInt("bg_dim", 0) + (kc == KeyEvent.KEYCODE_DPAD_RIGHT ? 10 : -10)));
                p.edit().putInt("bg_dim", d).apply();
                ((TextView) vw).setText(dimLabel());
                return true;
            }
            return false;
        });
        note(getString(R.string.ws_note_dim));
        if (v != 0 && active == v) {                                 // «تعطيل» له معنى فقط إن كان هذا الوضع هو المستعمل الآن
            action(getString(R.string.disable_default), "off", () -> p.edit().putInt("bg_mode", 0).apply());
            note(getString(R.string.ws_note_off));
        }
    }

    private void note(String s) {
        TextView t = text(13, GREY, false); t.setText(s); t.setPadding(dp(6), dp(3), dp(6), dp(2));
        right.addView(t);
    }

    private String dimLabel() { return getString(R.string.dim_fmt, p.getInt("bg_dim", 0)); }

    private TextView action(String label, String tag, Runnable r) {
        TextView t = rowView(label, tag, false);
        t.setOnClickListener(v -> { r.run(); pendingFocus = tag; render(); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(8);
        right.addView(t, lp);
        return t;
    }

    private TextView rowView(String label, String tag, boolean on) {
        TextView t = text(19, TEXT, false); t.setText(label);
        t.setPadding(dp(18), dp(16), dp(18), dp(16));
        t.setFocusable(true); t.setClickable(true); t.setTag(tag);
        t.setBackground(box(on ? 0xFF143B52 : 0xFF11213A, on ? 0xFF4FA8CC : 0x55FFFFFF, on ? 2 : 1, 18));
        t.setOnFocusChangeListener((v, f) -> v.setBackground(box(f || on ? 0xFF143B52 : 0xFF11213A, f ? 0xFFB8EEFF : on ? 0xFF4FA8CC : 0x55FFFFFF, f ? 3 : on ? 2 : 1, 18)));
        return t;
    }

    private View preview(int v) {
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(box(0xFF11213A, 0, 0, 18)); iv.setClipToOutline(true);
        try {
            BitmapFactory.Options o = new BitmapFactory.Options(); o.inSampleSize = 2;
            if (v == 0) iv.setImageBitmap(BitmapFactory.decodeResource(getResources(), Background.PRESETS[Background.preset(this)], o));
            else if (v == 1 && Background.photo(this).exists()) iv.setImageBitmap(BitmapFactory.decodeFile(Background.photo(this).getPath(), o));
            else if (v == 2 && Background.slides(this).length > 0) iv.setImageBitmap(BitmapFactory.decodeFile(Background.slides(this)[0].getPath(), o));
        } catch (Throwable ignored) { }
        iv.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(190)));
        return iv;
    }

    // ---------- الاستيراد من الجهاز ----------
    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("image/*");
        if (view == 2) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(i, view); }
        catch (Exception e) { Toast.makeText(this, getString(R.string.no_picker), Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int rc, int res, Intent d) {
        super.onActivityResult(rc, res, d);
        if (res != RESULT_OK || d == null || rc < 1 || rc > 2) return;
        List<Uri> uris = new ArrayList<>();
        if (d.getClipData() != null) for (int i = 0; i < d.getClipData().getItemCount(); i++) uris.add(d.getClipData().getItemAt(i).getUri());
        else if (d.getData() != null) uris.add(d.getData());
        if (uris.isEmpty()) return;
        Toast.makeText(this, getString(R.string.saving), Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            boolean ok = false;
            if (rc == 1) ok = saveImage(uris.get(0), Background.photo(this));
            else {
                File dir = Background.slidesDir(this); dir.mkdirs();
                for (File f : Background.slides(this)) f.delete();
                int n = 0;
                for (Uri u : uris) if (saveImage(u, new File(dir, String.format("s%03d.jpg", n)))) n++;
                ok = n > 0;
            }
            final boolean fin = ok;
            runOnUiThread(() -> {
                if (fin) { p.edit().putInt("bg_mode", rc).apply(); view = rc; }
                Toast.makeText(this, getString(fin ? R.string.saved : R.string.save_failed), Toast.LENGTH_SHORT).show();
                pendingFocus = "pick"; render();
            });
        }).start();
    }

    // ---------- الرفع من الهاتف عبر QR ----------
    private synchronized boolean saveUploaded(File tmp, int target, int[] count, TextView counter) {
        boolean ok;
        if (target == 1) ok = saveImage(Uri.fromFile(tmp), Background.photo(this));
        else {
            File dir = Background.slidesDir(this); dir.mkdirs();
            int n = 0; File f;
            do { f = new File(dir, String.format("s%03d.jpg", n++)); } while (f.exists());
            ok = saveImage(Uri.fromFile(tmp), f);
        }
        if (ok) {
            p.edit().putInt("bg_mode", target).apply();
            count[0]++;
            runOnUiThread(() -> counter.setText(getString(R.string.up_received, count[0])));
        }
        return ok;
    }

    private void showUpload() {
        String ip = UploadServer.localIp();
        if (ip == null) { Toast.makeText(this, R.string.up_noip, Toast.LENGTH_LONG).show(); return; }
        final int target = view;
        final int[] count = {0};
        final TextView counter = text(20, GREEN, true);
        counter.setText(getString(R.string.up_received, 0));
        final UploadServer srv;
        try { srv = new UploadServer(new File(getCacheDir(), "up"), tmp -> saveUploaded(tmp, target, count, counter)); }
        catch (IOException e) { Toast.makeText(this, R.string.save_failed, Toast.LENGTH_SHORT).show(); return; }
        srv.start();
        String url = "http://" + ip + ":" + srv.port() + "/" + srv.code;

        boolean[][] m = QrCode.encode(url);
        int n = m.length, q = 4, sc = Math.max(4, dp(300) / (n + 2 * q));
        Bitmap bm = Bitmap.createBitmap((n + 2 * q) * sc, (n + 2 * q) * sc, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bm); cv.drawColor(Color.WHITE);
        Paint pt = new Paint(); pt.setColor(Color.BLACK);
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
            if (m[y][x]) cv.drawRect((x + q) * sc, (y + q) * sc, (x + q + 1) * sc, (y + q + 1) * sc, pt);
        ImageView iv = new ImageView(this); iv.setImageBitmap(bm);

        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(28), dp(20), dp(28), dp(20));
        box.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF08111F, 0xFF12384F}));
        TextView title = text(24, TEXT, true); title.setText(R.string.up_title); title.setGravity(Gravity.CENTER);
        TextView link = text(16, ACCENT, false); link.setText(url); link.setPadding(0, dp(10), 0, dp(4));
        TextView note = text(14, DIM, false); note.setText(R.string.up_note); note.setGravity(Gravity.CENTER);
        box.addView(title); box.addView(iv); box.addView(link); box.addView(counter); box.addView(note);
        Dialog d = new Dialog(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        d.setContentView(box);
        d.setOnDismissListener(x -> { srv.stop(); render(); });
        d.show();
    }

    private boolean saveImage(Uri u, File out) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
            int s = 1; while (o.outWidth / (s * 2) >= 1920) s *= 2;
            o = new BitmapFactory.Options(); o.inSampleSize = s;
            Bitmap bm;
            try (InputStream in = getContentResolver().openInputStream(u)) { bm = BitmapFactory.decodeStream(in, null, o); }
            if (bm == null) return false;
            if (Build.VERSION.SDK_INT >= 24) {
                try (InputStream in = getContentResolver().openInputStream(u)) {
                    int ori = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1);
                    int deg = ori == 6 ? 90 : ori == 3 ? 180 : ori == 8 ? 270 : 0;
                    if (deg != 0) { Matrix m = new Matrix(); m.postRotate(deg); bm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true); }
                } catch (Exception ignored) { }
            }
            try (FileOutputStream fo = new FileOutputStream(out)) { bm.compress(Bitmap.CompressFormat.JPEG, 90, fo); }
            return true;
        } catch (Exception e) { return false; }
    }

    // ---------- أدوات ----------
    private GradientDrawable box(int fill, int stroke, int strokeDp, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke);
        return g;
    }
    private TextView text(int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
