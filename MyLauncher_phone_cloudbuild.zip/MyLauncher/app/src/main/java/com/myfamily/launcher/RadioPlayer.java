package com.myfamily.launcher;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.List;

/**
 * مشغّل البث المباشر (HTTP/HTTPS) فوق MediaPlayer.
 *
 * قاعدة صارمة: لا يبدأ أي صوت إلا من استدعاء صريح لـ play() ينتج عن ضغطة المستخدم.
 * لا يُنشأ أي MediaPlayer قبل ذلك (لا في الإنشاء ولا عند فتح الواجهة ولا عند تحميل القائمة).
 * كل الدوال تُستدعى من الخيط الرئيسي.
 */
final class RadioPlayer {
    enum State { STOPPED, LOADING, PLAYING, ERROR }

    interface Listener { void onRadioState(State state, RadioStation station, int errorRes); }

    private static final long PREPARE_TIMEOUT_MS = 8_000L;

    private static RadioPlayer inst;
    static RadioPlayer get(Context c) {
        if (inst == null) inst = new RadioPlayer(c.getApplicationContext());
        return inst;
    }

    private final Context app;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<Listener> listeners = new ArrayList<>();
    private final AudioManager am;

    private MediaPlayer mp;
    private int gen;                       // يُبطل نداءات المشغّل القديم
    private State state = State.STOPPED;
    private RadioStation current;
    private int errorRes;
    private boolean hasFocus;
    private AudioFocusRequest focusReq;    // API 26+

    private boolean recovered;

    // مؤقت النوم: يوقف البث بعد المدة ثم يلغي نفسه. يُلغى أيضًا عند أي إيقاف.
    private long sleepEnd;
    private final Runnable sleepStop = () -> { sleepEnd = 0; stop(); };
    private final Runnable timeout = () -> onStreamError(gen, R.string.radio_err_timeout);

    private final AudioManager.OnAudioFocusChangeListener focusListener = change -> {
        switch (change) {
            case AudioManager.AUDIOFOCUS_LOSS:
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                stop();                               // بث مباشر: الإيقاف أسلم من الإيقاف المؤقت
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                if (mp != null && state == State.PLAYING) try { mp.setVolume(0.25f, 0.25f); } catch (Exception ignored) { }
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                if (mp != null) try { mp.setVolume(1f, 1f); } catch (Exception ignored) { }
                break;
            default: break;
        }
    };

    private RadioPlayer(Context app) {
        this.app = app;
        this.am = (AudioManager) app.getSystemService(Context.AUDIO_SERVICE);
    }

    // ===================== الحالة =====================
    State state() { return state; }
    RadioStation current() { return current; }
    int errorRes() { return errorRes; }
    /** true فقط أثناء التشغيل الفعلي (ليس أثناء التحميل/التخزين المؤقت). */
    boolean isPlaying() { return state == State.PLAYING; }
    /** هذه المحطة هي الحالية وهي تُحمَّل أو تُشغَّل. */
    boolean isActive(RadioStation s) {
        return s != null && current != null && current.sameAs(s) && (state == State.LOADING || state == State.PLAYING);
    }

    void addListener(Listener l) { if (!listeners.contains(l)) listeners.add(l); }
    void removeListener(Listener l) { listeners.remove(l); }

    private void setState(State s, int err) {
        state = s; errorRes = err;
        for (Listener l : new ArrayList<>(listeners)) l.onRadioState(s, current, err);
    }

    // ===================== التحكم =====================
    /** ضغطة على محطة: إن كانت تعمل/تُحمَّل أوقفها، وإلا شغّلها. */
    void toggle(RadioStation s) {
        if (isActive(s)) stop(); else play(s);
    }

    /** يبدأ بث المحطة. لا يُستدعى إلا من فعل المستخدم. */
    void play(RadioStation s) {
        if (s == null || !s.hasPlayableUrl()) return;
        recovered = false;              // محاولة استرداد واحدة لكل ضغطة
        current = s;
        begin(s);
    }

    private void begin(RadioStation s) {
        releasePlayer();
        final int my = ++gen;
        if (!isOnline()) { fail(R.string.radio_err_offline); return; }
        setState(State.LOADING, 0);
        requestFocus();
        try {
            MediaPlayer p = new MediaPlayer();
            mp = p;
            p.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            try { p.setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK); } catch (Exception ignored) { }
            p.setOnPreparedListener(m -> {
                if (my != gen) return;
                main.removeCallbacks(timeout);
                try { m.start(); } catch (Exception e) { onStreamError(my, R.string.radio_err_generic); return; }
                setState(State.PLAYING, 0);
            });
            p.setOnInfoListener((m, what, extra) -> {
                if (my != gen) return true;
                if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START && state == State.PLAYING) setState(State.LOADING, 0);
                else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END && state == State.LOADING && mp != null && mp.isPlaying()) setState(State.PLAYING, 0);
                return true;
            });
            p.setOnErrorListener((m, what, extra) -> {
                onStreamError(my, what == MediaPlayer.MEDIA_ERROR_SERVER_DIED ? R.string.radio_err_generic
                        : (extra == -110 /* ETIMEDOUT */ ? R.string.radio_err_timeout : R.string.radio_err_generic));
                return true;
            });
            p.setOnCompletionListener(m -> onStreamError(my, R.string.radio_err_ended));
            p.setDataSource(s.url);
            p.prepareAsync();
            main.postDelayed(timeout, PREPARE_TIMEOUT_MS);
        } catch (Exception e) {
            onStreamError(my, R.string.radio_err_generic);
        }
    }

    /**
     * فشل البث. للمحطات المدمجة نجرّب مرة واحدة رابطاً بديلاً (Radio Browser ثم بوابة الإذاعة الجزائرية)،
     * وهذا يحدث فقط ضمن تشغيل طلبه المستخدم؛ وإن أوقف المستخدم أو بدّل المحطة يُلغى فوراً.
     */
    private void onStreamError(int my, int res) {
        if (my != gen) return;
        final RadioStation s = current;
        if (s == null || !s.builtIn || recovered) { fail(res); return; }
        recovered = true;
        main.removeCallbacks(timeout);
        releasePlayer();
        final int g = ++gen;
        setState(State.LOADING, 0);
        RadioRepository.resolveAlternative(s, alt -> {
            if (g != gen) return;                       // أُوقفت/بُدّلت المحطة أثناء البحث
            if (alt == null || alt.equalsIgnoreCase(s.url)) { fail(res); return; }
            RadioStation r = new RadioStation(s.id, s.name, alt, s.country, s.code, s.codec, s.bitrate, true);
            current = r;
            begin(r);
        });
    }

    /** إيقاف وتحرير كامل. آمن للاستدعاء في أي وقت. */
    void stop() {
        main.removeCallbacks(sleepStop); sleepEnd = 0;
        gen++;
        main.removeCallbacks(timeout);
        releasePlayer();
        abandonFocus();
        if (state != State.STOPPED || errorRes != 0) setState(State.STOPPED, 0);
    }

    /** minutes ≤ 0 يلغي المؤقت. */
    void setSleepTimer(int minutes) {
        main.removeCallbacks(sleepStop);
        if (minutes <= 0) { sleepEnd = 0; return; }
        long ms = minutes * 60_000L;
        sleepEnd = SystemClock.elapsedRealtime() + ms;
        main.postDelayed(sleepStop, ms);
    }
    /** الدقائق المتبقية (تقريب للأعلى)، 0 إن لم يكن هناك مؤقت. */
    int sleepMinutesLeft() {
        if (sleepEnd == 0) return 0;
        long ms = sleepEnd - SystemClock.elapsedRealtime();
        return ms <= 0 ? 0 : (int) ((ms + 59_999L) / 60_000L);
    }

    /** عند إغلاق التطبيق: أوقف وحرّر وانسَ المحطة الحالية. */
    void release() {
        stop();
        current = null;
        listeners.clear();
    }

    private void fail(int res) {
        gen++;
        main.removeCallbacks(timeout);
        releasePlayer();
        abandonFocus();
        setState(State.ERROR, res);
    }

    private void releasePlayer() {
        final MediaPlayer old = mp;
        mp = null;
        if (old == null) return;
        old.setOnPreparedListener(null); old.setOnErrorListener(null);
        old.setOnCompletionListener(null); old.setOnInfoListener(null);
        // release() قد يتأخر مع بث عالق؛ نفّذه خارج الخيط الرئيسي حتى لا تتجمد الواجهة
        new Thread(() -> {
            try { old.stop(); } catch (Exception ignored) { }
            try { old.release(); } catch (Exception ignored) { }
        }, "radio-release").start();
    }

    // ===================== التركيز الصوتي والشبكة =====================
    @SuppressWarnings("deprecation")
    private void requestFocus() {
        if (am == null || hasFocus) return;
        int r;
        if (Build.VERSION.SDK_INT >= 26) {
            focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setOnAudioFocusChangeListener(focusListener, main).build();
            r = am.requestAudioFocus(focusReq);
        } else {
            r = am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
        hasFocus = r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    }

    @SuppressWarnings("deprecation")
    private void abandonFocus() {
        if (am == null || !hasFocus) return;
        if (Build.VERSION.SDK_INT >= 26) { if (focusReq != null) am.abandonAudioFocusRequest(focusReq); }
        else am.abandonAudioFocus(focusListener);
        hasFocus = false;
    }

    @SuppressWarnings("deprecation")
    private boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) app.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            return ni == null || ni.isConnected();   // عند الشك نترك المحاولة تحسم
        } catch (Exception e) { return true; }
    }
}
