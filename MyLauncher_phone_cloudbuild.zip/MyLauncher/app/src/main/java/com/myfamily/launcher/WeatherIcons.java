package com.myfamily.launcher;

/**
 * ربط أكواد حالة WeatherAPI بأيقونات الطقس (مجموعة السكن SimpliMaX، ترقيم weather.com 0-47).
 * أيقونة خطية بيضاء واحدة للشارة والبطاقة.
 * (ملف مُولَّد؛ الأيقونات الكرتونية مثل الغبار/الرياح/البرد/الحر استُبعدت عمداً.)
 */
final class WeatherIcons {
    private WeatherIcons() { }

    /** البطاقة تستعمل الأيقونة الخطية نفسها (تُلوَّن بالكود) — لا أيقونات ملوّنة كبيرة لتقليل حجم الـ APK. */
    static int big(int code, boolean day) { return small(code, day); }

    /** لون الأيقونة الخطية حسب الحالة: شمس ذهبية، قمر أزرق فاتح، غيوم رمادية مزرقة، مطر أزرق، ثلج سماوي، عواصف بنفسجية. */
    static int tint(int code, boolean day) {
        switch (code) {
            case 1000: return day ? 0xFFFFC83D : 0xFFC9D8FF;
            case 1003: case 1006: return day ? 0xFFFFD36E : 0xFFC9D8FF;
            case 1009: return 0xFFB8C7D9;
            case 1030: case 1135: case 1147: return 0xFFC9D3DC;
            case 1087: case 1273: case 1276: case 1279: case 1282: return 0xFFC59BFF;
            case 1066: case 1069: case 1072: case 1114: case 1117:
            case 1204: case 1207: case 1210: case 1213: case 1216: case 1219: case 1222: case 1225:
            case 1237: case 1249: case 1252: case 1255: case 1258: case 1261: case 1264: return 0xFF9EE6FF;
            default: return 0xFF5CB8FF;                      // مطر وما عداه
        }
    }

    static int small(int code, boolean day) {
        switch (code) {
            case 1000: return day ? R.drawable.wxs_32 : R.drawable.wxs_31;
            case 1003: return day ? R.drawable.wxs_28 : R.drawable.wxs_27;
            case 1006: return day ? R.drawable.wxs_28 : R.drawable.wxs_27;
            case 1009: return R.drawable.wxs_26;
            case 1030: return R.drawable.wxs_19;
            case 1063: return day ? R.drawable.wxs_39 : R.drawable.wxs_45;
            case 1066: return day ? R.drawable.wxs_41 : R.drawable.wxs_46;
            case 1069: return R.drawable.wxs_5;
            case 1072: return R.drawable.wxs_8;
            case 1087: return day ? R.drawable.wxs_37 : R.drawable.wxs_47;
            case 1114: return R.drawable.wxs_15;
            case 1117: return R.drawable.wxs_43;
            case 1135: return R.drawable.wxs_19;
            case 1147: return R.drawable.wxs_19;
            case 1150: return R.drawable.wxs_9;
            case 1153: return R.drawable.wxs_9;
            case 1168: return R.drawable.wxs_8;
            case 1171: return R.drawable.wxs_10;
            case 1180: return day ? R.drawable.wxs_39 : R.drawable.wxs_45;
            case 1183: return R.drawable.wxs_11;
            case 1186: return R.drawable.wxs_11;
            case 1189: return R.drawable.wxs_12;
            case 1192: return R.drawable.wxs_40;
            case 1195: return R.drawable.wxs_40;
            case 1198: return R.drawable.wxs_10;
            case 1201: return R.drawable.wxs_10;
            case 1204: return R.drawable.wxs_5;
            case 1207: return R.drawable.wxs_5;
            case 1210: return R.drawable.wxs_13;
            case 1213: return R.drawable.wxs_13;
            case 1216: return R.drawable.wxs_16;
            case 1219: return R.drawable.wxs_16;
            case 1222: return R.drawable.wxs_42;
            case 1225: return R.drawable.wxs_42;
            case 1237: return R.drawable.wxs_18;
            case 1240: return day ? R.drawable.wxs_39 : R.drawable.wxs_45;
            case 1243: return R.drawable.wxs_12;
            case 1246: return R.drawable.wxs_40;
            case 1249: return R.drawable.wxs_5;
            case 1252: return R.drawable.wxs_5;
            case 1255: return day ? R.drawable.wxs_41 : R.drawable.wxs_46;
            case 1258: return R.drawable.wxs_42;
            case 1261: return R.drawable.wxs_18;
            case 1264: return R.drawable.wxs_18;
            case 1273: return day ? R.drawable.wxs_37 : R.drawable.wxs_47;
            case 1276: return R.drawable.wxs_4;
            case 1279: return day ? R.drawable.wxs_38 : R.drawable.wxs_47;
            case 1282: return R.drawable.wxs_3;
            default: return R.drawable.wxs_26;
        }
    }
}
