package com.myfamily.launcher;

import java.util.Calendar;
import java.util.TimeZone;

/** حساب أوقات الصلاة محليًا (طريقة الجزائر: الفجر 18°، العشاء 17°). بدون إنترنت. */
public class PrayerTimes {
    public static double LAT = 33.80, LNG = 2.88;                 // الأغواط (افتراضي)
    public static TimeZone TZ = TimeZone.getTimeZone("Africa/Algiers");
    public static int METHOD = 19;                                // 19 = الجزائر
    /** تعديل يدوي بالدقائق (−4..+4) لكل وقت: [فجر، شروق، ظهر، عصر، مغرب، عشاء] */
    public static final int[] ADJ = new int[6];

    public static void loadAdjust(android.content.SharedPreferences s) {
        for (int i = 0; i < 6; i++) ADJ[i] = Math.max(-4, Math.min(4, s.getInt("padj" + i, 0)));
    }

    /** {رقم الطريقة، زاوية الفجر، زاوية العشاء، دقائق العشاء بعد المغرب (0 = بالزاوية)} */
    public static final double[][] TABLE = {
        {0,16,14,0},{1,18,18,0},{2,15,15,0},{3,18,17,0},{4,18.5,0,90},{5,19.5,17.5,0},
        {7,17.7,14,0},{8,19.5,0,90},{9,18,17.5,0},{10,18,0,90},{11,20,18,0},{12,12,12,0},
        {13,18,17,0},{14,16,15,0},{15,18,18,0},{16,18.2,18.2,0},{17,20,18,0},{18,18,18,0},
        {19,18,17,0},{20,20,18,0},{21,19,17,0},{22,18,0,77},{23,18,18,0}};

    private static double[] row() {
        for (double[] r : TABLE) if ((int) r[0] == METHOD) return r;
        return TABLE[18];
    }

    /** يرجع الأوقات كساعات عشرية محلية: [فجر، شروق، ظهر، عصر، مغرب، عشاء] */
    public static double[] compute(Calendar day) {
        double tz = TZ.getOffset(day.getTimeInMillis()) / 3600000.0;
        int y = day.get(Calendar.YEAR), m = day.get(Calendar.MONTH) + 1, d = day.get(Calendar.DAY_OF_MONTH);
        if (m <= 2) { y--; m += 12; }
        int a = y / 100, b = 2 - a + a / 4;
        double jd = Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5;
        double D = jd - 2451545.0;
        double g = rad(fix(357.529 + 0.98560028 * D, 360));
        double q = fix(280.459 + 0.98564736 * D, 360);
        double L = rad(fix(q + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g), 360));
        double e = rad(23.439 - 0.00000036 * D);
        double ra = Math.toDegrees(Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L))) / 15;
        double eqt = q / 15 - fix(ra, 24);
        double decl = Math.asin(Math.sin(e) * Math.sin(L));
        double noon = 12 + tz - LNG / 15 - eqt;
        double asrAlt = Math.toDegrees(Math.atan(1 / (1 + Math.tan(Math.abs(rad(LAT) - decl)))));
        double[] r = row();
        double maghrib = noon + angle(-0.833, decl);
        double isha = r[3] > 0 ? maghrib + r[3] / 60 : noon + angle(-r[2], decl);
        double[] out = {
            noon - angle(-r[1], decl), noon - angle(-0.833, decl), noon,
            noon + angle(asrAlt, decl), maghrib, isha};
        for (int i = 0; i < 6; i++) out[i] += ADJ[i] / 60.0;
        return out;
    }

    private static double angle(double altDeg, double decl) {
        double lat = rad(LAT);
        double c = (Math.sin(rad(altDeg)) - Math.sin(lat) * Math.sin(decl)) / (Math.cos(lat) * Math.cos(decl));
        return Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, c)))) / 15;
    }
    private static double rad(double x) { return Math.toRadians(x); }
    private static double fix(double a, double m) { a = a - m * Math.floor(a / m); return a < 0 ? a + m : a; }

    public static String fmt(double h) {
        int mins = (int) Math.round(fix(h, 24) * 60);
        return String.format("%02d:%02d", (mins / 60) % 24, mins % 60);
    }
}
