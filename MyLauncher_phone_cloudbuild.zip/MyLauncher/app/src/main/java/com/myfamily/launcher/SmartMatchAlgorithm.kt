package com.myfamily.launcher

import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Provider-neutral match selection policy. Team and tournament IDs are injected after provider verification. */
object SmartMatchAlgorithm {
    val ALGIERS_TZ: ZoneId = ZoneId.of("Africa/Algiers")
    val MAX_AWAITING_UPDATE: Duration = Duration.ofHours(2)
    val MAX_LIVE_AGE: Duration = Duration.ofHours(8)
    val ORDINARY_GAP: Duration = Duration.ofHours(4)
    const val MAX_RESULTS = 3
    /** الفئة D: مكمِّلة فقط (50–55). لا تزاحم A/B/C ولا تخضع لفاصل الأربع ساعات. */
    private const val CATEGORY_D = "الفئة D"
    /** مباراة مؤهَّلة بالمتابعة فقط (لا A/B/C/D). تملأ الأماكن الشاغرة ولا ترتقي إلى أي فئة. */
    private const val CATEGORY_FOLLOW = "فئة المتابعة"
    private const val FOLLOW_SCORE = 40

    data class Match(
        val homeTeamId: Int?,
        val awayTeamId: Int?,
        val tournamentId: Int? = null,
        val tournamentName: String? = null,
        val matchType: String? = null,
        val importance: String? = null,
        val startTime: Instant? = null,
        /** Provider status must be normalized through normalizeProviderStatus before use. */
        val status: String? = null,
        val homeScore: Int? = null,
        val awayScore: Int? = null,
        val minute: String? = null,
        val providerMatchId: String? = null
    )

    enum class MatchState {
        UPCOMING, COUNTDOWN, LIVE, FINISHED, POSTPONED, CANCELLED,
        SUSPENDED, AWAITING_UPDATE, EXPIRED, UNSCHEDULED
    }

    data class RankedMatch(
        val match: Match,
        val state: MatchState,
        val category: String,
        val score: Int,
        val tournamentPriority: Int,
        val followScore: Int = 0
    )

    /**
     * The caller supplies verified IDs. Tests may use synthetic IDs; do not copy those
     * fixtures into production configuration. Missing IDs simply disable pair/team matching.
     */
    data class TeamCatalog(
        val teamIds: Map<String, Int>,
        val bigTeams: Set<String> = setOf(
            "REAL_MADRID", "BARCELONA", "ATLETICO_MADRID", "LIVERPOOL",
            "MAN_CITY", "MAN_UTD", "ARSENAL", "CHELSEA", "TOTTENHAM",
            "BAYERN", "DORTMUND", "PSG", "MARSEILLE", "AC_MILAN",
            "INTER", "JUVENTUS", "ROMA"
        ),
        val exceptionalPairs: Set<Set<String>> = setOf(
            setOf("REAL_MADRID", "BARCELONA"),
            setOf("REAL_MADRID", "ATLETICO_MADRID"),
            setOf("AC_MILAN", "INTER"),
            setOf("ARSENAL", "TOTTENHAM"),
            setOf("PSG", "MARSEILLE"),
            setOf("INTER", "JUVENTUS")
        )
    )

    /** Names are canonical labels; IDs can be added only after provider verification. */
    data class TournamentCatalog(
        val majorNames: Set<String> = setOf(
            "UEFA Champions League", "FIFA World Cup", "World Cup",
            "Africa Cup of Nations", "UEFA Euro / Major Tournaments"
        ),
        val priorityByName: Map<String, Int> = mapOf(
            "UEFA Champions League" to 1,
            "FIFA World Cup" to 2,
            "World Cup" to 2,
            "Africa Cup of Nations" to 3,
            "UEFA Euro / Major Tournaments" to 4,
            "Premier League" to 5,
            "La Liga" to 6,
            "Ligue 1" to 7,
            "Serie A" to 8,
            "Bundesliga" to 9
        ),
        val majorIds: Set<Int> = emptySet(),
        val priorityById: Map<Int, Int> = emptyMap()
    )

    /**
     * قوائم متابعة المستخدم (معرّفات البطولات والفرق) يمرّرها التطبيق من بياناته.
     * المتابعة لا تغيّر تصنيف A/B/C/D؛ هي (1) أولوية ترتيب مستقلة و(2) تأهيل لملء الأماكن الشاغرة.
     */
    data class FollowCatalog(
        val leagueIds: Set<Int> = emptySet(),
        val teamIds: Set<Int> = emptySet()
    )

    /** نقطة لكل من: بطولة متابَعة، فريق متابَع (يتراكمان). 0 = غير متابَعة. */
    private fun followScore(match: Match, follow: FollowCatalog): Int {
        val league = match.tournamentId != null && match.tournamentId in follow.leagueIds
        val team = (match.homeTeamId != null && match.homeTeamId in follow.teamIds) ||
            (match.awayTeamId != null && match.awayTeamId in follow.teamIds)
        return (if (league) 1 else 0) + (if (team) 1 else 0)
    }

    private fun exemptFromGap(category: String): Boolean =
        category == "الفئة A" || category == CATEGORY_D || category == CATEGORY_FOLLOW

    private fun norm(value: String?): String =
        value.orEmpty().trim().lowercase(Locale.ROOT).replace('-', '_')

    /**
     * Generic aliases explicitly listed during review. A provider adapter should own
     * its provider-specific mapping and pass these canonical values to the algorithm.
     */
    fun normalizeProviderStatus(raw: String?): String? = when (
        norm(raw).replace(' ', '_')
    ) {
        "cancelled", "canceled" -> "cancelled"
        "postponed", "delayed" -> "postponed"
        "suspended", "interrupted" -> "suspended"
        "ft", "aet", "pen", "finished", "full_time" -> "finished"
        "live", "1h", "2h", "ht" -> "live"
        else -> null
    }

    fun getMatchState(match: Match, now: Instant): MatchState {
        when (normalizeProviderStatus(match.status)) {
            "cancelled" -> return MatchState.CANCELLED
            "postponed" -> return MatchState.POSTPONED
            "suspended" -> return MatchState.SUSPENDED
            "finished" -> return MatchState.FINISHED
            "live" -> return MatchState.LIVE
        }

        val start = match.startTime ?: return MatchState.UNSCHEDULED
        if (start.isAfter(now)) {
            val untilStart = Duration.between(now, start)
            return if (untilStart <= Duration.ofHours(2)) {
                MatchState.COUNTDOWN
            } else {
                MatchState.UPCOMING
            }
        }

        val delay = Duration.between(start, now)
        return if (delay <= MAX_AWAITING_UPDATE) {
            MatchState.AWAITING_UPDATE
        } else {
            MatchState.EXPIRED
        }
    }

    fun getMatchStatusAndDisplay(match: Match, now: Instant): Pair<String, String> {
        val state = getMatchState(match, now)
        val score = "${match.homeScore ?: 0} - ${match.awayScore ?: 0}"
        return when (state) {
            MatchState.FINISHED -> "FINISHED" to "النتيجة النهائية: $score"
            MatchState.LIVE -> "LIVE" to "$score (${match.minute ?: "—"})"
            MatchState.COUNTDOWN -> {
                val seconds = Duration.between(now, match.startTime).seconds.coerceAtLeast(0)
                "COUNTDOWN" to "تبدأ خلال: ${seconds / 3600}س ${(seconds % 3600) / 60}د"
            }
            MatchState.UPCOMING -> "UPCOMING" to
                (match.startTime?.atZone(ALGIERS_TZ)?.format(DateTimeFormatter.ofPattern("HH:mm")) ?: "—")
            MatchState.AWAITING_UPDATE -> "AWAITING_UPDATE" to "بانتظار تحديث حالة المباراة"
            MatchState.EXPIRED -> "EXPIRED" to "لم يصل تحديث المباراة؛ أُزيلت من القائمة"
            MatchState.CANCELLED -> "CANCELLED" to "مباراة ملغاة"
            MatchState.POSTPONED -> "POSTPONED" to "مباراة مؤجلة"
            MatchState.SUSPENDED -> "SUSPENDED" to "مباراة متوقفة"
            MatchState.UNSCHEDULED -> "UNSCHEDULED" to "موعد الانطلاق غير متاح"
        }
    }

    fun evaluateMatch(
        match: Match,
        teams: TeamCatalog,
        tournaments: TournamentCatalog = TournamentCatalog()
    ): Pair<String, Int>? {
        val home = match.homeTeamId ?: return categoryCIfImportant(match)
        val away = match.awayTeamId ?: return categoryCIfImportant(match)
        val homeKey = teams.teamIds.entries.firstOrNull { it.value == home }?.key
        val awayKey = teams.teamIds.entries.firstOrNull { it.value == away }?.key
        val pair = if (homeKey != null && awayKey != null) setOf(homeKey, awayKey) else emptySet()

        val exceptional = pair.size == 2 && pair in teams.exceptionalPairs
        val type = norm(match.matchType)
        val majorTournament = isMajorTournament(match, tournaments)
        if (exceptional || (type == "final" && majorTournament) ||
            (type in setOf("knockout", "quarter_final", "semi_final") && majorTournament)
        ) {
            val score = when {
                pair == setOf("REAL_MADRID", "BARCELONA") -> 100
                type == "final" && majorTournament -> 100
                type == "knockout" && norm(match.tournamentName) == norm("UEFA Champions League") -> 90
                else -> 85
            }
            return "الفئة A" to score
        }

        val homeIsBig = homeKey != null && homeKey in teams.bigTeams
        val awayIsBig = awayKey != null && awayKey in teams.bigTeams
        if (homeIsBig && awayIsBig) return "الفئة B" to 70

        categoryCIfImportant(match)?.let { return it }

        // الفئة D: نادٍ كبير واحد على الأقل داخل بطولة كبرى. لا تصل إلى A أو B أو C.
        if ((homeIsBig || awayIsBig) && majorTournament) {
            return CATEGORY_D to categoryDScore(match, tournaments)
        }
        return null
    }

    /** 55 للبطولتين الأعلى أولوية في الكتالوج (أولوية ≤ 2)، و50 لبقية البطولات الكبرى. */
    private fun categoryDScore(match: Match, tournaments: TournamentCatalog): Int =
        if (tournamentPriority(match, tournaments) <= 2) 55 else 50

    private fun categoryCIfImportant(match: Match): Pair<String, Int>? =
        if (norm(match.importance) in setOf("title_decider", "qualification", "relegation_decider")) {
            "الفئة C" to 60
        } else null

    private fun isMajorTournament(match: Match, tournaments: TournamentCatalog): Boolean {
        if (match.tournamentId != null && match.tournamentId in tournaments.majorIds) return true
        return norm(match.tournamentName) in tournaments.majorNames.map(::norm).toSet()
    }

    private fun tournamentPriority(match: Match, tournaments: TournamentCatalog): Int {
        val idPriority = match.tournamentId?.let(tournaments.priorityById::get)
        if (idPriority != null) return idPriority
        return tournaments.priorityByName.entries
            .firstOrNull { norm(it.key) == norm(match.tournamentName) }
            ?.value ?: 100
    }

    private data class Quality(
        val aCount: Int,
        val coreCount: Int,
        val total: Int,
        val dCount: Int,
        val liveCount: Int,
        val scoreSum: Long,
        val followSum: Long,
        val tournamentPrioritySum: Long,
        val kickoffSum: Long
    )

    private fun quality(items: List<RankedMatch>) = Quality(
        aCount = items.count { it.category == "الفئة A" },
        coreCount = items.count { it.category != CATEGORY_D && it.category != CATEGORY_FOLLOW },
        total = items.size,
        dCount = items.count { it.category == CATEGORY_D },
        liveCount = items.count { it.state == MatchState.LIVE },
        scoreSum = items.sumOf { it.score.toLong() },
        followSum = items.sumOf { it.followScore.toLong() },
        tournamentPrioritySum = items.sumOf { it.tournamentPriority.toLong() },
        kickoffSum = items.sumOf { it.match.startTime?.epochSecond ?: Long.MAX_VALUE / 4 }
    )

    private fun better(a: Quality, b: Quality): Boolean = when {
        a.aCount != b.aCount -> a.aCount > b.aCount
        // D والمتابعة لا تزاحمان A/B/C: نفضّل أكبر عدد من A/B/C، ثم نكمل الأماكن الشاغرة
        a.coreCount != b.coreCount -> a.coreCount > b.coreCount
        a.total != b.total -> a.total > b.total
        a.dCount != b.dCount -> a.dCount > b.dCount          // عند التساوي: D قبل مباريات المتابعة فقط
        a.liveCount != b.liveCount -> a.liveCount > b.liveCount
        a.scoreSum != b.scoreSum -> a.scoreSum > b.scoreSum
        a.followSum != b.followSum -> a.followSum > b.followSum   // أولوية المتابعة المستقلة
        a.tournamentPrioritySum != b.tournamentPrioritySum -> a.tournamentPrioritySum < b.tournamentPrioritySum
        else -> a.kickoffSum < b.kickoffSum
    }

    private fun sameSelectionKey(match: Match): Any = match.providerMatchId?.let { "provider:$it" }
        ?: listOf(match.tournamentId, match.homeTeamId, match.awayTeamId, match.startTime)

    fun rankAndSelect(
        matches: List<Match>,
        now: Instant,
        targetDate: LocalDate,
        teams: TeamCatalog,
        tournaments: TournamentCatalog = TournamentCatalog(),
        follow: FollowCatalog = FollowCatalog()
    ): List<RankedMatch> {
        val candidates = matches.distinctBy(::sameSelectionKey).mapNotNull { match ->
            val start = match.startTime ?: return@mapNotNull null
            val state = getMatchState(match, now)
            val followScore = followScore(match, follow)
            val categoryAndScore = evaluateMatch(match, teams, tournaments)
                ?: (if (followScore > 0) CATEGORY_FOLLOW to FOLLOW_SCORE else null)
                ?: return@mapNotNull null
            if (state !in setOf(
                    MatchState.UPCOMING, MatchState.COUNTDOWN, MatchState.LIVE,
                    MatchState.FINISHED, MatchState.SUSPENDED, MatchState.AWAITING_UPDATE
                )
            ) return@mapNotNull null
            if (!belongsToDate(start, state, targetDate, now)) return@mapNotNull null
            RankedMatch(
                match = match,
                state = state,
                category = categoryAndScore.first,
                score = categoryAndScore.second,
                tournamentPriority = tournamentPriority(match, tournaments),
                followScore = followScore
            )
        }

        return chooseBest(candidates)
    }

    private fun belongsToDate(start: Instant, state: MatchState, targetDate: LocalDate, now: Instant): Boolean {
        val localDate = start.atZone(ALGIERS_TZ).toLocalDate()
        if (state != MatchState.LIVE) return localDate == targetDate
        if (start.isAfter(now)) return false
        val age = Duration.between(start, now)
        if (age.isNegative || age > MAX_LIVE_AGE) return false
        if (localDate == targetDate) return true
        val today = now.atZone(ALGIERS_TZ).toLocalDate()
        return targetDate == today && localDate == targetDate.minusDays(1)
    }

    private fun compatible(candidate: RankedMatch, chosen: List<RankedMatch>): Boolean {
        if (exemptFromGap(candidate.category)) return true
        val start = candidate.match.startTime ?: return false
        return chosen.all { existing ->
            if (exemptFromGap(existing.category)) true
            else {
                val other = existing.match.startTime ?: return@all false
                Duration.between(start, other).abs() >= ORDINARY_GAP
            }
        }
    }

    private fun chooseBest(candidates: List<RankedMatch>): List<RankedMatch> {
        var best = emptyList<RankedMatch>()
        var bestQuality = quality(best)
        val chosen = mutableListOf<RankedMatch>()

        fun search(from: Int) {
            val q = quality(chosen)
            if (better(q, bestQuality)) {
                best = chosen.toList()
                bestQuality = q
            }
            if (chosen.size == MAX_RESULTS) return
            for (i in from until candidates.size) {
                val candidate = candidates[i]
                if (!compatible(candidate, chosen)) continue
                chosen += candidate
                search(i + 1)
                chosen.removeAt(chosen.lastIndex)
            }
        }

        search(0)
        return best.sortedWith(
            compareByDescending<RankedMatch> { it.category == "الفئة A" }
                .thenByDescending { it.score }
                .thenByDescending { it.followScore }
                .thenBy { it.tournamentPriority }
                .thenBy { it.match.startTime }
        )
    }

    /** allMatches is supplied by the caller and should contain today's and tomorrow's data. */
    fun selectTopSmartMatches(
        allMatches: List<Match>,
        now: Instant,
        teams: TeamCatalog,
        tournaments: TournamentCatalog = TournamentCatalog(),
        follow: FollowCatalog = FollowCatalog()
    ): List<RankedMatch> {
        val today = now.atZone(ALGIERS_TZ).toLocalDate()
        val todays = rankAndSelect(allMatches, now, today, teams, tournaments, follow)
        if (todays.isNotEmpty()) return todays
        return rankAndSelect(allMatches, now, today.plusDays(1), teams, tournaments, follow)
    }
}
