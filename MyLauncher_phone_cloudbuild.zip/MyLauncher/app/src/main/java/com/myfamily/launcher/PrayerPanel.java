package com.myfamily.launcher;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** TV-friendly prayer-times dialog. Values are supplied by the launcher's live calculator. */
public final class PrayerPanel {
    private PrayerPanel() { }

    public interface DataSource {
        PageData current();
    }

    public static final class PageData {
        public final String locationAndDate;
        public final String hijriDate;
        public final String countdownText;
        public final String methodText;
        public final List<PrayerItem> prayers;

        public PageData(String locationAndDate, String hijriDate, String countdownText,
                        String methodText, List<PrayerItem> prayers) {
            this.locationAndDate = locationAndDate;
            this.hijriDate = hijriDate;
            this.countdownText = countdownText;
            this.methodText = methodText;
            this.prayers = prayers == null ? new ArrayList<>() : new ArrayList<>(prayers);
        }
    }

    public static final class PrayerItem {
        public final String name;
        public final String time;
        public final String icon;
        public final boolean isNext;

        public PrayerItem(String name, String time, String icon, boolean isNext) {
            this.name = name;
            this.time = time;
            this.icon = icon;
            this.isNext = isNext;
        }
    }

    public static Dialog show(Context context, DataSource source, Runnable onDismiss) {
        Dialog dialog = new Dialog(context, android.R.style.Theme_DeviceDefault_NoActionBar);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        Typeface outfit = Fonts.outfit(context);
        FrameLayout root = new FrameLayout(context);
        root.setClipToOutline(true);
        GradientDrawable rootBg = new GradientDrawable();
        rootBg.setCornerRadius(dp(context, 24));
        rootBg.setColor(Color.parseColor("#0D1520"));
        rootBg.setStroke(dp(context, 1), Color.parseColor("#33FFFFFF"));
        root.setBackground(rootBg);

        ImageView background = new ImageView(context);
        background.setImageResource(R.drawable.mosque_bg);
        background.setScaleType(ImageView.ScaleType.CENTER_CROP);
        background.setAlpha(1f);                       // صورة المسجد ظاهرة بالكامل
        background.setFocusable(false);
        root.addView(background, new FrameLayout.LayoutParams(-1, -1));

        View shade = new View(context);
        GradientDrawable shadeBg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#B30B131E"), Color.parseColor("#1A0B131E"), Color.parseColor("#E60B131E")});
        shade.setBackground(shadeBg);
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setClipChildren(false);
        int padding = dp(context, 28);
        content.setPadding(padding, padding, padding, dp(context, 22));
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = new LinearLayout(context);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleColumn = new LinearLayout(context);
        titleColumn.setOrientation(LinearLayout.VERTICAL);
        titleColumn.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));

        TextView title = text(context, outfit, 30, Color.WHITE);
        title.setText(R.string.prayer_times_title);
        title.setTypeface(outfit, Typeface.BOLD);
        title.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);

        TextView subtitle = text(context, outfit, 16, Color.parseColor("#E2E8F0"));
        subtitle.setMaxLines(2);
        subtitle.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);

        TextView method = text(context, outfit, 12, Color.parseColor("#94A3B8"));
        method.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        titleColumn.addView(title);
        titleColumn.addView(subtitle);
        titleColumn.addView(method);

        TextView countdown = text(context, outfit, 15, Color.parseColor("#7DD3FC"));
        countdown.setTypeface(outfit, Typeface.BOLD);
        countdown.setSingleLine(true);
        countdown.setEllipsize(android.text.TextUtils.TruncateAt.END);
        countdown.setPadding(dp(context, 14), dp(context, 9), dp(context, 14), dp(context, 9));
        GradientDrawable countdownBg = new GradientDrawable();
        countdownBg.setColor(Color.parseColor("#2638BDF8"));
        countdownBg.setCornerRadius(dp(context, 40));
        countdownBg.setStroke(dp(context, 1), Color.parseColor("#6638BDF8"));
        countdown.setBackground(countdownBg);

        ImageView settings = new ImageView(context);
        settings.setImageResource(R.drawable.ic_gear);
        settings.setColorFilter(Color.WHITE);
        settings.setPadding(dp(context, 10), dp(context, 10), dp(context, 10), dp(context, 10));
        settings.setFocusable(true);
        settings.setClickable(true);
        settings.setContentDescription(context.getString(R.string.adhan_settings_title));
        GradientDrawable settingsBg = new GradientDrawable();
        settingsBg.setShape(GradientDrawable.OVAL);
        settingsBg.setColor(Color.parseColor("#1FFFFFFF"));
        settings.setBackground(settingsBg);
        settings.setOnFocusChangeListener((view, focused) -> {
            settingsBg.setColor(Color.parseColor(focused ? "#0284C7" : "#1FFFFFFF"));
            view.animate().cancel();
            view.animate().scaleX(focused ? 1.12f : 1f).scaleY(focused ? 1.12f : 1f)
                    .setDuration(160).start();
        });
        settings.setOnClickListener(view -> {
            dialog.dismiss();
            Intent intent = new Intent(context, AdhanSettingsActivity.class);
            if (!(context instanceof Activity)) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        });

        LinearLayout.LayoutParams settingsParams = new LinearLayout.LayoutParams(dp(context, 44), dp(context, 44));
        settingsParams.setMarginStart(dp(context, 14));
        header.addView(titleColumn);
        header.addView(countdown);
        header.addView(settings, settingsParams);
        content.addView(header);

        LinearLayout cards = new LinearLayout(context);
        cards.setOrientation(LinearLayout.HORIZONTAL);
        cards.setGravity(Gravity.CENTER);
        cards.setClipChildren(false);
        cards.setClipToPadding(false);
        View spacer = new View(context);                // يدفع البطاقات إلى الأسفل ويترك صورة المسجد ظاهرة
        content.addView(spacer, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout.LayoutParams cardsParams = new LinearLayout.LayoutParams(-1, -2);
        cardsParams.setMargins(0, dp(context, 12), 0, dp(context, 14));
        content.addView(cards, cardsParams);

        List<CardBinding> bindings = new ArrayList<>();
        String[] icons = {"\uD83C\uDF19", "\uD83C\uDF05", "\u2600", "\uD83C\uDF24", "\uD83C\uDF07", "\uD83C\uDF0C"};
        int[] prayerNames = {R.string.fajr, R.string.sunrise, R.string.dhuhr, R.string.asr,
                R.string.maghrib, R.string.isha};
        android.util.DisplayMetrics dm = context.getResources().getDisplayMetrics();
        for (int i = 0; i < prayerNames.length; i++) {
            CardBinding binding = createPrayerCard(context, outfit, icons[i],
                    dm.heightPixels * 0.058f, dm.heightPixels * 0.027f, dm.heightPixels * 0.040f);
            binding.name.setText(prayerNames[i]);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(0, Math.round(dm.heightPixels * 0.25f), 1f);
            cardParams.setMargins(dp(context, 5), dp(context, 4), dp(context, 5), dp(context, 4));
            cards.addView(binding.card, cardParams);
            bindings.add(binding);
        }

        TextView footer = text(context, outfit, 12, Color.parseColor("#94A3B8"));
        footer.setText(R.string.prayer_panel_back_hint);
        footer.setGravity(Gravity.CENTER);
        content.addView(footer);

        dialog.setContentView(root);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.setDimAmount(0.72f);
        }

        Handler handler = new Handler(Looper.getMainLooper());
        Runnable[] updater = new Runnable[1];
        updater[0] = () -> {
            if (!dialog.isShowing()) return;
            try {
                PageData data = source.current();
                if (data != null) {
                    subtitle.setText(data.locationAndDate + "  •  " + data.hijriDate);
                    method.setText(data.methodText);
                    method.setVisibility(data.methodText == null || data.methodText.isEmpty() ? View.GONE : View.VISIBLE);
                    countdown.setText(data.countdownText);
                    for (int i = 0; i < Math.min(bindings.size(), data.prayers.size()); i++) {
                        bindings.get(i).bind(data.prayers.get(i));
                    }
                }
            } catch (RuntimeException ignored) {
                // Retain the last successfully displayed values if a refresh is temporarily unavailable.
            }
            handler.postDelayed(updater[0], 30_000L);
        };
        dialog.setOnDismissListener(ignored -> {
            handler.removeCallbacks(updater[0]);
            if (onDismiss != null) onDismiss.run();
        });
        dialog.setOnShowListener(ignored -> {
            Window shownWindow = dialog.getWindow();
            if (shownWindow != null) {
                int width = Math.round(context.getResources().getDisplayMetrics().widthPixels * 0.88f);
                int height = Math.round(context.getResources().getDisplayMetrics().heightPixels * 0.84f);
                shownWindow.setLayout(width, height);
            }
            updater[0].run();
            cards.post(() -> {
                for (CardBinding binding : bindings) {
                    if (binding.item != null && binding.item.isNext) {
                        binding.card.requestFocus();
                        break;
                    }
                }
            });
        });
        dialog.show();
        return dialog;
    }

    private static CardBinding createPrayerCard(Context context, Typeface font, String iconText, float iconPx, float namePx, float timePx) {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(context, 8), dp(context, 12), dp(context, 8), dp(context, 12));
        card.setFocusable(true);
        card.setClickable(true);

        TextView icon = text(context, font, 24, Color.WHITE);
        icon.setTextSize(TypedValue.COMPLEX_UNIT_PX, iconPx);
        icon.setText(iconText);
        icon.setGravity(Gravity.CENTER);
        TextView name = text(context, font, 15, Color.parseColor("#E2E8F0"));
        name.setTextSize(TypedValue.COMPLEX_UNIT_PX, namePx);
        name.setGravity(Gravity.CENTER);
        name.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        name.setPadding(0, dp(context, 8), 0, dp(context, 4));
        TextView time = text(context, font, 20, Color.WHITE);
        time.setTextSize(TypedValue.COMPLEX_UNIT_PX, timePx);
        time.setGravity(Gravity.CENTER);
        time.setTypeface(font, Typeface.BOLD);
        card.addView(icon);
        card.addView(name);
        card.addView(time);

        CardBinding binding = new CardBinding(card, icon, name, time, context, font);
        card.setOnFocusChangeListener((view, focused) -> binding.setFocused(focused));
        binding.bind(new PrayerItem("", "", iconText, false));
        return binding;
    }

    private static final class CardBinding {
        final LinearLayout card;
        final TextView icon;
        final TextView name;
        final TextView time;
        final Context context;
        final Typeface font;
        PrayerItem item;
        boolean focused;

        CardBinding(LinearLayout card, TextView icon, TextView name, TextView time,
                    Context context, Typeface font) {
            this.card = card;
            this.icon = icon;
            this.name = name;
            this.time = time;
            this.context = context;
            this.font = font;
        }

        void bind(PrayerItem value) {
            item = value;
            icon.setText(value.icon);
            name.setText(value.name);
            time.setText(value.time);
            time.setTypeface(font, Typeface.BOLD);
            GradientDrawable background = new GradientDrawable();
            background.setCornerRadius(dp(context, 18));
            if (value.isNext) {
                background.setOrientation(GradientDrawable.Orientation.TL_BR);
                background.setColors(new int[]{Color.parseColor("#0284C7"), Color.parseColor("#0369A1")});
                background.setStroke(dp(context, focused ? 2 : 2),
                        Color.parseColor(focused ? "#FFFFFFFF" : "#7DD3FC"));
                name.setTextColor(Color.WHITE);
            } else {
                background.setColor(Color.parseColor("#990D1520"));   // زجاج داكن: النص واضح فوق صورة المسجد
                background.setStroke(dp(context, focused ? 2 : 1),
                        Color.parseColor(focused ? "#FFFFFFFF" : "#40FFFFFF"));
                name.setTextColor(Color.parseColor("#E2E8F0"));
            }
            card.setBackground(background);
            updateScale();
        }

        void setFocused(boolean hasFocus) {
            focused = hasFocus;
            card.animate().cancel();
            card.animate().scaleX(scale()).scaleY(scale()).setDuration(170)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            if (item != null) bind(item);
        }

        private float scale() {
            return (item != null && item.isNext ? 1.04f : 1f) + (focused ? 0.06f : 0f);
        }

        private void updateScale() {
            card.setScaleX(scale());
            card.setScaleY(scale());
        }
    }

    private static TextView text(Context context, Typeface font, int sizeSp, int color) {
        TextView view = new TextView(context);
        view.setTextColor(color);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        view.setTypeface(font);
        view.setShadowLayer(4, 0, 1, 0x55000000);
        return view;
    }

    private static int dp(Context context, int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }
}
