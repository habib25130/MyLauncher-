package com.myfamily.launcher;

import android.content.Context;
import android.os.Build;
import java.util.Calendar;
import java.util.Locale;

/** التاريخ الهجري: أم القرى (إن توفر في النظام) وإلا الحساب الجدولي، مع تعديل يدوي ±2 يوم (للرؤية المحلية). */
final class Hijri {
    /** {سنة، شهر 1..12، يوم} */
    static int[] of(Calendar c, int adjust) {
        Calendar d = (Calendar) c.clone();
        d.add(Calendar.DAY_OF_MONTH, adjust);
        int y = d.get(Calendar.YEAR), m = d.get(Calendar.MONTH) + 1, day = d.get(Calendar.DAY_OF_MONTH);
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                java.time.chrono.HijrahDate h = java.time.chrono.HijrahDate.from(java.time.LocalDate.of(y, m, day));
                return new int[]{h.get(java.time.temporal.ChronoField.YEAR), h.get(java.time.temporal.ChronoField.MONTH_OF_YEAR),
                        h.get(java.time.temporal.ChronoField.DAY_OF_MONTH)};
            } catch (Throwable ignored) { }
        }
        return tabular(y, m, day);
    }

    /** الحساب الجدولي (دورة 30 سنة) */
    static int[] tabular(int y, int m, int d) {
        int a = (14 - m) / 12, yy = y + 4800 - a, mm = m + 12 * a - 3;
        long jd = d + (153 * mm + 2) / 5 + 365L * yy + yy / 4 - yy / 100 + yy / 400 - 32045;
        long l = jd - 1948440 + 10632;
        long n = (l - 1) / 10631;
        l = l - 10631 * n + 354;
        long j = ((10985 - l) / 5316) * ((50 * l) / 17719) + (l / 5670) * ((43 * l) / 15238);
        l = l - ((30 - j) / 15) * ((17719 * j) / 50) - (j / 16) * ((15238 * j) / 43) + 29;
        int month = (int) ((24 * l) / 709);
        int day = (int) (l - (709L * month) / 24);
        long year = 30 * n + j - 30;
        return new int[]{(int) year, month, day};
    }

    static String format(Context c) {
        return format(c, true);
    }

    static String formatHeader(Context c) {
        return format(c, false);
    }

    private static String format(Context c, boolean includeSuffix) {
        int adj = c.getSharedPreferences("launcher", Context.MODE_PRIVATE).getInt("hijri_adj", 0);
        int[] h = of(Calendar.getInstance(), adj);
        String[] names = c.getResources().getStringArray(R.array.hijri_months);
        String day = String.format(Locale.ROOT, "%02d", h[2]);
        String result = day + " " + names[Math.max(0, Math.min(11, h[1] - 1))] + " " + h[0];
        return includeSuffix ? result + " " + c.getString(R.string.hijri_suffix) : result;
    }
}
