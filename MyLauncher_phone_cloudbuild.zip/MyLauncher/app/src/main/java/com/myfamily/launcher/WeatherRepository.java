package com.myfamily.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * جلب الطقس من WeatherAPI.com + كاش محلي.
 * - كل الشبكة على خيط خلفي واحد؛ لا شيء يُنفَّذ على الخيط الرئيسي سوى قراءة SharedPreferences الصغيرة.
 * - الفشل صامت تماماً: لا Toast ولا حوارات؛ نبقي آخر نتيجة محفوظة ونعيد المحاولة لاحقاً.
 * - لا يُسجَّل المفتاح ولا الرابط في أي سجل.
 */
final class WeatherRepository {
    private static final String ENDPOINT = "https://api.weatherapi.com/v1/forecast.json";   // الحالة الحالية + توقعات 3 أيام (الحد المجاني) في طلب واحد
    private static final String UA = "MyLauncher/1.0 (Android TV launcher)";

    static final String P_KEY = "weather_key_enc", P_CITY = "weather_q", P_FAHRENHEIT = "weather_f", P_SHOW = "vis_weather";
    private static final String P_CACHE = "weather_cache", P_NEXT_TRY = "weather_next_try", P_BAD_UNTIL = "weather_bad_until", P_ERR = "weather_err";

    /** آخر خطأ جلب (يُصفَّر عند أول نجاح). */
    static final int ERR_NONE = 0, ERR_NETWORK = 1, ERR_QUOTA = 2, ERR_KEY = 3, ERR_SERVER = 4;

    private static final long FRESH_MS = 30 * 60_000L;       // لا نجلب أكثر من مرة كل 30 دقيقة
    private static final long MAX_AGE_MS = 48 * 3600_000L;   // الكاش يبقى معروضاً (مع تنبيه الخطأ) حتى 48 ساعة
    private static final long RETRY_MS = 10 * 60_000L;       // بعد فشل الشبكة
    private static final long BAD_KEY_MS = 6 * 3600_000L;    // بعد رفض المفتاح
    private static final long QUOTA_MS = 3 * 3600_000L;      // بعد انتهاء الحصة المجانية

    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static volatile boolean busy;

    private WeatherRepository() { }

    private static SharedPreferences p(Context c) { return c.getSharedPreferences("launcher", Context.MODE_PRIVATE); }

    // ===================== المفتاح والموقع =====================
    /** المفتاح الذي أدخله المستخدم فقط (مشفّر). لا مفتاح من البناء. */
    static String apiKey(Context c) {
        return SecretStore.decrypt(p(c).getString(P_KEY, "")).trim();
    }

    static boolean hasKey(Context c) { return !apiKey(c).isEmpty(); }

    /** هل أدخل المستخدم مفتاحاً بنفسه (وليس من البناء)؟ */
    static boolean hasUserKey(Context c) { return !SecretStore.decrypt(p(c).getString(P_KEY, "")).trim().isEmpty(); }

    /** حفظ المفتاح مشفّراً؛ نص فارغ = حذف. */
    static void saveKey(Context c, String key) {
        SharedPreferences.Editor e = p(c).edit();
        String k = key == null ? "" : key.trim();
        if (k.isEmpty()) e.remove(P_KEY); else e.putString(P_KEY, SecretStore.encrypt(k));
        e.remove(P_BAD_UNTIL).remove(P_NEXT_TRY).apply();
    }

    static void saveCity(Context c, String city) {
        String s = city == null ? "" : city.trim();
        SharedPreferences.Editor e = p(c).edit();
        if (s.isEmpty()) e.remove(P_CITY); else e.putString(P_CITY, s);
        e.remove(P_NEXT_TRY).apply();
    }

    static String city(Context c) { return p(c).getString(P_CITY, ""); }

    /** المدينة إن حُدّدت، وإلا موقع الجهاز (FusedLocation)، وإلا إحداثيات مواقيت الصلاة/الافتراضية. */
    static String query(Context c) {
        String city = city(c).trim();
        if (!city.isEmpty()) return city;
        return DeviceLocation.queryOrDefault(c);      // موقع الجهاز، وإلا إحداثيات المدينة/الافتراضية
    }

    private static String lang() {
        String l = Locale.getDefault().getLanguage();
        return ("ar".equals(l) || "fr".equals(l)) ? l : "en";
    }

    /** true إذا رفض WeatherAPI المفتاح مؤخراً (يظهر في الإعدادات فقط). */
    static boolean keyRejected(Context c) { return lastError(c) == ERR_KEY && System.currentTimeMillis() < p(c).getLong(P_BAD_UNTIL, 0); }

    /** آخر خطأ جلب (ERR_*)، أو ERR_NONE. */
    static int lastError(Context c) { return p(c).getInt(P_ERR, ERR_NONE); }

    /** نص الخطأ الحالي للواجهة، أو 0 إن لا خطأ. */
    static int errorText(Context c) {
        switch (lastError(c)) {
            case ERR_NETWORK: return R.string.weather_err_network;
            case ERR_QUOTA: return R.string.weather_err_quota;
            case ERR_KEY: return R.string.weather_err_key;
            case ERR_SERVER: return R.string.weather_err_server;
            default: return 0;
        }
    }

    // ===================== الكاش =====================
    /** آخر نتيجة محفوظة إن لم تتجاوز 48 ساعة، وإلا null. */
    static WeatherData cached(Context c) {
        WeatherData d = WeatherData.fromJson(p(c).getString(P_CACHE, ""));
        if (d == null || System.currentTimeMillis() - d.fetchedAt > MAX_AGE_MS) return null;
        return d;
    }

    private static boolean needsRefresh(Context c) {
        WeatherData d = cached(c);
        if (d == null || d.days.isEmpty()) return true;                       // كاش بلا توقعات (إصدار قديم) → حدّث
        if (!d.q.equals(query(c)) || !d.lang.equals(lang())) return true;     // تغيّرت المدينة/اللغة
        return System.currentTimeMillis() - d.fetchedAt >= FRESH_MS;
    }

    // ===================== التحديث =====================
    /** يحدّث في الخلفية إن لزم (force = تجاهل الـ 30 دقيقة وفترات الانتظار، للتحديث اليدوي). يعيد true إن بدأ الجلب. onDone على الخيط الرئيسي بعد المحاولة. */
    static boolean refresh(Context ctx, boolean force, Runnable onDone) {
        final Context app = ctx.getApplicationContext();
        final String key = apiKey(app);
        if (key.isEmpty()) return false;
        long now = System.currentTimeMillis();
        if (!force) {
            if (!needsRefresh(app)) return false;
            if (now < p(app).getLong(P_BAD_UNTIL, 0) || now < p(app).getLong(P_NEXT_TRY, 0)) return false;
        }
        if (busy) return false;
        busy = true;
        final String q = query(app), lang = lang();
        IO.execute(() -> {
            SharedPreferences sp = p(app);
            try {
                WeatherData d = fetch(key, q, lang);
                sp.edit().putString(P_CACHE, d.toJson()).putInt(P_ERR, ERR_NONE).remove(P_NEXT_TRY).remove(P_BAD_UNTIL).apply();
            } catch (ApiError e) {                               // مفتاح مرفوض / حصة منتهية / خطأ خدمة: الكاش يبقى كما هو
                long now2 = System.currentTimeMillis();
                SharedPreferences.Editor ed = sp.edit().putInt(P_ERR, e.kind);
                if (e.kind == ERR_KEY) ed.putLong(P_BAD_UNTIL, now2 + BAD_KEY_MS);
                else if (e.kind == ERR_QUOTA) ed.putLong(P_BAD_UNTIL, now2 + QUOTA_MS);
                else ed.putLong(P_NEXT_TRY, now2 + RETRY_MS);
                ed.apply();
            } catch (java.io.IOException e) {                    // لا شبكة / مهلة
                sp.edit().putInt(P_ERR, ERR_NETWORK).putLong(P_NEXT_TRY, System.currentTimeMillis() + RETRY_MS).apply();
            } catch (Exception e) {                              // ردّ غير مفهوم
                sp.edit().putInt(P_ERR, ERR_SERVER).putLong(P_NEXT_TRY, System.currentTimeMillis() + RETRY_MS).apply();
            } finally {
                busy = false;
            }
            if (onDone != null) MAIN.post(onDone);
        });
        return true;
    }

    private static final class ApiError extends Exception {
        final int kind;
        ApiError(int kind) { this.kind = kind; }
    }

    private static WeatherData fetch(String key, String q, String lang) throws Exception {
        URL url = new URL(ENDPOINT + "?key=" + URLEncoder.encode(key, "UTF-8")
                + "&q=" + URLEncoder.encode(q, "UTF-8") + "&days=3&lang=" + lang + "&aqi=no&alerts=no");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Accept", "application/json");
        try {
            int code = c.getResponseCode();
            if (code == 200) return WeatherData.fromApi(read(c.getInputStream()), q, lang);
            int apiErr = 0;
            try { apiErr = new JSONObject(read(c.getErrorStream())).getJSONObject("error").optInt("code", 0); } catch (Exception ignored) { }
            // 2007 تجاوز الحصة | 1002 مفتاح غير مرسل | 2006 غير صالح | 2008 معطّل | 2009 لا صلاحية | 2010/2011 مفتاح فارغ/خاطئ
            if (apiErr == 2007 || code == 429) throw new ApiError(ERR_QUOTA);
            if (code == 401 || code == 403 || apiErr == 1002 || (apiErr >= 2006 && apiErr <= 2011)) throw new ApiError(ERR_KEY);
            throw new ApiError(ERR_SERVER);                      // لا نضع الرابط في أي رسالة (فيه المفتاح)
        } finally { c.disconnect(); }
    }

    private static String read(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            char[] buf = new char[4096]; int n;
            while ((n = r.read(buf)) > 0 && sb.length() < 200_000) sb.append(buf, 0, n);
        }
        return sb.toString();
    }
}
