package com.myfamily.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Calendar;
import java.util.TimeZone;

/** الصلاة القادمة خارج الواجهة الرئيسية (شاشة التوقف). */
final class PrayerInfo {
    static void load(Context c) {
        SharedPreferences p = c.getSharedPreferences("launcher", Context.MODE_PRIVATE);
        try {
            PrayerTimes.LAT = Double.parseDouble(p.getString("lat", "33.80"));
            PrayerTimes.LNG = Double.parseDouble(p.getString("lng", "2.88"));
            PrayerTimes.TZ = TimeZone.getTimeZone(p.getString("tz", "Africa/Algiers"));
            PrayerTimes.METHOD = p.getInt("method", 19);
            PrayerTimes.loadAdjust(p);
        } catch (Exception ignored) { }
    }

    /** هل اليوم جمعة (بتوقيت مدينة الصلاة)؟ */
    static boolean isFriday() {
        return Calendar.getInstance(PrayerTimes.TZ).get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY;
    }

    /** اسم صلاة الظهر: «الجمعة» يوم الجمعة وإلا «الظهر». */
    static String dhuhrName(Context c) {
        return c.getString(isFriday() ? R.string.jumuah : R.string.dhuhr);
    }

    /** {«الفجر : 05:44»، «غدًا · بعد 9 س 33 د»، المدينة} */
    static String[] next(Context c) {
        load(c);
        String[] names = {c.getString(R.string.fajr), null, dhuhrName(c), c.getString(R.string.asr),
                c.getString(R.string.maghrib), c.getString(R.string.isha)};
        Calendar now = Calendar.getInstance(PrayerTimes.TZ);
        double nowH = now.get(Calendar.HOUR_OF_DAY) + now.get(Calendar.MINUTE) / 60.0;
        double[] t = PrayerTimes.compute(now);
        int next = -1;
        for (int i = 0; i < 6; i++) if (names[i] != null && t[i] > nowH) { next = i; break; }
        boolean tomorrow = false;
        if (next < 0) {
            Calendar tm = (Calendar) now.clone(); tm.add(Calendar.DAY_OF_MONTH, 1);
            t = PrayerTimes.compute(tm); next = 0; tomorrow = true;
        }
        int mins = (int) Math.round((t[next] + (tomorrow ? 24 : 0) - nowH) * 60);
        String in = c.getString(R.string.in_time, mins / 60, mins % 60);
        String city = c.getSharedPreferences("launcher", Context.MODE_PRIVATE).getString("city", c.getString(R.string.default_city));
        return new String[]{names[next] + " : " + PrayerTimes.fmt(t[next]), tomorrow ? c.getString(R.string.tomorrow) + " · " + in : in, city};
    }
}
