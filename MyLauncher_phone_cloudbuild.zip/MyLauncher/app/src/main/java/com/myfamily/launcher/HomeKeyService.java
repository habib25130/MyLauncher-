package com.myfamily.launcher;

import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import java.util.*;

/** زر Home يفتح هذا اللانشر دائمًا، حتى لو حاول التلفاز فتح لانشره الأصلي. يتطلب تفعيل الخدمة من «إمكانية الوصول». */
public class HomeKeyService extends AccessibilityService {
    // أنشطة الشاشة الرئيسية للتلفاز الأصلي (حزمة/نشاط) وليس الحزمة كاملة، حتى لا نلتقط شاشة الإعدادات
    private final Set<String> stockClasses = new HashSet<>();
    private long lastOpen = 0;
    /** الخدمة المتصلة حاليًا (تستعملها نافذة شريط الصلاة كتراكب بلا إذن إضافي). */
    static volatile HomeKeyService instance;
    private int swallow = -1;
    private long swallowAt;

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        loadStock();
    }

    @Override public boolean onUnbind(Intent i) { if (instance == this) instance = null; return super.onUnbind(i); }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    private static boolean isStopKey(int k) {
        return k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER
                || k == KeyEvent.KEYCODE_NUMPAD_ENTER || k == KeyEvent.KEYCODE_HOME || k == KeyEvent.KEYCODE_ESCAPE;
    }

    private static boolean isSettings(String pkg) {
        return pkg != null && pkg.toLowerCase(Locale.US).contains("settings");
    }

    private void loadStock() {
        stockClasses.clear();
        try {
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            for (ResolveInfo r : getPackageManager().queryIntentActivities(home, 0)) {
                String p = r.activityInfo.packageName;
                if (getPackageName().equals(p) || isSettings(p)) continue;
                stockClasses.add(p + "/" + r.activityInfo.name);
            }
        } catch (Exception ignored) { }
    }

    private void openMe() {
        long now = System.currentTimeMillis();
        if (now - lastOpen < 700) return;
        lastOpen = now;
        try {
            startActivity(new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        } catch (Exception ignored) { }
    }

    @Override public boolean onKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        long now = System.currentTimeMillis();
        // أثناء الأذان: OK/رجوع/Home توقفه فقط ويتابع الفيديو تحته (نبتلع الضغطة كلها حتى لا يتلقاها التطبيق أو اللانشر)
        if (swallow == code && now - swallowAt < 3000) { if (e.getAction() == KeyEvent.ACTION_UP) swallow = -1; return true; }
        if (AdhanService.active && e.getAction() == KeyEvent.ACTION_DOWN && isStopKey(code)) {
            swallow = code; swallowAt = now;
            Adhan.stop(this);
            return true;
        }
        if (e.getKeyCode() == KeyEvent.KEYCODE_HOME) {
            if (e.getAction() == KeyEvent.ACTION_UP) openMe();
            return true;
        }
        return false;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent ev) {
        if (ev == null || ev.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || ev.getPackageName() == null || ev.getClassName() == null) return;
        String pkg = ev.getPackageName().toString();
        if (isSettings(pkg)) return;
        if (stockClasses.isEmpty()) loadStock();
        if (stockClasses.contains(pkg + "/" + ev.getClassName())) openMe();
    }

    @Override public void onInterrupt() { }

    /** يفعّل الخدمة مباشرة إن مُنح WRITE_SECURE_SETTINGS عبر ADB. false إن لم يكن ذلك ممكنًا. */
    static boolean enableViaSecureSettings(Context c) {
        if (isEnabled(c)) return true;
        if (Build.VERSION.SDK_INT >= 23 && c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED) {
            try {
                String me = new ComponentName(c, HomeKeyService.class).flattenToString();
                String cur = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
                String all = (cur == null || cur.isEmpty()) ? me : (cur.contains(me) ? cur : cur + ":" + me);
                Settings.Secure.putString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, all);
                Settings.Secure.putInt(c.getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 1);
                return true;
            } catch (Exception ignored) { }
        }
        return false;
    }

    static boolean isEnabled(Context c) {
        try {
            String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (s == null) return false;
            for (String part : s.split(":")) {
                ComponentName cn = ComponentName.unflattenFromString(part);
                if (cn != null && cn.getPackageName().equals(c.getPackageName()) && cn.getClassName().endsWith("HomeKeyService")) return true;
            }
        } catch (Exception ignored) { }
        return false;
    }
}
