package com.myfamily.launcher;

import android.accessibilityservice.AccessibilityService;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * شريط الصلاة فوق أي تطبيق أو فيديو: شريط عند دخول الوقت (أثناء الأذان)، ثم شارة صغيرة اختيارية.
 * يُرسم كنافذة تراكب عبر خدمة إمكانية الوصول (بلا إذن إضافي) أو عبر إذن «العرض فوق التطبيقات».
 * النافذة لا تأخذ التركيز ولا اللمس، فلا تعطّل الفيديو الذي تحتها.
 *
 * الإعدادات (في إعدادات الأذان ← شريط التنبيه): الموضع، النوع (غليظ/نحيف/بدون شريط)، اللون، الخط، الحجم، الكتابة المضيئة.
 */
final class PrayerBanner {
    private static final long REMINDER_MS = 10 * 60_000L;
    private static PrayerBanner inst;
    static PrayerBanner get() { if (inst == null) inst = new PrayerBanner(); return inst; }

    /** {خلفية الشريط، الإطار، الجملة العليا، عنوان الصلاة، المدينة/الوسم، خلفية الشارة، نص الشارة، إطار الشارة} */
    static final int[][] THEMES = {
            {0xF2102447, 0xFFD9B75A, 0xFFFFFFFF, 0xFFFFD84A, 0xFFB9C7E6, 0xFF0F8F3C, 0xFFFFFFFF, 0xFF9BE8B4},   // كحلي وذهبي
            {0xF20B3D2E, 0xFFD9C27A, 0xFFFFFFFF, 0xFFFFE9A8, 0xFFBFE3CF, 0xFF1F9D55, 0xFFFFFFFF, 0xFFA8EBC4},   // أخضر زمردي
            {0xF2000000, 0xFFFFD84A, 0xFFFFFFFF, 0xFFFFD84A, 0xFFCCCCCC, 0xFF0F8F3C, 0xFFFFFFFF, 0xFF9BE8B4},   // أسود وذهبي
            {0xF2F7F1E1, 0xFF9A7B22, 0xFF1D2B3F, 0xFF8A5A00, 0xFF4A5A70, 0xFF1F7A45, 0xFFFFFFFF, 0xFF1F7A45}    // فاتح
    };
    private static final float[] SIZES = {0.85f, 1f, 1.2f};

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable hideRun = this::hide;
    private WindowManager wm;
    private View view;

    // ===================== من يرسم النافذة =====================
    /** خدمة إمكانية الوصول إن كانت مفعّلة، وإلا تطبيقنا إن مُنح إذن العرض فوق التطبيقات. */
    static Context host(Context c) {
        HomeKeyService s = HomeKeyService.instance;
        if (s != null) return s;
        Context a = c.getApplicationContext();
        try { if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(a)) return a; } catch (Exception ignored) { }
        return null;
    }

    boolean canShow(Context c) { return host(c) != null; }

    void showAlert(Context c, int k) { show(c, k, true, false); }

    void showReminder(Context c, int k) {
        show(c, k, false, false);
        h.removeCallbacks(hideRun);
        h.postDelayed(hideRun, REMINDER_MS);
    }

    /** معاينة صامتة: الشريط ست ثوانٍ ثم الشارة الصغيرة سبع ثوانٍ. */
    void preview(Context c) {
        final Context a = c.getApplicationContext();
        show(a, 1, true, true);                       // المعاينة تتجاهل مفتاح «إظهار الشريط»
        h.postDelayed(() -> { show(a, 1, false, true); h.removeCallbacks(hideRun); h.postDelayed(hideRun, 7000L); }, 6000L);
    }

    // ===================== معاينة داخل الشاشة الحالية =====================
    private View inView;

    /** عند تعذر التراكب (بلا خدمة زر Home ولا إذن): يعرض نفس الشريط داخل الشاشة المفتوحة لترى الأسلوب فقط. */
    void previewInActivity(final Activity a) {
        h.removeCallbacks(hideRun);
        removeView();
        removeIn();
        showIn(a, true);
        h.postDelayed(() -> { removeIn(); showIn(a, false); h.postDelayed(this::removeIn, 7000L); }, 6000L);
    }

    private void removeIn() {
        View v = inView; inView = null;
        if (v != null && v.getParent() instanceof ViewGroup) ((ViewGroup) v.getParent()).removeView(v);
    }

    private void showIn(Activity a, boolean big) {
        try {
            Style st = style(a);
            DisplayMetrics dm = a.getResources().getDisplayMetrics();
            float w = dm.widthPixels, hgt = dm.heightPixels;
            View v = big ? (st.type == 1 ? buildThin(a, 1, w, hgt, st) : buildBig(a, 1, w, hgt, st)) : buildSmall(a, 1, w, hgt, st);
            boolean wide = big && st.type != 1;
            int vert = st.pos == 1 ? Gravity.TOP : Gravity.BOTTOM;
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(wide ? Math.round(w * 0.96f) : -2, -2,
                    big ? (vert | Gravity.CENTER_HORIZONTAL) : (vert | Gravity.END));
            if (st.pos == 1) lp.topMargin = Math.round(hgt * 0.035f); else lp.bottomMargin = Math.round(hgt * 0.035f);
            if (!big) lp.setMarginEnd(Math.round(w * 0.025f));
            a.addContentView(v, lp);
            inView = v;
        } catch (Throwable ignored) { inView = null; }
    }

    void hide() {
        h.removeCallbacks(hideRun);
        removeView();
    }

    private void removeView() {
        View v = view; view = null;
        if (v != null && wm != null) { try { wm.removeViewImmediate(v); } catch (Exception ignored) { } }
    }

    // ===================== الخطوط =====================
    private static final Map<String, Typeface> CUSTOM = new HashMap<>();

    /** ملفات الخطوط الإضافية: assets/fonts/banner_*.ttf|otf (مثل banner_andalus.ttf). */
    private static List<String> customFonts(Context c) {
        List<String> out = new ArrayList<>();
        try {
            String[] all = c.getAssets().list("fonts");
            if (all != null) {
                Arrays.sort(all);
                for (String f : all) {
                    String l = f.toLowerCase();
                    if (l.startsWith("banner_") && (l.endsWith(".ttf") || l.endsWith(".otf"))) out.add(f);
                }
            }
        } catch (Exception ignored) { }
        return out;
    }

    /** أسماء الخطوط المعروضة في الإعدادات: افتراضي، Serif، Cursive، Casual، ثم الملفات الإضافية. */
    static String[] fontNames(Context c) {
        List<String> n = new ArrayList<>();
        n.add(c.getString(R.string.pb_font_default));
        n.add(c.getString(R.string.pb_font_serif));
        n.add(c.getString(R.string.pb_font_cursive));
        n.add(c.getString(R.string.pb_font_casual));
        for (String f : customFonts(c)) {
            String base = f.substring("banner_".length(), f.lastIndexOf('.'));
            n.add(base.isEmpty() ? f : Character.toUpperCase(base.charAt(0)) + base.substring(1));
        }
        return n.toArray(new String[0]);
    }

    private static Typeface font(Context c, int idx, boolean bold) {
        int style = bold ? Typeface.BOLD : Typeface.NORMAL;
        switch (idx) {
            case 1: return Typeface.create("serif", style);
            case 2: return Typeface.create("cursive", style);
            case 3: return Typeface.create("casual", style);
            case 0: return bold ? Fonts.bold(c) : Fonts.outfit(c);
            default: break;
        }
        List<String> cf = customFonts(c);
        int i = idx - 4;
        if (i >= 0 && i < cf.size()) {
            String name = cf.get(i);
            try {
                Typeface t = CUSTOM.get(name);
                if (t == null) { t = Typeface.createFromAsset(c.getAssets(), "fonts/" + name); CUSTOM.put(name, t); }
                return bold ? Typeface.create(t, Typeface.BOLD) : t;
            } catch (Exception ignored) { }
        }
        return bold ? Fonts.bold(c) : Fonts.outfit(c);
    }

    // ===================== الأسلوب =====================
    private static final class Style {
        int pos, type, color, size; boolean glow;
        Typeface reg, bold; float scale; int[] th;
    }

    private static Style style(Context c) {
        SharedPreferences p = Adhan.p(c);
        Style s = new Style();
        s.pos = Math.max(0, Math.min(1, p.getInt("adhan_bn_pos", 0)));
        s.type = Math.max(0, Math.min(2, p.getInt("adhan_bn_type", 0)));
        s.color = Math.max(0, Math.min(THEMES.length - 1, p.getInt("adhan_bn_color", 0)));
        s.size = Math.max(0, Math.min(SIZES.length - 1, p.getInt("adhan_bn_size", 1)));
        s.glow = p.getBoolean("adhan_bn_glow", false);
        int fi = p.getInt("adhan_bn_font", 0);
        if (fi < 0 || fi >= fontNames(c).length) fi = 0;
        s.reg = font(c, fi, false); s.bold = font(c, fi, true);
        s.scale = SIZES[s.size];
        // بلا شريط: النص فوق الفيديو مباشرة، فنستعمل ألواناً فاتحة حتى مع اللون «الفاتح»
        s.th = THEMES[(s.type == 2 && s.color == 3) ? 0 : s.color];
        return s;
    }

    @SuppressWarnings("deprecation")
    private void show(Context c, int k, boolean big, boolean force) {
        h.removeCallbacks(hideRun);
        removeView();
        if (!force && !Adhan.p(c).getBoolean("adhan_banner", true)) return;
        Context host = host(c);
        if (host == null) return;
        try {
            Context lc = LocaleHelper.wrap(host);
            Style st = style(lc);
            DisplayMetrics dm = host.getResources().getDisplayMetrics();
            float w = dm.widthPixels, hgt = dm.heightPixels;
            wm = (WindowManager) host.getSystemService(Context.WINDOW_SERVICE);
            View v = big ? (st.type == 1 ? buildThin(lc, k, w, hgt, st) : buildBig(lc, k, w, hgt, st)) : buildSmall(lc, k, w, hgt, st);
            int type = host instanceof AccessibilityService ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                    : (Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE);
            boolean wide = big && st.type != 1;
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(wide ? Math.round(w * 0.96f) : -2, -2, type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
            int vert = st.pos == 1 ? Gravity.TOP : Gravity.BOTTOM;
            lp.gravity = big ? (vert | Gravity.CENTER_HORIZONTAL) : (vert | Gravity.END);
            lp.y = Math.round(hgt * 0.035f);
            lp.x = big ? 0 : Math.round(w * 0.025f);
            v.setAlpha(0f);
            wm.addView(v, lp);
            view = v;
            v.animate().alpha(1f).setDuration(250).start();
        } catch (Throwable t) { view = null; }
    }

    // ===================== النصوص =====================
    private static String prayerName(Context c, int k) { return k == 1 ? PrayerInfo.dhuhrName(c) : Adhan.prayers(c)[k]; }

    private static String cityName(Context c) {
        String city = Adhan.p(c).getString("city", c.getString(R.string.default_city));
        int i = city.indexOf("·");
        return (i > 0 ? city.substring(0, i) : city).trim();
    }

    private static TextView tv(Context c, Typeface f, float px, int color) {
        OutlineText t = new OutlineText(c);
        t.setTypeface(f); t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setIncludeFontPadding(false);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        return t;
    }

    /** إضاءة الكتابة (ظل بلون النص) وحدّ أسود رقيق عند عدم وجود شريط لتبقى واضحة فوق الفيديو. */
    private static void fx(TextView t, Style st, float hgt) {
        boolean none = st.type == 2;
        if (none && t instanceof OutlineText) ((OutlineText) t).setOutline(Math.max(2f, hgt * 0.0035f), 0xE6000000);
        if (st.glow) t.setShadowLayer(hgt * 0.016f, 0f, 0f, t.getCurrentTextColor());
        else if (none) t.setShadowLayer(hgt * 0.006f, 0f, hgt * 0.003f, 0xCC000000);
    }

    private static GradientDrawable barBg(Style st, float hgt, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(st.th[0]); g.setCornerRadius(radius);
        g.setStroke(Math.max(2, Math.round(hgt * 0.003f)), st.th[1]);
        return g;
    }

    // ===================== الشريط الغليظ / بدون شريط =====================
    private View buildBig(Context c, int k, float w, float hgt, Style st) {
        boolean none = st.type == 2;
        float s = st.scale;
        int[] th = st.th;
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        int padH = Math.round(w * 0.02f), padV = Math.round(hgt * 0.02f);
        bar.setPadding(padH, padV, padH, padV);
        if (!none) bar.setBackground(barBg(st, hgt, hgt * 0.035f));

        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER_HORIZONTAL);
        String[] verses = {c.getString(R.string.pb_verse0), c.getString(R.string.pb_verse1), c.getString(R.string.pb_verse2)};
        int vi = (Calendar.getInstance().get(Calendar.DAY_OF_YEAR) + k) % verses.length;
        TextView verse = tv(c, st.bold, hgt * 0.034f * s, th[2]); verse.setText(verses[vi]); fx(verse, st, hgt);
        TextView title = tv(c, st.bold, hgt * 0.046f * s, th[3]); title.setText(c.getString(R.string.pb_title, prayerName(c, k))); fx(title, st, hgt);
        TextView city = tv(c, st.reg, hgt * 0.027f * s, th[4]); city.setText(c.getString(R.string.pb_city, cityName(c))); fx(city, st, hgt);
        mid.addView(verse); mid.addView(title); mid.addView(city);

        if (none) {                                           // نص فقط في الوسط
            bar.setGravity(Gravity.CENTER);
            bar.addView(mid, new LinearLayout.LayoutParams(-1, -2));
            return bar;
        }

        LinearLayout left = new LinearLayout(c);
        left.setGravity(Gravity.CENTER_VERTICAL);
        int cs = Math.round(hgt * 0.07f * s);
        left.addView(new Crescent(c), new LinearLayout.LayoutParams(cs, cs));
        TextView tag = tv(c, st.reg, hgt * 0.027f * s, th[3]);
        tag.setText(c.getString(R.string.pb_tag)); fx(tag, st, hgt);
        LinearLayout.LayoutParams tgl = new LinearLayout.LayoutParams(-2, -2); tgl.setMarginStart(Math.round(w * 0.006f));
        left.addView(tag, tgl);
        bar.addView(left, new LinearLayout.LayoutParams(-2, -2));

        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(0, -2, 1f);
        ml.setMarginStart(Math.round(w * 0.012f)); ml.setMarginEnd(Math.round(w * 0.012f));
        bar.addView(mid, ml);

        TextView pill = tv(c, st.bold, hgt * 0.027f * s, th[6]);
        pill.setText(c.getString(R.string.pb_pill));
        pill.setPadding(Math.round(w * 0.014f), Math.round(hgt * 0.012f), Math.round(w * 0.014f), Math.round(hgt * 0.012f));
        GradientDrawable pg = new GradientDrawable();
        pg.setColor(th[5]); pg.setCornerRadius(hgt * 0.04f); pg.setStroke(Math.max(1, Math.round(hgt * 0.002f)), th[7]);
        pill.setBackground(pg);
        bar.addView(pill, new LinearLayout.LayoutParams(-2, -2));
        return bar;
    }

    // ===================== الشريط النحيف: سطر واحد =====================
    private View buildThin(Context c, int k, float w, float hgt, Style st) {
        float s = st.scale;
        int[] th = st.th;
        LinearLayout bar = new LinearLayout(c);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        bar.setPadding(Math.round(w * 0.014f), Math.round(hgt * 0.009f), Math.round(w * 0.016f), Math.round(hgt * 0.009f));
        bar.setBackground(barBg(st, hgt, hgt * 0.03f));
        int cs = Math.round(hgt * 0.045f * s);
        bar.addView(new Crescent(c), new LinearLayout.LayoutParams(cs, cs));
        TextView title = tv(c, st.bold, hgt * 0.032f * s, th[3]); title.setText(c.getString(R.string.pb_title, prayerName(c, k))); fx(title, st, hgt);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2); tl.setMarginStart(Math.round(w * 0.008f));
        bar.addView(title, tl);
        TextView city = tv(c, st.reg, hgt * 0.024f * s, th[4]); city.setText("·  " + cityName(c)); fx(city, st, hgt);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2); cl.setMarginStart(Math.round(w * 0.008f));
        bar.addView(city, cl);
        return bar;
    }

    // ===================== الشارة الصغيرة بعد الأذان =====================
    private View buildSmall(Context c, int k, float w, float hgt, Style st) {
        boolean none = st.type == 2;
        float s = st.scale;
        int[] th = st.th;
        Adhan.load(c);
        String tm = "";
        try { tm = PrayerTimes.fmt(PrayerTimes.compute(Calendar.getInstance(PrayerTimes.TZ))[Adhan.TIME_INDEX[k]]); } catch (Exception ignored) { }
        LinearLayout box = new LinearLayout(c);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        box.setPadding(Math.round(w * 0.010f), Math.round(hgt * 0.008f), Math.round(w * 0.014f), Math.round(hgt * 0.008f));
        if (!none) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(th[0]); g.setCornerRadius(hgt * 0.03f);
            g.setStroke(Math.max(1, Math.round(hgt * 0.0025f)), th[1]);
            box.setBackground(g);
        }
        int cs = Math.round(hgt * 0.045f * s);
        box.addView(new Crescent(c), new LinearLayout.LayoutParams(cs, cs));
        TextView t = tv(c, st.bold, hgt * 0.026f * s, th[3]);
        t.setText(c.getString(R.string.pb_small, prayerName(c, k), tm)); fx(t, st, hgt);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2); tl.setMarginStart(Math.round(w * 0.006f));
        box.addView(t, tl);
        return box;
    }

    /** هلال ذهبي صغير. */
    private static final class Crescent extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        Crescent(Context c) { super(c); p.setColor(0xFFFFD66B); }
        @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
            float r = Math.min(w, h) * 0.46f, cx = w * 0.5f, cy = h * 0.5f;
            path.reset();
            path.addCircle(cx, cy, r, Path.Direction.CW);
            Path cut = new Path();
            cut.addCircle(cx + r * 0.42f, cy - r * 0.12f, r * 0.82f, Path.Direction.CW);
            path.op(cut, Path.Op.DIFFERENCE);
        }
        @Override protected void onDraw(Canvas cv) { cv.drawPath(path, p); }
    }
}
