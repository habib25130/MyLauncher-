package com.myfamily.launcher;

import java.io.*;
import java.net.*;
import java.util.*;

/** خادم HTTP صغير على الشبكة المحلية لاستقبال الصور من الهاتف. الرابط يحوي رمزًا عشوائيًا، ويعمل فقط أثناء فتح نافذة QR. */
final class UploadServer {
    interface Receiver { boolean onFile(File tmp); }

    final String code;
    private final File tmpDir;
    private final Receiver receiver;
    private ServerSocket ss;
    private volatile boolean running;

    private final boolean keyMode;
    private volatile boolean msgMode;
    /** صفحة إرسال رسالة ترحيب (نص + وقت + لغة) بدل الصور. */
    void setMessageMode() { msgMode = true; }
    private String keyTitle = "API-Football";
    void setKeyTitle(String t) { keyTitle = t; }

    UploadServer(File tmpDir, Receiver r) throws IOException { this(tmpDir, r, false); }

    /** keyMode = صفحة صغيرة لإرسال نص (مفتاح API) بدل الصور. */
    UploadServer(File tmpDir, Receiver r, boolean keyMode) throws IOException {
        this.keyMode = keyMode;
        this.tmpDir = tmpDir; this.receiver = r;
        tmpDir.mkdirs();
        String al = "abcdefghjkmnpqrstuvwxyz23456789";
        Random rnd = new java.security.SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) sb.append(al.charAt(rnd.nextInt(al.length())));
        code = sb.toString();
        try { ss = new ServerSocket(8080); } catch (IOException e) { ss = new ServerSocket(0); }
    }

    int port() { return ss.getLocalPort(); }

    void start() {
        running = true;
        new Thread(() -> {
            while (running) {
                try { final Socket s = ss.accept(); new Thread(() -> handle(s)).start(); }
                catch (IOException e) { if (!running) break; }
            }
        }).start();
    }

    void stop() { running = false; try { ss.close(); } catch (IOException ignored) { } }

    static String localIp() {
        String best = null;
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) {
                        String n = ni.getName();
                        if (n.startsWith("wlan") || n.startsWith("eth")) return a.getHostAddress();
                        if (best == null) best = a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) { }
        return best;
    }

    private void handle(Socket s) {
        try {
            s.setSoTimeout(20000);
            InputStream in = new BufferedInputStream(s.getInputStream());
            OutputStream out = s.getOutputStream();
            String line = readLine(in);
            if (line == null) { s.close(); return; }
            String[] rl = line.split(" ");
            long len = -1; String h;
            while ((h = readLine(in)) != null && !h.isEmpty()) {
                if (h.toLowerCase(Locale.US).startsWith("content-length:")) len = Long.parseLong(h.substring(15).trim());
            }
            String method = rl[0], path = rl.length > 1 ? rl[1] : "/";
            if (method.equals("GET") && path.equals("/" + code)) {
                reply(out, 200, "text/html; charset=utf-8", (msgMode ? MSG_PAGE : keyMode ? KEY_PAGE : PAGE).replace("@CODE@", code).replace("@TITLE@", keyTitle).getBytes("UTF-8"));
            } else if (method.equals("POST") && path.equals("/" + code + "/up") && len > 0 && len < ((keyMode || msgMode) ? 1024L : 60L * 1024 * 1024)) {
                File tmp = File.createTempFile("upl", ".bin", tmpDir);
                try (OutputStream fo = new FileOutputStream(tmp)) {
                    byte[] buf = new byte[1 << 16]; long left = len;
                    while (left > 0) { int n = in.read(buf, 0, (int) Math.min(buf.length, left)); if (n < 0) break; fo.write(buf, 0, n); left -= n; }
                }
                boolean ok = false;
                try { ok = receiver.onFile(tmp); } catch (Throwable ignored) { }
                tmp.delete();
                reply(out, ok ? 200 : 500, "text/plain", (ok ? "ok" : "fail").getBytes());
            } else reply(out, 404, "text/plain", "not found".getBytes());
        } catch (Exception e) {
            try { reply(s.getOutputStream(), 500, "text/plain", "fail".getBytes()); } catch (Exception ignored) { }
        }
        try { s.close(); } catch (IOException ignored) { }
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder(); int c;
        while ((c = in.read()) >= 0) { if (c == '\n') break; if (c != '\r') sb.append((char) c); if (sb.length() > 8192) break; }
        return (c < 0 && sb.length() == 0) ? null : sb.toString();
    }

    private static void reply(OutputStream out, int code, String type, byte[] body) throws IOException {
        String head = "HTTP/1.1 " + code + (code == 200 ? " OK" : " Error") + "\r\nContent-Type: " + type
                + "\r\nContent-Length: " + body.length + "\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n";
        out.write(head.getBytes("UTF-8")); out.write(body); out.flush();
    }

    private static final String PAGE = "<!doctype html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
            + "<title>TV</title><style>body{font-family:sans-serif;background:#0b1626;color:#fff;text-align:center;padding:28px}"
            + "label{display:block;background:#1e6fb0;border-radius:18px;padding:22px;font-size:20px;margin:18px 0}"
            + "#s{font-size:18px;line-height:1.8;color:#7fe0c8}input{display:none}</style></head><body>"
            + "<h2>📺 إرسال صور إلى التلفاز / Send photos to TV</h2>"
            + "<label><input id=f type=file accept='image/*' multiple>اختر الصور · Choose photos</label><div id=s></div>"
            + "<script>var f=document.getElementById('f'),s=document.getElementById('s');f.onchange=async function(){var ok=0,n=f.files.length;"
            + "for(var i=0;i<n;i++){s.textContent=(i+1)+' / '+n+' …';try{var r=await fetch('/@CODE@/up',{method:'POST',body:f.files[i]});if(r.ok)ok++}catch(e){}}"
            + "s.textContent='✅ '+ok+' / '+n;f.value=''}</script></body></html>";

    private static final String KEY_PAGE = "<!doctype html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
            + "<title>TV</title><style>body{font-family:sans-serif;background:#0b1626;color:#fff;text-align:center;padding:28px}"
            + "input{width:92%;font-size:20px;padding:16px;border-radius:14px;border:0;margin:18px 0;box-sizing:border-box}"
            + "button{background:#1e6fb0;color:#fff;border:0;border-radius:18px;padding:18px 40px;font-size:20px}#s{font-size:18px;margin-top:18px;color:#7fe0c8}</style></head><body>"
            + "<h2>🔑 @TITLE@</h2>"
            + "<input id=k placeholder='API key' autocapitalize=off autocomplete=off spellcheck=false><br><button id=b>إرسال · Send</button><div id=s></div>"
            + "<script>var k=document.getElementById('k'),s=document.getElementById('s');document.getElementById('b').onclick=async function(){"
            + "var v=k.value.trim();if(!v)return;s.textContent='…';try{var r=await fetch('/@CODE@/up',{method:'POST',body:v});"
            + "s.textContent=r.ok?'✅ OK':'❌ مفتاح غير صالح / Invalid key';if(r.ok)k.value=''}catch(e){s.textContent='❌'}}</script></body></html>";

    private static final String MSG_PAGE = "<!doctype html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
            + "<title>TV</title><style>body{font-family:sans-serif;background:#0b1626;color:#fff;text-align:center;padding:24px}"
            + "textarea,select{width:92%;font-size:20px;padding:14px;border-radius:14px;border:0;margin:10px 0;box-sizing:border-box}"
            + "button{background:#1e6fb0;color:#fff;border:0;border-radius:18px;padding:18px 40px;font-size:20px;margin-top:10px}#s{font-size:18px;margin-top:16px;color:#7fe0c8}</style></head><body>"
            + "<h2>💬 رسالة ترحيب · Greeting message</h2>"
            + "<textarea id=m rows=3 maxlength=80 placeholder='اكتب الرسالة · Type the message'></textarea>"
            + "<select id=p><option value=0>كل الأوقات · Any time</option><option value=1>صباحاً · Morning</option><option value=2>مساءً · Evening</option><option value=3>ليلاً · Night</option><option value=4>الجمعة · Friday</option></select>"
            + "<select id=l><option value=''>كل اللغات · All languages</option><option value=ar>العربية</option><option value=fr>Français</option><option value=en>English</option></select><br>"
            + "<button id=b>إرسال · Send</button><div id=s></div>"
            + "<script>var m=document.getElementById('m'),p=document.getElementById('p'),l=document.getElementById('l'),s=document.getElementById('s');"
            + "document.getElementById('b').onclick=async function(){var v=m.value.replace(/[\\r\\n|]+/g,' ').trim();if(!v)return;s.textContent='…';"
            + "try{var r=await fetch('/@CODE@/up',{method:'POST',body:p.value+'|'+l.value+'|'+v});"
            + "s.textContent=r.ok?'✅ تمت الإضافة · Added':'❌ لم تُحفظ (ممتلئة؟) · Not saved (full?)';if(r.ok)m.value=''}catch(e){s.textContent='❌'}}</script></body></html>";
}
