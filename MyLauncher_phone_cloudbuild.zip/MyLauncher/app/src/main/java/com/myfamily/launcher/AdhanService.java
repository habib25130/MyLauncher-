package com.myfamily.launcher;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.view.KeyEvent;

/**
 * يشغّل الأذان: يعرض شريط الصلاة فوق أي تطبيق، ويطلب من التطبيقات الأخرى التوقف مؤقتًا (تركيز صوتي + مفتاح إيقاف
 * للتطبيقات التي تتجاهل التركيز)، ثم يستأنفها بعد الأذان إن كانت تعمل قبله. بعد الأذان يتحول الشريط إلى شارة صغيرة اختيارية.
 */
public class AdhanService extends Service {
    /** true أثناء الأذان؛ تقرؤها خدمة زر Home والشاشة الرئيسية لإيقافه بـ OK/رجوع/Home. */
    static volatile boolean active;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private final Handler h = new Handler(Looper.getMainLooper());
    private MediaPlayer mp;
    private AudioManager am;
    private AudioFocusRequest focusReq;
    private boolean hasFocus, resumeOthers, test;
    private final AudioManager.OnAudioFocusChangeListener focusListener = change -> { };   // لا نتفاعل مع فقدان التركيز: الأذان قصير
    private int prayerK = 1;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        startFg();
        h.removeCallbacksAndMessages(null);
        release();
        abandonFocus();
        active = true;
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        int mode = i != null ? i.getIntExtra("mode", 1) : 1;
        int k = i != null ? i.getIntExtra("k", -1) : -1;
        test = k < 0;
        prayerK = k >= 0 ? k : 1;

        PrayerBanner.get().showAlert(getApplicationContext(), prayerK);

        RadioPlayer rp = RadioPlayer.get(this);
        boolean radioWas = rp.state() == RadioPlayer.State.LOADING || rp.state() == RadioPlayer.State.PLAYING;
        rp.stop();                                   // الأذان أولاً: أوقف الراديو إن كان يعمل

        boolean pauseOthers = Adhan.p(this).getBoolean("adhan_pause", true);
        boolean wasActive = pauseOthers && !radioWas && am != null && am.isMusicActive();   // فيديو/صوت يعمل في تطبيق آخر
        resumeOthers = wasActive;
        if (pauseOthers) requestFocus();
        final int m = mode;
        if (wasActive) {
            // نمنح التطبيقات المطيعة وقتًا لتتوقف بالتركيز الصوتي، ومن بقي يعمل نرسل له مفتاح الإيقاف
            h.postDelayed(() -> { if (am != null && am.isMusicActive()) sendKey(am, KeyEvent.KEYCODE_MEDIA_PAUSE); }, 400L);
            h.postDelayed(() -> startPlayer(m), 750L);
        } else startPlayer(m);
        return START_NOT_STICKY;
    }

    private void startPlayer(int mode) {
        release();
        try {
            Uri uri;
            int raw = getResources().getIdentifier("adhan", "raw", getPackageName());
            if (mode == 2) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            else if (Adhan.source(this) == 0 && raw != 0) uri = Uri.parse("android.resource://" + getPackageName() + "/" + raw);
            else uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mp.setDataSource(this, uri);
            float v = Adhan.volume(this) / 100f;
            mp.setVolume(v, v);
            mp.setOnCompletionListener(x -> stopSelf());
            mp.setOnErrorListener((x, w, e) -> { stopSelf(); return true; });
            mp.setOnPreparedListener(MediaPlayer::start);
            mp.prepareAsync();
        } catch (Exception e) { stopSelf(); }
    }

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel("adhan", getString(R.string.adhan_channel), NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, "adhan");
        } else b = new Notification.Builder(this);
        Notification n = b.setSmallIcon(R.drawable.icon).setContentTitle(getString(R.string.adhan_notif_title)).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(1, n);
    }

    // ===================== التركيز الصوتي ومفاتيح الوسائط =====================
    @SuppressWarnings("deprecation")
    private void requestFocus() {
        if (am == null || hasFocus) return;
        int r;
        if (Build.VERSION.SDK_INT >= 26) {
            focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setOnAudioFocusChangeListener(focusListener, h).build();
            r = am.requestAudioFocus(focusReq);
        } else {
            r = am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
        }
        hasFocus = r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    }

    @SuppressWarnings("deprecation")
    private void abandonFocus() {
        if (am == null || !hasFocus) return;
        if (Build.VERSION.SDK_INT >= 26) { if (focusReq != null) am.abandonAudioFocusRequest(focusReq); }
        else am.abandonAudioFocus(focusListener);
        hasFocus = false;
    }

    private static void sendKey(AudioManager a, int code) {
        try {
            a.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
            a.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
        } catch (Exception ignored) { }
    }

    private void release() { if (mp != null) { try { mp.release(); } catch (Exception ignored) { } mp = null; } }

    @Override public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        release();
        abandonFocus();
        active = false;
        final Context app = getApplicationContext();
        if (resumeOthers && am != null) {
            final AudioManager a = am;
            // يُستأنف فقط ما كان يعمل قبل الأذان، وفقط إن لم يستأنف نفسه بالتركيز الصوتي
            MAIN.postDelayed(() -> { try { if (!a.isMusicActive()) sendKey(a, KeyEvent.KEYCODE_MEDIA_PLAY); } catch (Exception ignored) { } }, 700L);
        }
        if (!test && Adhan.p(app).getBoolean("adhan_reminder", true)) PrayerBanner.get().showReminder(app, prayerK);
        else PrayerBanner.get().hide();
        super.onDestroy();
    }
}
