package com.myfamily.launcher

import java.time.Instant
import java.util.Locale

/**
 * جسر بين بيانات API-Football (Football.M) وخوارزمية SmartMatchAlgorithm الأصلية.
 * لا يغيّر أي نقاط أو قواعد: يترجم فقط المعرّفات والحالات والأدوار إلى ما تفهمه الخوارزمية،
 * ثم يعيد نفس كائنات Football.M التي اختارتها الخوارزمية (بعد وسم حالتها في الحقل smart).
 *
 * لا يلمس أي شيء من Android ولا من حالة Football الساكنة، فيمكن اختباره على JVM.
 */
object SmartMatchBridge {

    /** حدّ عمر المباراة المباشرة (قاعدة 7) — مصدره الخوارزمية نفسها. */
    @JvmField
    val MAX_LIVE_AGE_MS: Long = SmartMatchAlgorithm.MAX_LIVE_AGE.toMillis()

    /**
     * معرّفات الفرق في API-Football (نفس أرقام media.api-sports.io/football/teams/<id>.png).
     * هذه معرّفات حقيقية، وليست المعرّفات التجريبية (1..17) الموجودة في الاختبارات.
     */
    private val TEAM_IDS: Map<String, Int> = mapOf(
        "REAL_MADRID" to 541, "BARCELONA" to 529, "ATLETICO_MADRID" to 530,
        "LIVERPOOL" to 40, "MAN_CITY" to 50, "MAN_UTD" to 33,
        "ARSENAL" to 42, "CHELSEA" to 49, "TOTTENHAM" to 47,
        "BAYERN" to 157, "DORTMUND" to 165, "PSG" to 85,
        "MARSEILLE" to 81, "AC_MILAN" to 489, "INTER" to 505,
        "JUVENTUS" to 496, "ROMA" to 497
    )

    /** معرّفات البطولات في API-Football مع الاسم المعتمد في الخوارزمية. */
    private val LEAGUE_NAMES: Map<Int, String> = mapOf(
        2 to "UEFA Champions League",
        1 to "FIFA World Cup",
        6 to "Africa Cup of Nations",
        4 to "UEFA Euro / Major Tournaments",
        39 to "Premier League",
        140 to "La Liga",
        61 to "Ligue 1",
        135 to "Serie A",
        78 to "Bundesliga"
    )

    private val teams = SmartMatchAlgorithm.TeamCatalog(teamIds = TEAM_IDS)

    /**
     * قوائم المتابعة الفعلية للتطبيق تُقرأ من FootballConfig (المصدر الوحيد، بلا نسخة مكررة هنا).
     * تُقرأ عند كل اختيار، فإن صارت ديناميكية لاحقًا لا يلزم تعديل الجسر.
     */
    private fun follow() = SmartMatchAlgorithm.FollowCatalog(
        leagueIds = FootballConfig.LEAGUES.toSet(),
        teamIds = FootballConfig.TEAMS.toSet()
    )

    // نفس ترتيب أولوية البطولات في TournamentCatalog الافتراضي (1..9)، لكن بالمعرّف.
    private val tournaments = SmartMatchAlgorithm.TournamentCatalog(
        majorIds = setOf(2, 1, 6, 4),
        priorityById = mapOf(2 to 1, 1 to 2, 6 to 3, 4 to 4, 39 to 5, 140 to 6, 61 to 7, 135 to 8, 78 to 9)
    )

    /** رمز حالة API-Football → القيم التي تعرفها الخوارزمية. null = لم تبدأ (يُحسم بالوقت). */
    internal fun apiStatus(short: String?): String? = when (short.orEmpty().trim().uppercase(Locale.ROOT)) {
        "1H", "2H", "HT", "ET", "BT", "P", "LIVE" -> "live"
        "FT", "AET", "PEN" -> "finished"
        "PST" -> "postponed"
        "CANC", "ABD", "AWD", "WO" -> "cancelled"   // لا تُلعب: خارج الاختيار
        "SUSP", "INT" -> "suspended"
        else -> null                                  // NS, TBD, ...
    }

    /**
     * league.round في API-Football → matchType.
     * النهائي = "final". أي دور إقصائي آخر = "knockout" (فتأخذ دوري الأبطال 90 والبقية 85 كما في الخوارزمية).
     * التصفيات التمهيدية ومباراة المركز الثالث ومراحل المجموعات = "normal".
     */
    internal fun matchType(round: String?): String {
        val r = round.orEmpty().trim().lowercase(Locale.ROOT)
        if (r.isEmpty()) return "normal"
        if ("qualifying" in r || "preliminary" in r || "3rd place" in r || "third place" in r) return "normal"
        if (r == "final") return "final"
        if ("round of" in r || "finals" in r || "quarter" in r || "semi" in r ||
            "play-off" in r || "playoff" in r || "knockout" in r
        ) return "knockout"
        return "normal"
    }

    private fun toMatch(m: Football.M): SmartMatchAlgorithm.Match {
        val name = LEAGUE_NAMES[m.leagueId] ?: m.league
        return SmartMatchAlgorithm.Match(
            homeTeamId = m.homeId.takeIf { it > 0 },
            awayTeamId = m.awayId.takeIf { it > 0 },
            tournamentId = m.leagueId.takeIf { it > 0 },
            tournamentName = name,
            matchType = matchType(m.round),
            importance = null,   // API-Football لا يوفّر "أهمية المباراة"؛ لا نخترعها
            startTime = Instant.ofEpochSecond(m.ts),
            status = apiStatus(m.st),
            homeScore = m.hg.takeIf { it >= 0 },
            awayScore = m.ag.takeIf { it >= 0 },
            minute = if (m.el >= 0) "${m.el}'" else null,
            providerMatchId = m.id.takeIf { it > 0 }?.toString()
        )
    }

    /** هل تستحق المباراة الدخول في الاختيار الذكي أصلًا (A أو B أو C)؟ تُستخدم لتصفية ما يُخزَّن من الـ API. */
    @JvmStatic
    fun isSmartCandidate(m: Football.M): Boolean =
        SmartMatchAlgorithm.evaluateMatch(toMatch(m), teams, tournaments) != null

    /** اختيار الخوارزمية الكامل: مباريات اليوم، وإن لم توجد مناسبة فالغد (قاعدة 6). */
    @JvmStatic
    fun select(all: List<Football.M>, nowMillis: Long): List<Football.M> =
        runSelection(all) { matches ->
            SmartMatchAlgorithm.selectTopSmartMatches(matches, Instant.ofEpochMilli(nowMillis), teams, tournaments, follow())
        }

    /** اختيار اليوم فقط (بتوقيت الجزائر) — لمعرفة هل نحتاج جلب بيانات الغد. */
    @JvmStatic
    fun selectToday(all: List<Football.M>, nowMillis: Long): List<Football.M> =
        runSelection(all) { matches ->
            val now = Instant.ofEpochMilli(nowMillis)
            val today = now.atZone(SmartMatchAlgorithm.ALGIERS_TZ).toLocalDate()
            SmartMatchAlgorithm.rankAndSelect(matches, now, today, teams, tournaments, follow())
        }

    private fun runSelection(
        all: List<Football.M>,
        choose: (List<SmartMatchAlgorithm.Match>) -> List<SmartMatchAlgorithm.RankedMatch>
    ): List<Football.M> {
        val byId = LinkedHashMap<String, Football.M>()
        for (m in all) if (m.id > 0) byId.putIfAbsent(m.id.toString(), m)
        val ranked = choose(byId.values.map(::toMatch))
        return ranked.mapNotNull { r ->
            r.match.providerMatchId?.let { byId[it] }?.also { it.smart = r.state.name }
        }
    }
}
