package com.myfamily.launcher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Duration
import java.time.Instant
import java.time.LocalDate

/** اختبارات الفئة D فقط. اختبارات الخوارزمية الأصلية في SmartMatchAlgorithmTest بلا أي تعديل. */
class SmartMatchCategoryDTest {
    private val now = Instant.parse("2026-10-24T08:00:00Z")
    private val today = LocalDate.of(2026, 10, 24)

    // معرّفات تجريبية فقط (نفس أسلوب الاختبارات الأصلية)
    private val teams = SmartMatchAlgorithm.TeamCatalog(
        mapOf(
            "REAL_MADRID" to 1, "BARCELONA" to 2, "ATLETICO_MADRID" to 3,
            "LIVERPOOL" to 4, "MAN_CITY" to 5, "MAN_UTD" to 6,
            "ARSENAL" to 7, "CHELSEA" to 8, "TOTTENHAM" to 9,
            "BAYERN" to 10, "DORTMUND" to 11, "PSG" to 12
        )
    )
    private val tournaments = SmartMatchAlgorithm.TournamentCatalog(
        majorNames = setOf("UEFA Champions League", "FIFA World Cup", "Africa Cup of Nations"),
        priorityByName = mapOf(
            "UEFA Champions League" to 1, "FIFA World Cup" to 2, "Africa Cup of Nations" to 3,
            "Premier League" to 5, "La Liga" to 6
        )
    )
    private val ucl = "UEFA Champions League"

    private fun match(
        home: Int, away: Int,
        start: Instant = now.plus(Duration.ofHours(1)),
        tournament: String = "Premier League",
        status: String? = null,
        importance: String? = null,
        id: String? = null
    ) = SmartMatchAlgorithm.Match(
        homeTeamId = home, awayTeamId = away, tournamentName = tournament,
        matchType = "normal", importance = importance, startTime = start,
        status = status, providerMatchId = id
    )

    private fun select(matches: List<SmartMatchAlgorithm.Match>) =
        SmartMatchAlgorithm.rankAndSelect(matches, now, today, teams, tournaments)

    @Test
    fun oneBigTeamInMajorTournamentIsCategoryDNotA() {
        val result = SmartMatchAlgorithm.evaluateMatch(match(1, 99, tournament = ucl), teams, tournaments)
        assertEquals("الفئة D", result?.first)
        assertEquals(55, result?.second)
    }

    @Test
    fun categoryDScoreIs50ForLowerPriorityMajorTournament() {
        val result = SmartMatchAlgorithm.evaluateMatch(
            match(1, 99, tournament = "Africa Cup of Nations"), teams, tournaments
        )
        assertEquals("الفئة D", result?.first)
        assertEquals(50, result?.second)
    }

    @Test
    fun bigTeamInDomesticLeagueIsStillNotSelected() {
        assertNull(SmartMatchAlgorithm.evaluateMatch(match(4, 99), teams, tournaments))
    }

    @Test
    fun aBCAreNotAffectedByD() {
        assertEquals("الفئة B", SmartMatchAlgorithm.evaluateMatch(match(7, 11, tournament = ucl), teams, tournaments)?.first)
        assertEquals(
            "الفئة C",
            SmartMatchAlgorithm.evaluateMatch(match(1, 99, tournament = ucl, importance = "qualification"), teams, tournaments)?.first
        )
        assertEquals("الفئة A", SmartMatchAlgorithm.evaluateMatch(match(1, 2, tournament = ucl), teams, tournaments)?.first)
    }

    @Test
    fun categoryDFillsSelectionAfterB() {
        val arsenalDortmund = match(7, 11, tournament = ucl, id = "b")
        val realPsv = match(1, 99, tournament = ucl, id = "d1")
        val cityNapoli = match(5, 98, tournament = ucl, id = "d2")
        val result = select(listOf(realPsv, cityNapoli, arsenalDortmund))
        assertEquals(3, result.size)
        assertEquals("b", result[0].match.providerMatchId)
        assertEquals(setOf("d1", "d2"), result.drop(1).map { it.match.providerMatchId }.toSet())
    }

    @Test
    fun simultaneousCategoryDMatchesAreBothKept() {
        val result = select(listOf(match(1, 99, tournament = ucl), match(5, 98, tournament = ucl)))
        assertEquals(2, result.size)
    }

    @Test
    fun categoryDNeverDisplacesThreeBMatchesEvenWhenLive() {
        val b1 = match(4, 5, start = now.plus(Duration.ofHours(1)), id = "b1")
        val b2 = match(6, 8, start = now.plus(Duration.ofHours(5)), id = "b2")
        val b3 = match(10, 11, start = now.plus(Duration.ofHours(9)), id = "b3")
        val liveD = match(1, 99, start = now.minus(Duration.ofMinutes(20)), tournament = ucl, status = "1H", id = "d")
        val result = select(listOf(liveD, b1, b2, b3))
        assertEquals(setOf("b1", "b2", "b3"), result.map { it.match.providerMatchId }.toSet())
        assertFalse(result.any { it.category == "الفئة D" })
    }

    @Test
    fun bestCategoryDMatchesChosenByScoreWhenMoreThanThree() {
        val d55a = match(1, 99, start = now.plus(Duration.ofHours(1)), tournament = ucl, id = "a")
        val d55b = match(5, 98, start = now.plus(Duration.ofHours(1)), tournament = ucl, id = "b")
        val d55c = match(10, 97, start = now.plus(Duration.ofHours(1)), tournament = ucl, id = "c")
        val d50 = match(4, 96, start = now.plus(Duration.ofHours(1)), tournament = "Africa Cup of Nations", id = "x")
        val result = select(listOf(d50, d55a, d55b, d55c))
        assertEquals(3, result.size)
        assertTrue(result.none { it.match.providerMatchId == "x" })
    }
}
