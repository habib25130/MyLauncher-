package com.myfamily.launcher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Duration
import java.time.Instant
import java.time.LocalDate

class SmartMatchAlgorithmTest {
    private val now = Instant.parse("2026-10-24T08:00:00Z")
    private val today = LocalDate.of(2026, 10, 24)

    // Synthetic test IDs only. They are not provider IDs and must not be shipped as mappings.
    private val teamIds = mapOf(
        "REAL_MADRID" to 1, "BARCELONA" to 2, "ATLETICO_MADRID" to 3,
        "LIVERPOOL" to 4, "MAN_CITY" to 5, "MAN_UTD" to 6,
        "ARSENAL" to 7, "CHELSEA" to 8, "TOTTENHAM" to 9,
        "BAYERN" to 10, "DORTMUND" to 11, "PSG" to 12,
        "MARSEILLE" to 13, "AC_MILAN" to 14, "INTER" to 15,
        "JUVENTUS" to 16, "ROMA" to 17
    )
    private val teams = SmartMatchAlgorithm.TeamCatalog(teamIds)
    private val tournaments = SmartMatchAlgorithm.TournamentCatalog(
        majorNames = setOf("UEFA Champions League", "FIFA World Cup", "Africa Cup of Nations"),
        priorityByName = mapOf(
            "UEFA Champions League" to 1,
            "FIFA World Cup" to 2,
            "Africa Cup of Nations" to 3,
            "Premier League" to 5,
            "La Liga" to 6,
            "Ligue 1" to 7,
            "Serie A" to 8
        ),
        majorIds = setOf(101, 102, 103),
        priorityById = mapOf(101 to 1, 102 to 2, 103 to 3)
    )

    private fun match(
        home: Int,
        away: Int,
        start: Instant? = now.plus(Duration.ofHours(1)),
        tournament: String = "Premier League",
        tournamentId: Int? = null,
        type: String = "normal",
        status: String? = null,
        importance: String? = null,
        homeScore: Int? = null,
        awayScore: Int? = null,
        minute: String? = null,
        fixtureId: String? = null
    ) = SmartMatchAlgorithm.Match(
        homeTeamId = home,
        awayTeamId = away,
        tournamentId = tournamentId,
        tournamentName = tournament,
        matchType = type,
        importance = importance,
        startTime = start,
        status = status,
        homeScore = homeScore,
        awayScore = awayScore,
        minute = minute,
        providerMatchId = fixtureId
    )

    private fun select(matches: List<SmartMatchAlgorithm.Match>, at: Instant = now) =
        SmartMatchAlgorithm.rankAndSelect(
            matches, at, at.atZone(SmartMatchAlgorithm.ALGIERS_TZ).toLocalDate(), teams, tournaments
        )

    @Test
    fun totalSelectionNeverExceedsThreeWhenThereAreThreeAAndTwoB() {
        val matches = listOf(
            match(1, 2, now.plus(Duration.ofMinutes(30))),
            match(1, 3, now.plus(Duration.ofHours(1))),
            match(14, 15, now.plus(Duration.ofHours(2))),
            match(4, 5, now.plus(Duration.ofHours(1)), importance = null),
            match(6, 8, now.plus(Duration.ofHours(5)), importance = null)
        )
        val result = select(matches)
        assertEquals(3, result.size)
        assertEquals(3, result.count { it.category == "الفئة A" })
    }

    @Test
    fun oneBigTeamAgainstMediumTeamIsNotAutomaticallyCategoryAOrB() {
        val result = SmartMatchAlgorithm.evaluateMatch(match(4, 99), teams, tournaments)
        assertEquals(null, result)
    }

    @Test
    fun twoBigTeamsAreCategoryBAndImportanceOnlyFixtureCanBeCategoryC() {
        assertEquals("الفئة B", SmartMatchAlgorithm.evaluateMatch(match(4, 5), teams, tournaments)?.first)
        assertEquals(
            "الفئة C",
            SmartMatchAlgorithm.evaluateMatch(match(98, 99, importance = "title_decider"), teams, tournaments)?.first
        )
    }

    @Test
    fun exceptionalPairIsCategoryARegardlessOfHomeAwayOrder() {
        val forward = SmartMatchAlgorithm.evaluateMatch(match(1, 2), teams, tournaments)
        val reversed = SmartMatchAlgorithm.evaluateMatch(match(2, 1), teams, tournaments)
        assertEquals("الفئة A", forward?.first)
        assertEquals("الفئة A", reversed?.first)
    }

    @Test
    fun clasicoBeatsOrdinaryLiveWhenOnlyOneCanFit() {
        val live = match(4, 5, start = now.minus(Duration.ofMinutes(20)), status = "1H")
        val clasico = match(1, 2, start = now.plus(Duration.ofHours(1)))
        // Add two ordinary matches with 4-hour spacing so the A-vs-LIVE choice is constrained to 3.
        val otherLive1 = match(6, 8, start = now.minus(Duration.ofHours(7)), status = "live")
        val otherLive2 = match(10, 11, start = now.minus(Duration.ofHours(3)), status = "ht")
        val result = select(listOf(live, clasico, otherLive1, otherLive2))
        assertTrue(result.any { it.match === clasico || it.match == clasico })
        assertTrue(result.any { it.category == "الفئة A" })
        assertEquals(3, result.size)
    }

    @Test
    fun fourExceptionalMatchesChooseThreeByScoreThenTournamentPriority() {
        val clasico = match(1, 2, now.plus(Duration.ofHours(1)), tournament = "La Liga") // 100
        val majorFinal = match(4, 5, now.plus(Duration.ofHours(2)), tournament = "FIFA World Cup", type = "final") // 100
        val uclKnockout = match(6, 8, now.plus(Duration.ofHours(3)), tournament = "UEFA Champions League", type = "knockout") // 90
        val madridDerby = match(1, 3, now.plus(Duration.ofHours(4)), tournament = "La Liga") // 85

        val result = select(listOf(clasico, majorFinal, uclKnockout, madridDerby))
        assertEquals(3, result.size)
        assertTrue(result.any { it.match == clasico })
        assertTrue(result.any { it.match == majorFinal })
        assertTrue(result.any { it.match == uclKnockout })
        assertFalse(result.any { it.match == madridDerby })
    }

    @Test
    fun fourEqualExceptionalMatchesUseTournamentPriorityAsTieBreaker() {
        val madridDerby = match(1, 3, now.plus(Duration.ofHours(1)), tournament = "La Liga")
        val northLondon = match(7, 9, now.plus(Duration.ofHours(2)), tournament = "Premier League")
        val psgMarseille = match(12, 13, now.plus(Duration.ofHours(3)), tournament = "Ligue 1")
        val milanDerby = match(14, 15, now.plus(Duration.ofHours(4)), tournament = "Serie A")

        val result = select(listOf(madridDerby, northLondon, psgMarseille, milanDerby))
        assertEquals(3, result.size)
        assertTrue(result.any { it.match == northLondon })
        assertTrue(result.any { it.match == madridDerby })
        assertTrue(result.any { it.match == psgMarseille })
        assertFalse(result.any { it.match == milanDerby })
    }

    @Test
    fun ordinaryMatchesExactlyFourHoursApartAreBothSelected() {
        val first = match(4, 5, now.plus(Duration.ofHours(1)))
        val second = match(6, 8, now.plus(Duration.ofHours(5)))
        val result = select(listOf(first, second))
        assertEquals(2, result.size)
    }

    @Test
    fun ordinaryMatchesLessThanFourHoursApartCannotBothBeSelected() {
        val first = match(4, 5, now.plus(Duration.ofHours(1)))
        val second = match(6, 8, now.plus(Duration.ofHours(4)).minusSeconds(1))
        val result = select(listOf(first, second))
        assertEquals(1, result.size)
    }

    @Test
    fun exceptionalMatchesAreExemptFromFourHourGap() {
        val derby1 = match(1, 2, now.plus(Duration.ofMinutes(30)))
        val derby2 = match(1, 3, now.plus(Duration.ofHours(1)))
        val result = select(listOf(derby1, derby2))
        assertEquals(2, result.size)
    }

    @Test
    fun previousAlgiersDateLiveMatchCrossesMidnightWithinEightHours() {
        val afterMidnight = Instant.parse("2026-10-24T00:30:00Z") // 01:30 in Algiers
        val yesterdayKickoff = Instant.parse("2026-10-23T22:30:00Z") // 23:30 previous Algiers date
        val live = match(4, 5, start = yesterdayKickoff, status = "live")
        val result = SmartMatchAlgorithm.rankAndSelect(
            listOf(live), afterMidnight, LocalDate.of(2026, 10, 24), teams, tournaments
        )
        assertEquals(1, result.size)
        assertEquals(SmartMatchAlgorithm.MatchState.LIVE, result.single().state)
    }

    @Test
    fun previousDateLiveMatchOlderThanEightHoursIsExcluded() {
        val nowAfterEightHours = Instant.parse("2026-10-24T07:00:01Z")
        val yesterdayKickoff = Instant.parse("2026-10-23T22:30:00Z")
        val live = match(4, 5, start = yesterdayKickoff, status = "live")
        val result = SmartMatchAlgorithm.rankAndSelect(
            listOf(live), nowAfterEightHours, LocalDate.of(2026, 10, 24), teams, tournaments
        )
        assertTrue(result.isEmpty())
    }

    @Test
    fun liveMatchOnSameDateIsAlsoLimitedToEightHours() {
        val sameDateOldKickoff = now.minus(Duration.ofHours(8)).minusSeconds(1)
        val live = match(4, 5, start = sameDateOldKickoff, status = "live")
        assertTrue(select(listOf(live)).isEmpty())
    }

    @Test
    fun awaitingUpdateIsEligibleUntilTwoHourBoundaryAndExpiresAfter() {
        val exactlyTwoHoursLate = match(1, 2, start = now.minus(Duration.ofHours(2)))
        val twoHoursAndOneSecondLate = match(1, 2, start = now.minus(Duration.ofHours(2)).minusSeconds(1))
        assertEquals(SmartMatchAlgorithm.MatchState.AWAITING_UPDATE,
            SmartMatchAlgorithm.getMatchState(exactlyTwoHoursLate, now))
        assertEquals(1, select(listOf(exactlyTwoHoursLate)).size)
        assertEquals(SmartMatchAlgorithm.MatchState.EXPIRED,
            SmartMatchAlgorithm.getMatchState(twoHoursAndOneSecondLate, now))
        assertTrue(select(listOf(twoHoursAndOneSecondLate)).isEmpty())
    }

    @Test
    fun countdownStartsAtTwoHoursAndNotEarlier() {
        val exactlyTwoHours = match(1, 2, start = now.plus(Duration.ofHours(2)))
        val twoHoursAndOneSecond = match(1, 2, start = now.plus(Duration.ofHours(2)).plusSeconds(1))
        assertEquals(SmartMatchAlgorithm.MatchState.COUNTDOWN,
            SmartMatchAlgorithm.getMatchState(exactlyTwoHours, now))
        assertEquals(SmartMatchAlgorithm.MatchState.UPCOMING,
            SmartMatchAlgorithm.getMatchState(twoHoursAndOneSecond, now))
    }

    @Test
    fun providerStatusAliasesNormalizeToInternalStates() {
        val aliases = mapOf(
            "ft" to SmartMatchAlgorithm.MatchState.FINISHED,
            "finished" to SmartMatchAlgorithm.MatchState.FINISHED,
            "full_time" to SmartMatchAlgorithm.MatchState.FINISHED,
            "1H" to SmartMatchAlgorithm.MatchState.LIVE,
            "2H" to SmartMatchAlgorithm.MatchState.LIVE,
            "HT" to SmartMatchAlgorithm.MatchState.LIVE,
            "suspended" to SmartMatchAlgorithm.MatchState.SUSPENDED,
            "interrupted" to SmartMatchAlgorithm.MatchState.SUSPENDED,
            "postponed" to SmartMatchAlgorithm.MatchState.POSTPONED,
            "cancelled" to SmartMatchAlgorithm.MatchState.CANCELLED
        )
        aliases.forEach { (raw, expected) ->
            assertEquals(raw, expected,
                SmartMatchAlgorithm.getMatchState(match(4, 5, status = raw), now))
        }
    }

    @Test
    fun finishedMatchDisplaysFinalScoreAndOverridesLiveAlias() {
        val finished = match(1, 2, status = "full time", homeScore = 2, awayScore = 1)
        assertEquals(SmartMatchAlgorithm.MatchState.FINISHED,
            SmartMatchAlgorithm.getMatchState(finished, now))
        assertEquals(
            "النتيجة النهائية: 2 - 1",
            SmartMatchAlgorithm.getMatchStatusAndDisplay(finished, now).second
        )
    }

    @Test
    fun postponedCancelledAndMissingTimeAreNotSelected() {
        val postponed = match(4, 5, status = "postponed")
        val cancelled = match(1, 2, status = "cancelled")
        val missingTime = match(1, 2, start = null)
        assertTrue(select(listOf(postponed, cancelled, missingTime)).isEmpty())
    }

    @Test
    fun noSuitableTodayMatchFallsBackToTomorrowFromSuppliedList() {
        val weakToday = match(98, 99, start = now.plus(Duration.ofHours(1)))
        val tomorrowStart = Instant.parse("2026-10-24T23:30:00Z") // 00:30 next day in Algiers
        val tomorrowClasico = match(1, 2, start = tomorrowStart)
        val result = SmartMatchAlgorithm.selectTopSmartMatches(
            listOf(weakToday, tomorrowClasico), now, teams, tournaments
        )
        assertEquals(1, result.size)
        assertEquals(tomorrowClasico, result.single().match)
    }

    @Test
    fun unverifiedOrMissingTeamMappingsDoNotCreateExceptionalClassification() {
        val noVerifiedMappings = SmartMatchAlgorithm.TeamCatalog(teamIds = emptyMap())
        val match = match(1, 2)
        assertEquals(null, SmartMatchAlgorithm.evaluateMatch(match, noVerifiedMappings, tournaments))
    }

    @Test
    fun duplicateProviderFixtureIsSelectedOnlyOnce() {
        val first = match(1, 2, fixtureId = "provider-fixture-1")
        val duplicateWithUpdatedScore = match(1, 2, homeScore = 1, awayScore = 0, fixtureId = "provider-fixture-1")
        val result = select(listOf(first, duplicateWithUpdatedScore))
        assertEquals(1, result.size)
    }
}
