package com.myfamily.launcher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

/** اختبارات الجسر فقط (ترجمة بيانات API-Football). اختبارات الخوارزمية الأصلية في SmartMatchAlgorithmTest. */
class SmartMatchBridgeTest {
    // 2026-10-24 09:00 بتوقيت الجزائر
    private val nowMs = Instant.parse("2026-10-24T08:00:00Z").toEpochMilli()
    private val nowSec = nowMs / 1000

    // بطولة خارج قائمة المتابعة في FootballConfig (لا نكرر القائمة: نتأكد فقط أن هذا الرقم ليس فيها)
    private val UNFOLLOWED = 999999

    private fun fx(
        id: Int, home: Int, away: Int, league: Int,
        inSeconds: Long = 3600, round: String = "Regular Season - 10", st: String = "NS"
    ) = Football.M().also {
        it.id = id; it.homeId = home; it.awayId = away; it.leagueId = league
        it.league = "x"; it.round = round; it.st = st; it.ts = nowSec + inSeconds
    }

    @Test
    fun apiStatusCodesAreTranslated() {
        assertNull(SmartMatchBridge.apiStatus("NS"))
        assertNull(SmartMatchBridge.apiStatus("TBD"))
        listOf("1H", "2H", "HT", "ET", "BT", "P", "LIVE").forEach { assertEquals(it, "live", SmartMatchBridge.apiStatus(it)) }
        listOf("FT", "AET", "PEN").forEach { assertEquals(it, "finished", SmartMatchBridge.apiStatus(it)) }
        assertEquals("postponed", SmartMatchBridge.apiStatus("PST"))
        assertEquals("cancelled", SmartMatchBridge.apiStatus("CANC"))
        assertEquals("suspended", SmartMatchBridge.apiStatus("SUSP"))
        assertEquals("suspended", SmartMatchBridge.apiStatus("INT"))
    }

    @Test
    fun roundsMapToMatchTypes() {
        assertEquals("final", SmartMatchBridge.matchType("Final"))
        assertEquals("knockout", SmartMatchBridge.matchType("Quarter-finals"))
        assertEquals("knockout", SmartMatchBridge.matchType("Semi-finals"))
        assertEquals("knockout", SmartMatchBridge.matchType("Round of 16"))
        assertEquals("knockout", SmartMatchBridge.matchType("8th Finals"))
        assertEquals("normal", SmartMatchBridge.matchType("3rd Place Final"))
        assertEquals("normal", SmartMatchBridge.matchType("Group Stage - 1"))
        assertEquals("normal", SmartMatchBridge.matchType("2nd Qualifying Round"))
        assertEquals("normal", SmartMatchBridge.matchType("Regular Season - 10"))
        assertEquals("normal", SmartMatchBridge.matchType(""))
    }

    @Test
    fun realClasicoIsSelectedWithCountdownState() {
        val clasico = fx(1001, 541, 529, 140)
        val result = SmartMatchBridge.select(listOf(clasico), nowMs)
        assertEquals(1, result.size)
        assertEquals(1001, result[0].id)
        assertEquals("COUNTDOWN", result[0].smart)
    }

    @Test
    fun syntheticTestIdsAreNotTreatedAsRealTeams() {
        // 1 و2 هما "ريال/برشلونة" في اختبارات الخوارزمية الوهمية فقط
        assertTrue(SmartMatchBridge.select(listOf(fx(1002, 1, 2, UNFOLLOWED)), nowMs).isEmpty())
    }

    @Test
    fun famousTeamAgainstUnlistedTeamIsNotSelected() {
        assertTrue(SmartMatchBridge.select(listOf(fx(1003, 40, 9999, UNFOLLOWED)), nowMs).isEmpty())
    }

    @Test
    fun clasicoThenChampionsLeagueKnockoutThenNothingElse() {
        val clasico = fx(1, 541, 529, 140, 3600)                                   // 100
        val ucl = fx(2, 9001, 9002, 2, 3 * 3600L, round = "Round of 16")            // 90
        val ordinary = fx(3, 9003, 9004, UNFOLLOWED, 4 * 3600L)                    // لا يؤهَّل
        val result = SmartMatchBridge.select(listOf(ordinary, ucl, clasico), nowMs)
        assertEquals(listOf(1, 2), result.map { it.id })
    }

    @Test
    fun twoBigTeamsInDomesticLeagueAreSelected() {
        val liverpoolCity = fx(4, 40, 50, 39)    // الفئة B
        assertEquals(listOf(4), SmartMatchBridge.select(listOf(liverpoolCity), nowMs).map { it.id })
    }

    @Test
    fun duplicateApiIdIsSelectedOnce() {
        val a = fx(7, 541, 529, 140)
        val b = fx(7, 541, 529, 140)
        assertEquals(1, SmartMatchBridge.select(listOf(a, b), nowMs).size)
    }

    @Test
    fun clasicoInAnyCompetitionIsKeptInTheCache() {
        assertTrue(SmartMatchBridge.isSmartCandidate(fx(8, 541, 529, 143)))   // كأس الملك
        assertTrue(!SmartMatchBridge.isSmartCandidate(fx(9, 541, 9999, 143)))
    }

    @Test
    fun followedLeagueAndFollowedTeamMakeOrdinaryMatchesEligible() {
        assertTrue(!FootballConfig.LEAGUES.contains(UNFOLLOWED))
        val league = fx(20, 9001, 9002, FootballConfig.LEAGUES[0])
        val team = fx(21, FootballConfig.TEAMS[0], 9002, UNFOLLOWED)
        val none = fx(22, 9001, 9002, UNFOLLOWED)
        val result = SmartMatchBridge.select(listOf(none, league, team), nowMs)
        assertEquals(setOf(20, 21), result.map { it.id }.toSet())
    }

    @Test
    fun bigClubsInChampionsLeagueFillTheSelectionAsCategoryD() {
        val arsenalDortmund = fx(10, 42, 165, 2)    // الفئة B
        val realOther = fx(11, 541, 9999, 2)        // الفئة D
        val cityOther = fx(12, 50, 9998, 2)         // الفئة D
        val result = SmartMatchBridge.select(listOf(realOther, cityOther, arsenalDortmund), nowMs)
        assertEquals(3, result.size)
        assertEquals(10, result[0].id)
    }
}
