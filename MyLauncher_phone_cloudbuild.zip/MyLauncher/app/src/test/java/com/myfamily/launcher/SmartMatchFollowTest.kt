package com.myfamily.launcher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Duration
import java.time.Instant
import java.time.LocalDate

/** اختبارات المتابعة فقط. اختبارات الخوارزمية الأصلية في SmartMatchAlgorithmTest بلا أي تعديل. */
class SmartMatchFollowTest {
    private val now = Instant.parse("2026-10-24T08:00:00Z")
    private val today = LocalDate.of(2026, 10, 24)

    // معرّفات تجريبية فقط
    private val teams = SmartMatchAlgorithm.TeamCatalog(
        mapOf(
            "REAL_MADRID" to 1, "LIVERPOOL" to 4, "MAN_CITY" to 5, "MAN_UTD" to 6,
            "CHELSEA" to 8, "BAYERN" to 10, "DORTMUND" to 11
        )
    )
    private val tournaments = SmartMatchAlgorithm.TournamentCatalog(
        majorNames = setOf("UEFA Champions League"),
        priorityByName = mapOf("UEFA Champions League" to 1, "Premier League" to 5)
    )
    private val follow = SmartMatchAlgorithm.FollowCatalog(leagueIds = setOf(777), teamIds = setOf(98))

    private fun match(
        home: Int, away: Int,
        start: Instant = now.plus(Duration.ofHours(1)),
        tournament: String = "Premier League",
        tournamentId: Int? = null,
        status: String? = null,
        id: String? = null
    ) = SmartMatchAlgorithm.Match(
        homeTeamId = home, awayTeamId = away, tournamentId = tournamentId, tournamentName = tournament,
        matchType = "normal", startTime = start, status = status, providerMatchId = id
    )

    private fun select(matches: List<SmartMatchAlgorithm.Match>, f: SmartMatchAlgorithm.FollowCatalog = follow) =
        SmartMatchAlgorithm.rankAndSelect(matches, now, today, teams, tournaments, f)

    @Test
    fun followDoesNotChangeClassification() {
        assertNull(SmartMatchAlgorithm.evaluateMatch(match(97, 99, tournamentId = 777), teams, tournaments))
    }

    @Test
    fun followedLeagueMatchIsEligibleButNeverCategoryA() {
        val result = select(listOf(match(97, 99, tournamentId = 777)))
        assertEquals(1, result.size)
        assertEquals("فئة المتابعة", result.single().category)
        assertFalse(result.single().category == "الفئة A")
    }

    @Test
    fun followedTeamMatchIsEligible() {
        assertEquals(1, select(listOf(match(98, 99))).size)
    }

    @Test
    fun unfollowedOrdinaryMatchIsStillExcluded() {
        assertTrue(select(listOf(match(97, 99, tournamentId = 123))).isEmpty())
        assertTrue(select(listOf(match(98, 99)), SmartMatchAlgorithm.FollowCatalog()).isEmpty())
    }

    @Test
    fun followedMatchesFillRemainingSlotsAfterB() {
        val b = match(4, 5, id = "b")
        val f1 = match(97, 99, tournamentId = 777, id = "f1")
        val f2 = match(98, 96, id = "f2")
        val result = select(listOf(f1, f2, b))
        assertEquals(3, result.size)
        assertEquals("b", result[0].match.providerMatchId)
    }

    @Test
    fun followBreaksTiesBetweenEqualCategoriesWithoutChangingThem() {
        val unfollowedEarlier = match(4, 5, start = now.plus(Duration.ofHours(1)), id = "plain")
        val followedLater = match(6, 8, start = now.plus(Duration.ofHours(2)), tournamentId = 777, id = "followed")
        val result = select(listOf(unfollowedEarlier, followedLater))
        assertEquals(1, result.size)               // فاصل الأربع ساعات ما زال يمنع الاثنين
        assertEquals("followed", result.single().match.providerMatchId)
        assertEquals("الفئة B", result.single().category)
    }

    @Test
    fun followedMatchNeverDisplacesThreeBMatchesEvenWhenLive() {
        val b1 = match(4, 5, start = now.plus(Duration.ofHours(1)), id = "b1")
        val b2 = match(6, 8, start = now.plus(Duration.ofHours(5)), id = "b2")
        val b3 = match(10, 11, start = now.plus(Duration.ofHours(9)), id = "b3")
        val liveFollowed = match(97, 99, start = now.minus(Duration.ofMinutes(20)), tournamentId = 777, status = "1H", id = "f")
        val result = select(listOf(liveFollowed, b1, b2, b3))
        assertEquals(setOf("b1", "b2", "b3"), result.map { it.match.providerMatchId }.toSet())
    }

    @Test
    fun categoryDIsPreferredOverFollowOnlyMatchesWhenFilling() {
        val d = match(1, 99, tournament = "UEFA Champions League", id = "d")
        val f = (1..3).map { match(90 + it, 80 + it, tournamentId = 777, id = "f$it") }
        val result = select(f + d)
        assertEquals(3, result.size)
        assertTrue(result.any { it.match.providerMatchId == "d" })
    }
}
