package com.myfamily.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * تصدير واستيراد إعدادات ومفاتيح التطبيق (SharedPreferences "launcher") إلى/من ملف محلي.
 * يتيح الاستعادة اليدوية كاحتياط إضافي للنسخ التلقائي الخاص بـ Android System.
 */
public final class SettingsBackup {
    private SettingsBackup() { }

    public static final String BACKUP_FILENAME = "mylauncher_backup.json";

    public static File getExportFile(Context context) {
        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (downloads != null && (downloads.exists() || downloads.mkdirs()) && downloads.canWrite()) {
            return new File(downloads, BACKUP_FILENAME);
        }
        File ext = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (ext != null) return new File(ext, BACKUP_FILENAME);
        return new File(context.getFilesDir(), BACKUP_FILENAME);
    }

    public static File getImportFile(Context context) {
        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (downloads != null) {
            File f = new File(downloads, BACKUP_FILENAME);
            if (f.exists() && f.canRead()) return f;
        }
        File ext = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (ext != null) {
            File f = new File(ext, BACKUP_FILENAME);
            if (f.exists() && f.canRead()) return f;
        }
        File internal = new File(context.getFilesDir(), BACKUP_FILENAME);
        if (internal.exists() && internal.canRead()) return internal;
        return null;
    }

    public static String exportSettings(Context context) throws Exception {
        SharedPreferences p = context.getSharedPreferences("launcher", Context.MODE_PRIVATE);
        Map<String, ?> all = p.getAll();

        JSONObject root = new JSONObject();
        root.put("version", 1);
        root.put("timestamp", System.currentTimeMillis());

        JSONObject data = new JSONObject();
        for (Map.Entry<String, ?> entry : all.entrySet()) {
            String key = entry.getKey();
            Object val = entry.getValue();
            if (key != null && val != null) {
                data.put(key, val);
            }
        }
        root.put("data", data);

        File target = getExportFile(context);
        File parent = target.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();

        try (OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(target), StandardCharsets.UTF_8)) {
            writer.write(root.toString(2));
        }

        return target.getAbsolutePath();
    }

    public static boolean importSettings(Context context, File file) throws Exception {
        if (file == null || !file.exists() || !file.canRead()) {
            throw new IllegalArgumentException("File not found or unreadable");
        }

        StringBuilder sb = new StringBuilder();
        try (InputStreamReader reader = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8)) {
            char[] buf = new char[4096];
            int r;
            while ((r = reader.read(buf)) != -1) {
                sb.append(buf, 0, r);
            }
        }

        JSONObject root = new JSONObject(sb.toString());
        JSONObject data = root.has("data") ? root.getJSONObject("data") : root;

        SharedPreferences p = context.getSharedPreferences("launcher", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = p.edit();

        java.util.Iterator<String> keys = data.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            if (k == null || k.equals("version") || k.equals("timestamp")) continue;
            Object val = data.get(k);
            if (val instanceof Boolean) {
                editor.putBoolean(k, (Boolean) val);
            } else if (val instanceof Integer) {
                editor.putInt(k, (Integer) val);
            } else if (val instanceof Long) {
                editor.putLong(k, (Long) val);
            } else if (val instanceof Double || val instanceof Float) {
                editor.putFloat(k, ((Number) val).floatValue());
            } else if (val instanceof String) {
                editor.putString(k, (String) val);
            }
        }
        editor.apply();

        // تحديث الخدمات الحية بعد استيراد المفاتيح والإعدادات
        WeatherRepository.refresh(context, true, null);
        Football.refresh(context, true, null);
        Adhan.schedule(context);

        return true;
    }
}
